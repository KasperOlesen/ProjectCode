﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KitchenApplication.Tests.tests.selenium.common;

namespace KitchenApplication.Tests.tests.selenium.pages
{
    /// <summary>
    /// Defines a definition of a page that can be used to test
    /// </summary>
    public interface IPageDefinition
    {
        /// <summary>
        /// Navigates to the page
        /// </summary>
        bool NavigateTo();

        /// <summary>
        /// Return the url to the page
        /// </summary>
        /// <returns></returns>
        string UrlToPage();

        /// <summary>
        /// Test if the current page is this one
        /// </summary>
        /// <returns></returns>
        bool IsPagePresent(bool startsWith = false);
    }
}
