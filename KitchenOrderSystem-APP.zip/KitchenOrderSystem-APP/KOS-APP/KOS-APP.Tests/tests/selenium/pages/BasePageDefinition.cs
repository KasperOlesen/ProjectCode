﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KitchenApplication.Tests.tests.selenium.common;

namespace KitchenApplication.Tests.tests.selenium.pages
{
    /// <summary>
    /// This is the basic implementation of the page definition
    /// </summary>
    public abstract class BasePageDefinition : IPageDefinition
    {
        /// <summary>
        /// Navigates to the page. 
        /// </summary>
        public virtual bool NavigateTo()
        {
            BrowserFactory.GetRunner().WebDriver.Navigate().GoToUrl(UrlToPage());
            return IsPagePresent();
        }

        /// <summary>
        /// Return the url to the page
        /// </summary>
        /// <returns></returns>
        public abstract string UrlToPage();

        /// <summary>
        /// Check if the current page is this one
        /// </summary>
        /// <returns></returns>
        public virtual bool IsPagePresent(bool startsWith = false)
        {
            string urlToPage = UrlToPage().Replace("//", "/").ToLower();
            string currentUrl = BrowserFactory.GetRunner().WebDriver.Url.Replace("/en/", "//").Replace("//", "/").ToLower();

            return startsWith ? currentUrl.StartsWith(urlToPage) : currentUrl.Equals(urlToPage);
        }
    }
}
