﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KitchenApplication.Tests.tests.selenium.common
{
    /// <summary>
    /// This will create a new browser runner 
    /// </summary>
    public class BrowserFactory
    {
        /// <summary>
        /// The current runner used for testing in the browser
        /// </summary>
        private static BrowserRunner _runner;

        /// <summary>
        /// Gets the runner. Either create it or reuse the existing one
        /// </summary>
        /// <returns></returns>
        public static BrowserRunner GetRunner()
        {
            if (_runner != null)
            {
                return _runner;
            }

            var baseUrl = "http://localhost/KitchenProject";
            var browserType = "Chrome";

            _runner = new BrowserRunner(
                baseUrl,
                browserType
                );

            return _runner;
        }

        /// <summary>
        /// Dispose it we are finished
        /// </summary>
        public static void DisposeRunner()
        {
            if (_runner != null)
            {
                _runner.Close();
                _runner = null;
            }
        }

        /// <summary>
        /// test if a runner has been initialised
        /// </summary>
        /// <returns></returns>
        public static bool HasRunner()
        {
            return _runner != null;
        }
    }
}