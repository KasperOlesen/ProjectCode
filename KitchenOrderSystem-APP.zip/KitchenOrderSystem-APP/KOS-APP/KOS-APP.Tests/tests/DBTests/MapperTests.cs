﻿//using System;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using KitchenApplication.Models.Database;
//using System.Collections.Generic;
//using System.Linq;
//using KitchenApplication.App_Start.Services;
//using Moq;
//using WebApplication1.Models;

//namespace KitchenApplication.Tests.tests.DBTests
//{
//    [TestClass]
//    public class MapperTests
//    {

//        [TestMethod]
//        public void TestMapUsers()
//        {
//            var user1 = new Entity.User
//            {
//                Name = "TestUser",
//                Location = "TestLocation",
//                Email = "TestEmail@testmail.dk",
//                Orders = new List<Entity.Order>()
//            };

//            var user2 = new Entity.User
//            {
//                Name = "TestUser2",
//                Location = "TestLocation2",
//                Email = "TestEmail2@testmail.dk",
//                Orders = new List<Entity.Order>()
//            };

//            List<Entity.User> usersList = new List<Entity.User>{user1, user2};
//            Mock<IBoundary> mock = new Mock<IBoundary>();

//            mock.Setup(x => x.GetAllUsers()).Returns(usersList);

//            MapperService map = new MapperService(mock.Object);

//            List<UserViewModel> usersExpected = new List<UserViewModel>();

//            foreach (var user in usersList)
//            {
//                usersExpected.Add(new UserViewModel
//                {
//                    Email = user.Email,
//                    Id = user.Id,
//                    ImageUrl = user.ImageUrl,
//                    Location = user.Location,
//                    Name = user.Name,
//                    Orders = null
//                });
//            }

//            List<UserViewModel> users = map.Users();

//            CollectionAssert.AreEqual(usersExpected.OrderByDescending(x => x.Name).Reverse().ToList(), users);
//        }


//        [TestMethod]
//        public void TestNewMenuDate()
//        {
//            var menu = new Entity.Menu { ClosingTime = DateTime.Today.AddHours(2), Date = DateTime.Today, MenuItems = new List<Entity.MenuItem>() };
//            var menuItem1 = new Entity.MenuItem { FoodItem = "Ged", Description = "Med hår" };
//            var menuItem2 = new Entity.MenuItem { FoodItem = "Burger", Description = "med salat" };

//            menu.MenuItems.Add(menuItem1);
//            menu.MenuItems.Add(menuItem2);
//            using (var db = new Entity.KitchenAppContext())
//            {
//                db.Menus.Add(menu);
//                db.SaveChanges();
//            }

//            MapperService map = new MapperService();

//            MenuViewModel todaysMenu = map.TodaysMenu();

//            Assert.IsTrue(todaysMenu.Date.Equals(menu.Date) && todaysMenu.MenuItems.Count == 2);
//        }

//        [TestMethod]
//        public void TestUsersToUserViewModelsType()
//        {
//            var user1 = new Entity.User
//            {
//                Name = "Karsten-Arne",
//                Location = "Kbh",
//                Email = "Karsten-Arne@mail.dk",
//                Orders = new List<Entity.Order>()
//            };
//            var user2 = new Entity.User
//            {
//                Name = "Abel-Ort",
//                Location = "Århus",
//                Email = "abelort@mail.dk",
//                Orders = new List<Entity.Order>()
//            };
//            var user3 = new Entity.User
//            {
//                Name = "Androt",
//                Location = "Kbh",
//                Email = "Androt@mail.dk",
//                Orders = new List<Entity.Order>()
//            };
//            var user4 = new Entity.User
//            {
//                Email = "kasperpontoppidan@gmail.com",
//                Location = "København",
//                Name = "Kasper Hornum Pontoppidan",
//                Orders = new List<Entity.Order>()
//            };

//            List<Entity.User> users = new List<Entity.User> { user1, user2, user3, user4 };

//            var userViewModels = new MapperService().UsersToUserViewModels(users);

//            Assert.IsInstanceOfType(userViewModels, typeof(List<UserViewModel>));
//        }


//        [TestMethod]
//        public void TestTodaysMenu()
//        {
//            Entity.Menu menu = new Entity.Menu();
//            var menuItem1 = new Entity.MenuItem { FoodItem = "TestCreateOrderFoodItem1", Description = "Med hår", Price = 25.0 };
//            var menuItem2 = new Entity.MenuItem { FoodItem = "TestCreateOrderFoodItem2", Description = "med salat", Price = 25.0 };
//            var menuItem3 = new Entity.MenuItem { FoodItem = "TestCreateOrderFoodItem3", Description = "løgsuppe", Price = 25.0 };

//            List<Entity.MenuItem> menuItems = new List<Entity.MenuItem> { menuItem1, menuItem2, menuItem3 };

//            menu.ClosingTime = DateTime.Today.AddHours(13);
//            menu.Date = DateTime.Today;
//            menu.MenuItems = menuItems;

//            var boundaryMock = new Mock<IBoundary>();

//            boundaryMock.Setup(x => x.GetMenuByDate(DateTime.Today)).Returns(menu);

//            List<MenuItemViewModel> menuItemsVm = new List<MenuItemViewModel>();

//            foreach (var menuItem in menuItems)
//            {
//                menuItemsVm.Add(new MenuItemViewModel
//                {
//                    Description = menuItem.Description,
//                    FoodItem = menuItem.FoodItem,
//                    Id = menuItem.Id,
//                    OrderCount = menuItem.OrderCount,
//                    Price = menuItem.Price
//                });
//            }

//            MenuViewModel mvm = new MenuViewModel
//            {
//                ClosingTime = menu.ClosingTime,
//                Date = menu.Date,
//                Id = menu.Id,
//                MenuItems = menuItemsVm
//            };

//            MenuViewModel mvmMapper = new MapperService(boundaryMock.Object).TodaysMenu();

//            Assert.AreEqual(mvm.Id, mvmMapper.Id);
//            Assert.AreEqual(mvm.Date, mvmMapper.Date);
//            Assert.AreEqual(mvm.ClosingTime, mvmMapper.ClosingTime);
//            Assert.AreEqual(mvm.MenuItems.Count, mvmMapper.MenuItems.Count);
//        }

//    }
//}
