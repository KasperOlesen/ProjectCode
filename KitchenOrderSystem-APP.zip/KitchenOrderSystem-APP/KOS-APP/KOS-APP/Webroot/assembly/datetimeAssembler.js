


export function getDate(dateObj) {
  try {
    let date = dateObj.getDate() + "." + (dateObj.getMonth()+1) + "." + dateObj.getFullYear()
    return date
  }
  catch (e) {
    console.log('Error in datetimeAssembler - (getDate): ' + e)
  }
}

export function getTime(dateObj) {
  try {
    let time = dateObj.getHours() + ':' + ('0'+dateObj.getMinutes()).slice(-2)
    return time
  }
  catch (e) {
    console.log('Error in datetimeAssembler - (getTime): ' + e)
  }
}

export function fixFormat(dateObj) {
  try {
    let dateTime = new Date(dateObj.split('(')[1].split(')')[0] * 1)
    return dateTime
  }
  catch (e) {
    console.log('Error in datetimeAssembler - (fixFormat): ' + e)
  }
}