﻿import React, { Component } from 'react'
import { put, call, take, fork, select } from 'redux-saga/effects'
import { callServerApi } from '../services/serverService'


export function* handleRequest(url, method, data){

  //TODO - ERROR HANDLING

  return yield call(executeRequest, url, method, data)
}

function* executeRequest(url, method, data) {


   try { 
    let response = yield call(callServerApi, url, method, data)
    let responseSuccess = response && response.Succeeded   

    //temporary workaround - should NOT return response here,
    //but response.Succeeded returns undefined.
    //Add 'Succeeded' prop to the response with a boolean
    //with true/false depending on whether
    //the request was succesfully handled or not. 
    return response
    


    if (responseSuccess) {
    
      yield success(response)
      //return response
    
    } else {
      console.log('ERROR', response)
      
      //TODO - ERROR HANDLING
      
     }  
    
    } catch (error){
       console.log('Error from serverSaga', error)
    //TODO - ERROR HANDLING

    
  } 
}