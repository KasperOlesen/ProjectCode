import { fork } from 'redux-saga/effects'
import 'babel-polyfill'

import orderSaga from './placeOrderSaga'


export default function* root(){

  yield [
    fork(orderSaga),

  ]
}