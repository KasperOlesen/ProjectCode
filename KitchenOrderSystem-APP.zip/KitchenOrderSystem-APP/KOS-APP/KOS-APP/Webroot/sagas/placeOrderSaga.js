import { fork, put, select, call } from 'redux-saga/effects'
import { takeEvery, takeLatest } from 'redux-saga'
import { handleRequest } from './serverSaga'
import {
  setUserData,
  addMenuItem,
  remMenuItem,
  setOrderingProcessInit,
  setComment,
  setMenu,
  setOrderType
} from '../reducers/placeOrderReducer'

const SET_USER_DATA_REQUEST = 'SET_USER_DATA_REQUEST'
const ADD_MENU_ITEM_REQUEST = 'ADD_MENU_ITEM_REQUEST'
const REM_MENU_ITEM_REQUEST = 'REM_MENU_ITEM_REQUEST'
const SET_COMMENT_REQUEST = 'SET_COMMENT_REQUEST'
const SET_MENU_REQUEST = "SET_MENU_REQUEST"
const SUBMIT_ORDER_REQUEST = 'SUBMIT_ORDER_REQUEST'
const SET_ORDER_TYPE_REQUEST = 'SET_ORDER_TYPE_REQUEST'

export function setUserDataRequest(userData) { return { type: SET_USER_DATA_REQUEST, userData } }
export function addMenuItemRequest(menuItem) { return { type: ADD_MENU_ITEM_REQUEST, menuItem } }
export function remMenuItemRequest(menuItem) { return { type: REM_MENU_ITEM_REQUEST, menuItem } }
export function setCommentRequest(comment) { return { type: SET_COMMENT_REQUEST, comment } }
export function setMenuRequest(menu) { return { type: SET_MENU_REQUEST, menu } }
export function submitOrderRequest(users, orderType, order, comment) { return { type: SUBMIT_ORDER_REQUEST, users, orderType, order, comment } }
export function setOrderTypeRequest(orderType) {return {type: SET_ORDER_TYPE_REQUEST, orderType}}


function* setUserDataSaga(action) {
  yield put(setUserData(action.userData))
}

function* addMenuItemSaga(action) {
  yield put(addMenuItem(action.menuItem))
  yield put(setOrderingProcessInit())
}

function* remMenuItemSaga(action) {
  yield put(remMenuItem(action.menuItem))
}

function* setCommentSaga(action) {
  yield put(setComment(action.comment))
}

function* setMenuSaga(action) {
  yield put(setMenu(action.menu))
}

function* submitOrderSaga(action) {

  const newOrder = {
    Users: [action.users],
    DeliveryType: action.orderType,
    MenuItems: action.order,
    Comment: action.comment
  }

  yield call(handleRequest('/home/order', 'POST', newOrder))
}

function* setOrderTypeSaga(action) {
  yield put(setOrderType(action.orderType))
  yield put(setOrderingProcessInit())
}


export default function* orderSaga() {
  yield [
    fork(function* () {
      yield takeEvery(SET_USER_DATA_REQUEST, setUserDataSaga)
    }),
    fork(function* () {
      yield takeEvery(ADD_MENU_ITEM_REQUEST, addMenuItemSaga)
    }),
    fork(function* () {
      yield takeEvery(REM_MENU_ITEM_REQUEST, remMenuItemSaga)
    }),
    fork(function* () {
      yield takeEvery(SET_COMMENT_REQUEST, setCommentSaga)
    }),
    fork(function* () {
      yield takeEvery(SET_MENU_REQUEST, setMenuSaga)
    }),
    fork(function* () {
      yield takeEvery(SUBMIT_ORDER_REQUEST, submitOrderSaga)
    }),
    fork(function* () {
      yield takeEvery(SET_ORDER_TYPE_REQUEST, setOrderTypeSaga)
    }),
  ]
}