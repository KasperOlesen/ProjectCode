﻿import { combineReducers } from 'redux'
import { reducer as reduxFormReducer } from 'redux-form'


import orderList from '../reducers/placeOrderReducer'


export default combineReducers({
  orderList,
})