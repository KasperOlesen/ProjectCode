import React, { Component } from 'react'
import { connect } from 'react-redux'


const mapStateToProps = (state) => {
  return {

  }
}

const mapDispatchToProps = (dispatch) => {
  return {

  }
}

class empAppPage extends React.Component {

  constructor(props) {
    super(props)
  }

  componentWillMount() {    
  }

  componentDidMount() {
  }


  render() {

    return (
      <div>
      </div>

    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(empAppPage)



