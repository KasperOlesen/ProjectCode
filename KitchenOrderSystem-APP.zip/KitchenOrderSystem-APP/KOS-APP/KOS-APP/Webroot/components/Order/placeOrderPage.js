import React, { Component } from 'react'
import { connect } from 'react-redux'
import { orderSelector } from '../../reducers/placeOrderReducer';
import {
  setUserDataRequest,
  addMenuItemRequest,
  remMenuItemRequest,
  setOrderingProcessInitRequest,
  setMenuRequest,
  setCommentRequest,
  submitOrderRequest,
  setOrderTypeRequest
} from '../../sagas/placeOrderSaga'
import MenuElement from './MenuElement';
import OrderElement from './OrderElement';
import '../../css/placeOrderPage.css'

const mapStateToProps = (state) => {
  return {
    UserId: orderSelector.UserId(state),
    UserName: orderSelector.UserName(state),
    Order: orderSelector.Order(state),
    TypesAlreadyOrdered: orderSelector.TypesAlreadyOrdered(state),
    OrderingInitialized: orderSelector.OrderingInitialized(state),
    Menu: orderSelector.Menu(state),
    Comment: orderSelector.Comment(state),
    orderType: orderSelector.orderType(state),
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    setUserData: (userData) => dispatch(setUserDataRequest(userData)),
    addMenuItem: (menuItem) => dispatch(addMenuItemRequest(menuItem)),
    remMenuItem: (menuItem) => dispatch(remMenuItemRequest(menuItem)),
    SetOrderingProcessInitialized: () => dispatch(setOrderingProcessInitRequest()),
    setMenu: (menu) => dispatch(setMenuRequest(menu)),
    setComment: (comment) => dispatch(setCommentRequest(comment)),
    submitOrder: (userId, orderType, order, comment) => dispatch(submitOrderRequest(userId, orderType, order, comment)),
    setOrderType: (orderType) => dispatch(setOrderTypeRequest(orderType)),
  }
}

class placeOrderPage extends React.Component {

  constructor(props) {
    super(props)
    this._handleType = this._handleType.bind(this);
  }

  componentWillMount() {

    const menuItems = [
      {
        Id: "33",
        FoodItem: "Gedesovs med sky og appelsiner",
        Description: "",
        Price: "50",
        OrderCount: "0"
      },
      {
        Id: "42",
        FoodItem: "Tartelletter med meeeeget sovs og hons",
        Description: "",
        Price: "50",
        OrderCount: "0"
      },
      {
        Id: "23",
        FoodItem: "Tauntaun med invoker indvolde",
        Description: "",
        Price: "50",
        OrderCount: "0"
      },
      {
        Id: "34",
        FoodItem: "KarateKid m. myagi-sovs",
        Description: "",
        Price: "50",
        OrderCount: "0"
      },
      {
        Id: "46",
        FoodItem: "Nemo og far",
        Description: "",
        Price: "50",
        OrderCount: "0"
      },
      {
        Id: "53",
        FoodItem: "Hannibal Lector Kage",
        Description: "",
        Price: "50",
        OrderCount: "0"
      },
    ]

    const testMenu = {
      ClosingTime: "",
      Date: "",
      Id: 235,
      menuItems: menuItems
    }

    const testUser = {
      UserId: "1337",
      UserName: "Kasper Alexander Olesen"
    }


    this.props.setMenu(testMenu)
    this.props.setUserData(testUser)

  }

  _handleType(e) {

    this.props.setOrderType(e.currentTarget.value)
  }

  componentDidMount() {
  }


  render() {

    return (
      <div className='standardPageLayout'>
        <div className='viewContent'>
          <div className='backNavigator'>
            <a href=''>Gå Tilbage</a>
          </div>
          <div>
            <label className='userNameTitle'>{this.props.UserName}</label>
          </div>


          <div className='pickupType'>
            <label>
              Sen Frokost
                <input type='radio' id='late' name='pickupType' value='late' onClick={this._handleType} disabled={this.props.TypesAlreadyOrdered.late} />
            </label>
            <label>
              Møde
                <input type='radio' id='meeting' name='pickupType' value='meeting' onClick={this._handleType} disabled={this.props.TypesAlreadyOrdered.meeting} />
            </label>
            <label>
              Med Hjem
                <input type='radio' id='home' name='pickupType' value='home' onClick={this._handleType} disabled={this.props.TypesAlreadyOrdered.home} />
            </label>
          </div>

          <MenuElement
            menuItems={this.props.Menu.menuItems}
            addMenuItem={this.props.addMenuItem}
          />


          <OrderElement
            order={this.props.Order}
            remMenuItem={this.props.remMenuItem}
            setComment={this.props.setComment} />

          <div className='bottomArea'>
            <button onClick={() => this.props.submitOrder(this.props.userId,
              this.props.orderType,
              this.props.Order,
              this.props.Comment)}
              disabled={this.props.Order.length === 0 || !this.props.orderType }
              className='submitBtn'
            >Opret Bestilling</button>
          </div>
        </div>
      </div>

    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(placeOrderPage)



