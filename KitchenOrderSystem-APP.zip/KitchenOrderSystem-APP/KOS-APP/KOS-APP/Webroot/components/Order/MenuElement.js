import React, { Component } from 'react'



class MenuElement extends React.Component {
  constructor(props) {
    super(props)
  }


  _renderMenu(menuItems, addMenuItem) {

    let completeMenu

    if (menuItems) {
      completeMenu = menuItems.map((menuItem) => {
        return (
          <div className='menuItem' key={menuItem.Id}>
            <div>{menuItem.FoodItem}</div>
            <button className='menuItemBtn' onClick={() => addMenuItem(menuItem)}>Tilføj</button>
          </div>
        )
      })
    }
    return completeMenu
  }

  render() {

    const { menuItems, addMenuItem } = this.props


    return (
      <div className='menu'>
        <label className='titleText'> Menu </label>
        {this._renderMenu(menuItems, addMenuItem)}
      </div>
    )
  }
}


export default MenuElement