import React, { Component } from 'react'



class OrderElement extends React.Component {
  constructor(props) {
    super(props)
  }

  count(arr) {
    return arr.reduce((counter, element) => {

      counter[element.Id] = ++counter[element.Id] || 1;
      return counter;
    }, {});
  }


  _renderOrder(order, remMenuItem) {

    let completeOrder
    let counts = this.count(order)

    if (order.length > 0) {
      completeOrder = order.map((orderItem) => {
        return (
          <div className='menuItem' key={orderItem.Id}>
            <div className='menuItemTitle'>{orderItem.FoodItem}</div>
            <div><b>{counts[orderItem.Id]}</b></div>
            <button className='menuItemBtn' onClick={() => remMenuItem(orderItem)}>Fjern</button>
          </div>
        )
      })
    } else {
      completeOrder = (
        <div>
          <label className='emptyOrderText'>Tilføj menu for at bestille...</label>
        </div>
      )
    }
    return completeOrder
  }

  _renderTextArea(order, setComment) {
    return (
      <textarea 
      cols='400' 
      rows='5' 
      maxLength='260' 
      className='orderComment'
      disabled={order.length === 0}
      placeholder='Skriv en kommentar til køkkenet...' 
      onBlur={(e) => setComment(e.target.value)} />
    )
  }



  render() {

    const { order, remMenuItem, setComment } = this.props
    return (

      <div className='order'>
        <div className='orderItemArea'>
          <label className='titleText'> Bestilling </label>
          {this._renderOrder(order, remMenuItem)}
        </div>
        <p> Kommentar </p>
        {this._renderTextArea(order, setComment)}
      </div>

    )
  }
}


export default OrderElement