﻿import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {Provider} from 'react-redux'

import rootSaga from '../sagas/rootSaga'
import comps from './allRenderings'
import configureStore from '../store/configureStore'

const store = configureStore()
store.runSaga(rootSaga)

var components = {};

for (var key in comps){
  if (comps.hasOwnProperty(key)) {
    setupComponent(key, comps[key])
  }
}

function setupComponent(key, Comp) {
  components[key] = class StoreEnabled extends Component {

    constructor(props){
      super(props)
    }

    render(){
      return (
        <Provider store={store}>
          <Comp {...this.props} />
        </Provider>
      )
    }
  }
}

module.exports = components;