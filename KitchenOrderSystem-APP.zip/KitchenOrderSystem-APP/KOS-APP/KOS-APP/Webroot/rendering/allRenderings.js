﻿
import empAppPage from '../components/EmployeePicker/empAppPage'
import placeOrderPage from '../components/Order/placeOrderPage'

let renderings = {}

function setupRendering(key, render) {
    renderings[key] = render
}

setupRendering('empAppPage', empAppPage)
setupRendering('placeOrderPage', placeOrderPage)


module.exports = renderings

