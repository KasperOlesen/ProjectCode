import iassign from 'immutable-assign'

const SET_USER_DATA = "SET_USER_DATA"
const ADD_MENU_ITEM = "ADD_MENU_ITEM"
const REM_MENU_ITEM = "REM_MENU_ITEM"
const SET_ORDERING_PROCESS_INIT = "SET_ORDERING_PROCESS_INIT"
const SET_MENU = "SET_MENU"
const SET_COMMENT = "SET_COMMENT"
const SET_ORDER_TYPE = "SET_ORDER_TYPE"

export function setUserData(userData) { return { type: SET_USER_DATA, userData } }
export function addMenuItem(menuItem) { return { type: ADD_MENU_ITEM, menuItem } }
export function remMenuItem(menuItem) { return { type: REM_MENU_ITEM, menuItem } }
export function setOrderingProcessInit() { return { type: SET_ORDERING_PROCESS_INIT } }
export function setMenu(menu) { return { type: SET_MENU, menu } }
export function setComment(comment) { return { type: SET_COMMENT, comment } }
export function setOrderType(orderType) { return { type: SET_ORDER_TYPE, orderType } }



iassign.freeze = false;

const initialState = {
  "UserId": "",
  "UserName": "",
  "Order": [],
  "orderType": "",
  "TypesAlreadyOrdered": {
    late: false,
    meeting: false,
    home: false
  },
  "OrderingInitialized": false,
  "Menu": {},
  "Comment": "",
}



function orderReducer(state = iassign(initialState, (s) => s), action) {
  switch (action.type) {
    case SET_USER_DATA:
      return iassign(
        state,
        function (original) {

          original.UserId = action.userData.UserId
          original.UserName = action.userData.UserName

          return original
        }
      )
    case ADD_MENU_ITEM:
      return iassign(
        state,
        function (original) {

          let tempArr = [...original.Order]
          tempArr.push(action.menuItem)

          original.Order = tempArr

          return original
        }
      )
    case REM_MENU_ITEM:
      return iassign(
        state,
        function (original) {

          let menuIndex = original.Order.findIndex(m => m.Id === action.menuItem.Id)
          let tempArr = [...original.Order]
          tempArr.splice(menuIndex, 1)

          original.Order = tempArr

          return original
        }
      )
    case SET_ORDERING_PROCESS_INIT:
      return iassign(
        state,
        function (original) {

          original.OrderingInitialized = true

          return original
        }
      )
    case SET_MENU:
      return iassign(
        state,
        function (original) {

          original.Menu = action.menu

          return original
        }
      )
    case SET_COMMENT:
      return iassign(
        state,
        function (original) {

          original.Comment = action.comment

          return original
        }
      )
    case SET_ORDER_TYPE:
      return iassign(
        state,
        function (original) {

          original.orderType = action.orderType

          return original
        }
      )

    default:
      return state
  }
}

export const orderSelector = {
  UserId: state => state.orderList.UserId,
  UserName: state => state.orderList.UserName,
  Order: state => state.orderList.Order,
  TypesAlreadyOrdered: state => state.orderList.TypesAlreadyOrdered,
  OrderingInitialized: state => state.orderList.OrderingInitialized,
  Menu: state => state.orderList.Menu,
  Comment: state => state.orderList.Comment,
  orderType: state => state.orderList.orderType,
}

export default orderReducer


