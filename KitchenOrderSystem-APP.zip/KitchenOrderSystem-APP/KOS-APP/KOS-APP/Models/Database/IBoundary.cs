﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models.Database
{
    public interface IBoundary
    {
        List<Entity.User> AddUsers(List<Entity.User> usersList);
        List<Entity.Order> ChangeOrderStatus(List<Entity.Order> orders);
        string CreateOrder(Entity.Order order, List<Entity.User> users);
        void CreateUser(Entity.User user);
        bool DeleteOrder(int orderId);
        List<Entity.User> GetAllUsers();
        Entity.Order GetLatestOrderByUserEmail(string email);
        Entity.Menu GetMenu(int menuId);
        Entity.Menu GetMenuByDate(DateTime date);
        Entity.MenuItem GetMenuItem(int id);
        List<Entity.MenuItem> GetMenuItemsByOrderId(int orderId);
        Entity.Order GetOrder(int orderId);
        List<Entity.Order> GetOrdersByDate(DateTime date);
        List<Entity.Order> GetOrdersByMonth(int month);
        List<Entity.Order> GetOrdersByUser(Entity.User user);
        List<Entity.Order> GetOrdersByUserEmail(string email);
        List<Entity.Order> GetOrdersToday();
        List<Entity.Order> GetOrdersTodayByUser(int userId);
        Entity.User GetUser(int id);
        Entity.User GetUserData(string email);
        List<Entity.User> GetUserOrdersByDate(DateTime date);
        List<Entity.User> RemoveUnlistedUsers(List<Entity.User> usersList);
        void SetDbContext(Entity.KitchenAppContext kitchenAppContext);
    }
}