﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using Castle.Core.Internal;
using WebApplication1.Services;

namespace WebApplication1.Models.Database
{
    public class Boundary : IBoundary
    {
        private Entity.KitchenAppContext _kitchenAppContext;
        public Boundary()
        {
            _kitchenAppContext = new Entity.KitchenAppContext();
        }

        public Boundary(Entity.KitchenAppContext kitchenAppContext)
        {
            _kitchenAppContext = kitchenAppContext;
        }

        public void SetDbContext(Entity.KitchenAppContext kitchenAppContext)
        {
            _kitchenAppContext = kitchenAppContext;
        }

        public List<Entity.Order> GetOrdersTodayByUser(int userId)
        {
            List<Entity.Order> orders = new List<Entity.Order>();
            DateTime today = DateTime.Today;
            using (var db = new Entity.KitchenAppContext())
            {
                if (db.Orders.Any(o =>
                    o.User.Id == userId && o.Date.Year == today.Year && o.Date.Month == today.Month &&
                    o.Date.Day == today.Day))
                {
                    orders = db.Orders.Include(o => o.User).Include(o => o.MenuItems).Where(o => o.User.Id == userId && o.Date.Year == today.Year && o.Date.Month == today.Month && o.Date.Day == today.Day).ToList();
                }

            }
            new Log<List<Entity.Order>>(orders).Read();
            return orders;
        }

        public List<Entity.Order> GetOrdersByUserEmail(string email)
        {
            List<Entity.Order> orders = new List<Entity.Order>();

            using (var db = new Entity.KitchenAppContext())
            {
                orders = db.Orders.Include(o => o.MenuItems).Include(o => o.User).Where(o => o.User.Email == email).ToList();
            }
            new Log<List<Entity.Order>>(orders).Read();
            return orders;
        }

        public List<Entity.Order> GetOrdersByMonth(int month)
        {
            List<Entity.Order> orders = new List<Entity.Order>();

            using (var db = new Entity.KitchenAppContext())
            {
                orders = db.Orders.Where(o => o.Date.Month == month).ToList();
            }
            new Log<List<Entity.Order>>(orders).Read();
            return orders;
        }

        public List<Entity.User> GetAllUsers()
        {
            List<Entity.User> users = new List<Entity.User>();
            //Get all users ordered by name A - Z
            using (var db = new Entity.KitchenAppContext())
            {
                var query = db.Users.Include(u => u.Orders).ToList();
                users = query;
            }
            new Log<List<Entity.User>>(users).Read();
            return users;
        }

        public List<Entity.User> GetUserOrdersByDate(DateTime date)
        {
            List<Entity.User> users = new List<Entity.User>();
            using (var db = new Entity.KitchenAppContext())
            {
                var query = db.Users
                            .Include(u => u.Orders).ToList();

                foreach (var user in query)
                {
                    users.Add(new Entity.User { Email = user.Email, Location = user.Location, Name = user.Name, Id = user.Id, Orders = user.Orders.Where(o => o.Date == date).ToList() });
                }
            }
            new Log<List<Entity.User>>(users).Read();
            return users;
        }

        public Entity.User GetUserData(string email)
        {
            Entity.User user = new Entity.User();

            List<Entity.Order> orders = new List<Entity.Order>();

            List<Entity.MenuItem> menuItems = new List<Entity.MenuItem>();

            using (var db = new Entity.KitchenAppContext())
            {
                user = db.Users.Include(u => u.Orders).Single(u => u.Email == email);

                foreach (var order in user.Orders)
                {
                    menuItems = db.Orders.Include(o => o.MenuItems).Single(o => o.Id == order.Id).MenuItems;
                    orders.Add(new Entity.Order
                    {
                        Comment = order.Comment,
                        Date = order.Date,
                        DeliveryType = order.DeliveryType,
                        Id = order.Id,
                        KitchenComment = order.KitchenComment,
                        MenuItems = menuItems,
                        Status = order.Status,
                        TotalPrice = order.TotalPrice,
                        User = user
                    });
                }
            }
            user.Orders = orders;
            return user;
        }

        public List<Entity.MenuItem> GetMenuItemsByOrderId(int orderId)
        {
            List<Entity.MenuItem> menuItems = new List<Entity.MenuItem>();

            using (var db = new Entity.KitchenAppContext())
            {
                var query = db.MenuItems.Where(m => m.Orders.Any(o => o.Id == orderId));

                foreach (var menuItem in query)
                {
                    menuItems.Add(menuItem);
                }
            }

            return menuItems;
        }

        public List<Entity.Order> GetOrdersByDate(DateTime date)
        {
            List<Entity.Order> orders = new List<Entity.Order>();

            using (var db = new Entity.KitchenAppContext())
            {
                var query = db.Orders.Include(o => o.User).Include(o => o.MenuItems).Where(o => o.Date == date).ToList();

                orders = query;
            }
            new Log<List<Entity.Order>>(orders).Read();
            return orders;
        }

        public List<Entity.Order> GetOrdersByUser(Entity.User user)
        {
            List<Entity.Order> orders = null;

            using (var db = new Entity.KitchenAppContext())
            {
                var query = db.Users.Find(user.Id);

                try
                {
                    orders = query.Orders;
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e);
                }
            }
            new Log<List<Entity.Order>>(orders).Read();
            return orders;
        }

        public List<Entity.Order> GetOrdersToday()
        {
            List<Entity.Order> orders;

            DateTime today = DateTime.Today;

            using (var db = new Entity.KitchenAppContext())
            {
                var query = db.Orders.Include(o => o.User).Include(o => o.MenuItems).Where(o => o.Date.Year == today.Year && o.Date.Month == today.Month && o.Date.Day == today.Day && o.Status == "Pending");
                orders = query.ToList();
            }
            new Log<List<Entity.Order>>(orders).Read();
            return orders;
        }

        public Entity.Order GetOrder(int orderId)
        {
            Entity.Order order;

            using (var db = new Entity.KitchenAppContext())
            {
                if (db.Orders.Any(o => o.Id == orderId))
                {
                    order = db.Orders.Include(o => o.MenuItems).SingleOrDefault(o => o.Id == orderId);
                }
                else
                {
                    order = new Entity.Order();
                }
            }
            new Log<Entity.Order>(order).Read();
            return order;
        }

        public Entity.Order GetLatestOrderByUserEmail(string email)
        {
            Entity.Order order;
            Entity.Order newOrder = new Entity.Order();
            using (var db = new Entity.KitchenAppContext())
            {
                //var query = db.Users
                //    .Include(u => u.Orders)

                //users = db.Users.Where(u => u.Email == email).ToList();
                var query = db.Users.Where(u => u.Email == email)
                    .Include(u => u.Orders);

                try
                {
                    //var q = query.First().Orders[0].MenuItems;
                    order = query.FirstOrDefault().Orders.OrderByDescending(o => o.Date).FirstOrDefault();
                    newOrder.Date = order.Date;
                    newOrder.Status = order.Status;
                    newOrder.Comment = order.Comment;
                    newOrder.KitchenComment = order.KitchenComment;
                    newOrder.DeliveryType = order.DeliveryType;
                    newOrder.Id = order.Id;
                    newOrder.MenuItems = order.MenuItems;
                    double sum = 0.0;
                    foreach (var item in newOrder.MenuItems)
                    {
                        sum += item.Price;
                    }
                    newOrder.TotalPrice = sum;
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e);
                }
            }
            new Log<Entity.Order>(newOrder).Read();
            return newOrder;
        }

        public void CreateUser(Entity.User user)
        {
            using (var db = new Entity.KitchenAppContext())
            {
                db.Users.Add(user);
                db.SaveChanges();
            }
            new Log<Entity.User>(user).Write();
        }


        public Entity.Menu GetMenuByDate(DateTime date)
        {
            Entity.Menu menu;
            using (var db = new Entity.KitchenAppContext())
            {
                var query = db.Menus
                    .Where(m => m.Date == date).Include(m => m.MenuItems).FirstOrDefault();
                menu = query;
            }
            new Log<Entity.Menu>(menu).Read();
            return menu;
        }

        public Entity.Menu GetMenu(int menuId)
        {
            Entity.Menu menu;
            using (var db = new Entity.KitchenAppContext())
            {
                var query = db.Menus
                    .Where(m => m.Id == menuId).Include(m => m.MenuItems).FirstOrDefault();
                menu = query;
            }
            new Log<Entity.Menu>(menu).Read();
            return menu;
        }


        public Entity.User GetUser(int id)
        {
            Entity.User user;
            using (var db = new Entity.KitchenAppContext())
            {
                user = db.Users.SingleOrDefault(u => u.Id == id);
            }
            new Log<Entity.User>(user).Read();
            return user;
        }


        public string CreateOrder(Entity.Order order, List<Entity.User> users)
        {

            //EmailServiceCustom es = new EmailServiceCustom();
            //double sum = 0;
            //foreach (var item in order.MenuItems)
            //{
            //    sum += item.Price;
            //}
            order.TotalPrice = 50;
            //DateTime today = DateTime.Today;
            bool result;

            using (var db = new Entity.KitchenAppContext())
            {

                List<Entity.MenuItem> mi = new List<Entity.MenuItem>();

                List<Entity.User> errorUsers = new ValidationHelpers().OrderTypeExistsForUsersToday(order, users);

                if (errorUsers.Count > 0)
                {
                    string error = "ERROR: ";

                    foreach (var u in errorUsers)
                    {
                        error += u.Name + ", ";
                    }

                    if (errorUsers.Count == 1)
                    {
                        error += "has already placed an order of type [" + order.DeliveryType + "] today!";
                    }
                    else
                    {
                        error += "have already placed an order of type [" + order.DeliveryType + "] today!";
                    }
                    return error;
                }

                foreach (var item in order.MenuItems)
                {
                    Entity.MenuItem menuItem = db.MenuItems.Single(m => m.Id == item.Id);
                    db.MenuItems.Single(m => m.Id == menuItem.Id).OrderCount += 1;
                    mi.Add(menuItem);
                }

                foreach (var user in users)
                {
                    //foreach (var item in order.MenuItems)
                    //{
                    //    db.MenuItems.First(m => m.Id == item.Id).Orders;
                    //}
                    db.Users.First(u => u.Id == user.Id).Orders.Add(new Entity.Order
                    {
                        Comment = order.Comment,
                        Date = order.Date,
                        DeliveryType = order.DeliveryType,
                        KitchenComment = order.KitchenComment,
                        MenuItems = mi,
                        TotalPrice = order.TotalPrice,
                        Status = "Pending"
                    });
                }
                //es.OrderNotification(user, GetLatestOrderByUserEmail(user.Email));

                result = db.SaveChanges() > 0;
            }
            new Log<Entity.Order>(order).Write();

            //es.SendAllEmails();
            return result ? "Order placed successfully" : "Failed to place order";
        }


        public List<Entity.Order> ChangeOrderStatus(List<Entity.Order> orders)
        {
            //User user;
            List<Entity.Order> pendingOrders = new List<Entity.Order>();
            using (var db = new Entity.KitchenAppContext())
            {
                foreach (var order in orders)
                {
                    if (order.Id != 0)
                    {

                        //user = db.Users.SingleOrDefault(u => u.Orders.Any(o => o.Id == orderId));
                        db.Orders.SingleOrDefault(x => x.Id == order.Id).Status = order.Status;
                        if (!order.KitchenComment.IsNullOrEmpty())
                        {
                            db.Orders.SingleOrDefault(x => x.Id == order.Id).KitchenComment = order.KitchenComment;
                        }
                        db.Orders.SingleOrDefault(x => x.Id == order.Id).TotalPrice = order.TotalPrice;
                        db.SaveChanges();
                        //order = db.Orders.Include(o => o.MenuItems).SingleOrDefault(o => o.Id == orderId);
                        pendingOrders = db.Orders.Where(x => x.Status == "Pending").Include(x => x.User).Include(x => x.MenuItems).ToList();
                    }
                }
            }

            //order = new Order();
            //EmailServiceCustom es = new EmailServiceCustom();
            //es.OrderStatusNotification(user, order);
            //es.SendAllEmails();
            return pendingOrders;
        }

        public Entity.MenuItem GetMenuItem(int id)
        {
            Entity.MenuItem menuItem;
            using (var db = new Entity.KitchenAppContext())
            {
                menuItem = db.MenuItems.SingleOrDefault(mi => mi.Id == id);
            }
            new Log<Entity.MenuItem>(menuItem).Read();
            return menuItem;
        }

        public bool DeleteOrder(int orderId)
        {
            bool result;
            using (var db = new Entity.KitchenAppContext())
            {
                var order = db.Orders.Single(o => o.Id == orderId);
                db.Orders.Remove(order);
                result = db.SaveChanges() > 0;
            }

            return result;
        }


        public List<Entity.User> AddUsers(List<Entity.User> usersList)
        {
            List<Entity.User> usersToAdd = new List<Entity.User>();

            using (var db = new Entity.KitchenAppContext())
            {
                List<Entity.User> usersDb = db.Users.ToList();
                foreach (var user in usersList)
                {
                    bool exists = usersDb.Any(userDb => user.Email == userDb.Email);

                    if (!exists)
                    {
                        usersToAdd.Add(user);
                    }
                }
                db.Users.AddRange(usersToAdd);
                db.SaveChanges();
            }
            return usersToAdd;
        }

        public List<Entity.User> RemoveUnlistedUsers(List<Entity.User> usersList)
        {
            List<Entity.User> usersToRemove = new List<Entity.User>();
            using (var db = new Entity.KitchenAppContext())
            {
                List<Entity.User> usersDb = db.Users.ToList();

                usersToRemove.AddRange(usersDb.Where(userDb => usersList.All(user => userDb.Email != user.Email)));

                db.Users.RemoveRange(usersToRemove);

                db.SaveChanges();
            }
            return usersToRemove;
        }

    }


}