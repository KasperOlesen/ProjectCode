﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WebApplication1.Models.Database
{
    public class ValidationHelpers
    {
        public List<Entity.User> OrderTypeExistsForUsersToday(Entity.Order order, List<Entity.User> users)
        {
            List<Entity.User> usersWithOrdersToday = new List<Entity.User>();
            DateTime today = DateTime.Today;

            using (var db = new Entity.KitchenAppContext())
            {
                foreach (var user in users)
                {
                    bool hasOrderedToday = false;

                    List<Entity.Order> orders = db.Orders.Where(o =>
                        o.Date.Year == today.Year && o.Date.Month == today.Month && o.Date.Day == today.Day &&
                        o.User.Id == user.Id).ToList();


                    if (orders.Count > 0)
                    {
                        foreach (var o in orders)
                        {
                            if (o.DeliveryType == order.DeliveryType)
                            {
                                hasOrderedToday = true;
                            }
                        }

                        if (hasOrderedToday)
                        {
                            usersWithOrdersToday.Add(user);
                        }
                    }
                }
            }
            return usersWithOrdersToday;
        }
    }
}