﻿using System.Collections.Generic;

namespace WebApplication1.Models
{
    public class OrderStatusViewModel
    {
        public List<OrderViewModel> OrderViewModels { get; set; }
    }
}