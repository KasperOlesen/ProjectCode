﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models
{
    public class OrderMenuViewModel
    {
        public MenuViewModel Menu { get; set; }
        public List<OrderViewModel> Orders { get; set; }
    }

    public static class OrderMenuExtensions
    {
        public static List<MenuItemViewModel> ToMenuItemViewModels(this string ids)
        {
            string[] splitIds = ids.Split(',');

            List<MenuItemViewModel> menuItems = new List<MenuItemViewModel>();

            foreach (var id in splitIds)
            {
                menuItems.Add(new MenuItemViewModel
                {
                    Id = Int32.Parse(id)
                });
            }

            return menuItems;
        }

        public static List<UserViewModel> ToUserViewModels(this string ids)
        {
            string[] splitIds = ids.Split(',');

            List<UserViewModel> users = new List<UserViewModel>();

            foreach (var id in splitIds)
            {
                users.Add(new UserViewModel
                {
                    Id = Int32.Parse(id)
                });
            }

            return users;
        }
    }
}