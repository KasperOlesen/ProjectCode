﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models
{
    public class MenuViewModel
    {
        public int Id { get; set; }
        public DateTime ClosingTime { get; set; }
        public DateTime Date { get; set; }
        public List<MenuItemViewModel> MenuItems { get; set; }

        public override string ToString()
        {
            return $"Id: {Id}, ClosingTime: {ClosingTime}, Date: {Date}, MenuItems: {MenuItems}";
        }
    }
}