﻿namespace WebApplication1.Models
{
    public class MenuItemViewModel
    {
        public int Id { get; set; }
        public string FoodItem { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
        public int OrderCount { get; set; }
        public override string ToString()
        {
            return $"Id: {Id}, FoodItem: {FoodItem}, Description: {Description}, Price: {Price}";
        }
    }
}