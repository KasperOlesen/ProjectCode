﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models
{
    public class OrderViewModel
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public string DeliveryType { get; set; }
        public string Status { get; set; }
        public string Comment { get; set; }
        public string KitchenComment { get; set; }
        public double Price { get; set; }
        public List<UserViewModel> Users { get; set; }
        public List<MenuItemViewModel> MenuItems { get; set; }

        public override string ToString()
        {
            return $"Id: {Id}, Date: {Date}, DeliveryType: {DeliveryType}, Status: {Status}, Comment: {Comment}, KitchenComment: {KitchenComment}, Price: {Price}, Users: {Users}, MenuItems: {MenuItems}";
        }
    }
}