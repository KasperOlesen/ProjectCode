﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using WebApplication1.Models.Database;

namespace WebApplication1.Models.DAL
{
    public class UserRepository : IUserRepository, IDisposable
    {
        private Entity.KitchenAppContext context;

        private bool disposed = false;

        public UserRepository(Entity.KitchenAppContext context)
        {
            this.context = context;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public IEnumerable<Entity.User> GetUsers()
        {
            return context.Users.ToList();
        }

        public Entity.User GetUserById(int userId)
        {
            return context.Users.Find(userId);
        }

        public void InsertUser(Entity.User user)
        {
            context.Users.Add(user);
        }

        public void DeleteUser(int userId)
        {
            Entity.User user = context.Users.Find(userId);

            if (user != null) context.Users.Remove(user);
        }

        public void UpdateUser(Entity.User user)
        {
            context.Entry(user).State = EntityState.Modified;
        }

        public void Save()
        {
            context.SaveChanges();
        }


    }
}