﻿using System;
using WebApplication1.Models.Database;

namespace WebApplication1.Models.DAL
{
    public class UnitOfWork : IDisposable
    {
        private Entity.KitchenAppContext context = new Entity.KitchenAppContext();
        private GenericRepository<Entity.User> userRepository;
        private GenericRepository<Entity.Menu> menuRepository;
        private GenericRepository<Entity.Order> orderRepository;
        private GenericRepository<Entity.MenuItem> menuItemRepository;

        private bool disposed = false;

        public GenericRepository<Entity.User> UserRepository
        {
            get
            {
                return this.userRepository ?? new GenericRepository<Entity.User>(context);
                
            }
        }

        public GenericRepository<Entity.Menu> MenuRepository
        {
            get
            {
                return this.menuRepository ?? new GenericRepository<Entity.Menu>(context);

            }
        }

        public GenericRepository<Entity.Order> OrderRepository
        {
            get
            {
                return this.orderRepository ?? new GenericRepository<Entity.Order>(context);

            }
        }

        public GenericRepository<Entity.MenuItem> MenuItemRepository
        {
            get
            {
                return this.menuItemRepository ?? new GenericRepository<Entity.MenuItem>(context);

            }
        }

        public void Save()
        {
            context.SaveChanges();
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}