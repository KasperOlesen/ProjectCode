﻿using System;

namespace WebApplication1.Services
{
    public class Log<T>
    {
        private readonly T _value;
        private string _today;
        public Log(T t)
        {
            this._value = t;
            this._today = DateTime.Today.ToShortDateString();
        }

        public void Write()
        {
            //using (TextWriter tsw = new StreamWriter(@"C:\" + this._today + ".txt", true))
            //{
            //    tsw.WriteLine(DateTime.Now + " [WRITE] " + this._value.ToString() + " Type: " + this._value.GetType());
            //}
        }
        public void Read()
        {
            //using (TextWriter tsw = new StreamWriter(@"C:\" + this._today + ".txt", true))
            //{
            //    tsw.WriteLine(DateTime.Now + " [READ] " + this._value.ToString() + " Type: " + this._value.GetType());
            //}
        }

        public void Error()
        {
            //using (TextWriter tsw = new StreamWriter(@"C:\" + this._today + ".txt", true))
            //{
            //    tsw.WriteLine(DateTime.Now + " [ERROR] " + this._value.ToString() + " Type: " + this._value.GetType());
            //}
        }
    }
}