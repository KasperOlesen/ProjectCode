﻿using System;
using System.Collections.Generic;
using System.Linq;
using WebApplication1.Models;
using WebApplication1.Models.Database;
using WebApplication1.Models.DAL;

namespace WebApplication1.Services
{
    public class MapperServiceDAL
    {
        private readonly UnitOfWork _unitOfWork = new UnitOfWork();
        private readonly MapperHelper _helper = new MapperHelper();

        public List<UserViewModel> Users()
        {
            var dbUsers = _unitOfWork.UserRepository.Get();
            List<UserViewModel> users = new List<UserViewModel>();

            foreach (var user in dbUsers)
            {
                users.Add(new UserViewModel
                {
                    Email = user.Email,
                    Id = user.Id,
                    ImageUrl = user.ImageUrl,
                    Location = user.Location,
                    Name = user.Name
                });
            }

            return users;
        }

        public MenuViewModel TodaysMenu()
        {
            MenuViewModel todaysMenu;
            DateTime today = DateTime.Today;
            var menu = _unitOfWork.MenuRepository.Get(x => x.Date.Year == today.Year && x.Date.Month == today.Month && x.Date.Day == today.Day, includeProperties: "MenuItems").Single();

            if (menu != null)
            {
                todaysMenu = new MenuViewModel
                {
                    Id = menu.Id,
                    ClosingTime = menu.ClosingTime,
                    Date = menu.Date,
                    MenuItems = new List<MenuItemViewModel>()
                };

                foreach (var menuItem in menu.MenuItems)
                {
                    todaysMenu.MenuItems.Add(new MenuItemViewModel
                    {
                        Description = menuItem.Description,
                        FoodItem = menuItem.FoodItem,
                        Id = menuItem.Id,
                        Price = menuItem.Price
                    });
                }
            }
            else
            {
                todaysMenu = new MenuViewModel();
            }
            return todaysMenu;
        }

        //public OrderMenuViewModel OrderMenu(int userId)
        //{
        //    DateTime today = DateTime.Today;
        //    var menu = _unitOfWork.MenuRepository.Get(o => o.Date == today).FirstOrDefault();
        //    //Entity.Menu menu = bd.GetMenuByDate(DateTime.Today);
        //    var orders = _unitOfWork.OrderRepository.Get(o =>
        //        o.User.Id == userId && o.Date.Year == today.Year && o.Date.Month == today.Month &&
        //        o.Date.Day == today.Day);
        //    var order = new Entity.Order();
        //    if (orders.Any())
        //    {
        //        order = _unitOfWork.OrderRepository
        //            .Get(
        //                o => o.User.Id == userId && o.Date.Year == today.Year && o.Date.Month == today.Month &&
        //                     o.Date.Day == today.Day, includeProperties: "MenuItems, User").Single();
        //    }
        //    OrderMenuViewModel omvm = new OrderMenuViewModel();

        //    if (order.Status != null)
        //    {

        //        omvm.Order = new OrderViewModel
        //        {
        //            Id = order.Id,
        //            Comment = order.Comment,
        //            Date = order.Date,
        //            DeliveryType = order.DeliveryType,
        //            KitchenComment = order.KitchenComment,
        //            Status = order.Status,
        //            MenuItems = _helper.MenuItemsToMenuItemViewModels(order.MenuItems),
        //            Price = order.TotalPrice,
        //            Users = _helper.UsersToUserViewModels(new List<Entity.User> { order.User })
        //        };
        //    }
        //    else
        //    {
        //        if (menu != null)
        //        {
        //            omvm.Menu = new MenuViewModel
        //            {
        //                Date = menu.Date,
        //                ClosingTime = menu.ClosingTime,
        //                Id = menu.Id,
        //                MenuItems = _helper.MenuItemsToMenuItemViewModels(menu.MenuItems)
        //            };
        //        }
        //        else
        //        {
        //            omvm.Menu = new MenuViewModel
        //            {
        //                MenuItems = new List<MenuItemViewModel> { new MenuItemViewModel() }
        //            };
        //        }

        //    }

        //    return omvm;
        //}

        public List<OrderViewModel> OrdersByUserEmail(string email)
        {
            List<OrderViewModel> orderViewModels = new List<OrderViewModel>();

            List<Entity.Order> orders = _unitOfWork.OrderRepository
                .Get(o => o.User.Email == email, includeProperties: "MenuItems, User").ToList();

            foreach (var order in orders)
            {
                orderViewModels.Add(new OrderViewModel
                {
                    Comment = order.Comment,
                    Date = order.Date,
                    DeliveryType = order.DeliveryType,
                    Id = order.Id,
                    KitchenComment = order.KitchenComment,
                    Price = order.TotalPrice,
                    Status = order.Status,
                    MenuItems = _helper.MenuItemsToMenuItemViewModels(order.MenuItems),
                    Users = _helper.UsersToUserViewModels(new List<Entity.User> { order.User })
                });
            }

            return orderViewModels;
        }

        public List<OrderViewModel> AllOrders()
        {

            var orders = _unitOfWork.OrderRepository.Get();
            List<OrderViewModel> ovms = new List<OrderViewModel>();

            foreach (var order in orders)
            {

                ovms.Add(new OrderViewModel { KitchenComment = order.KitchenComment, Id = order.Id, Comment = order.Comment, Date = order.Date, DeliveryType = order.DeliveryType, MenuItems = _helper.MenuItemsToMenuItemViewModels(order.MenuItems), Status = order.Status, Price = order.TotalPrice, Users = _helper.UsersToUserViewModels(new List<Entity.User> { order.User }) });
            }

            return ovms;
        }

        public List<OrderViewModel> OrdersToday()
        {
            DateTime today = DateTime.Today;
            var orders = _unitOfWork.OrderRepository.Get(o => o.Date.Year == today.Year && o.Date.Month == today.Month && o.Date.Day == today.Day, includeProperties: "MenuItems, User");
            List<OrderViewModel> ordersToday = new List<OrderViewModel>();

            foreach (var order in orders)
            {
                ordersToday.Add(new OrderViewModel
                {
                    Comment = order.Comment,
                    Date = order.Date,
                    DeliveryType = order.DeliveryType,
                    Id = order.Id,
                    KitchenComment = order.KitchenComment,
                    MenuItems = _helper.MenuItemsToMenuItemViewModels(order.MenuItems),
                    Price = order.TotalPrice,
                    Status = order.Status,
                    Users = _helper.UsersToUserViewModels(new List<Entity.User> { order.User })
                });
            }

            return ordersToday;
        }
        public List<OrderViewModel> OrderToday(int userId)
        {
            DateTime today = DateTime.Today;
            var orders = _unitOfWork.OrderRepository.Get(o => o.Date.Year == today.Year && o.Date.Month == today.Month && o.Date.Day == today.Day && o.User.Id == userId, includeProperties: "MenuItems, User");
            List<OrderViewModel> ordersToday = new List<OrderViewModel>();

            foreach (var order in orders)
            {
                ordersToday.Add(new OrderViewModel
                {
                    Comment = order.Comment,
                    Date = order.Date,
                    DeliveryType = order.DeliveryType,
                    Id = order.Id,
                    KitchenComment = order.KitchenComment,
                    MenuItems = _helper.MenuItemsToMenuItemViewModels(order.MenuItems),
                    Price = order.TotalPrice,
                    Status = order.Status,
                    Users = _helper.UsersToUserViewModels(new List<Entity.User> { order.User })
                });
            }

            return ordersToday;
        }

        public List<MenuItemViewModel> MenuItems(int orderId)
        {
            var menuItems = _unitOfWork.MenuItemRepository.Get(m => m.Orders.Any(o => o.Id == orderId));
            List<MenuItemViewModel> menuItemViewModels = new List<MenuItemViewModel>();

            foreach (var item in menuItems)
            {
                menuItemViewModels.Add(new MenuItemViewModel
                {
                    Description = item.Description,
                    FoodItem = item.FoodItem,
                    Id = item.Id,
                    OrderCount = item.OrderCount,
                    Price = item.Price
                });
            }
            return menuItemViewModels;
        }

        public string CreateOrder(OrderViewModel ovm)
        {

            Entity.Order order = new Entity.Order
            {
                Date = DateTime.Now,
                Comment = ovm.Comment,
                DeliveryType = ovm.DeliveryType,
                Status = "Pending"
            };

            double sum = 0;

            
            List<Entity.MenuItem> menuItems = new List<Entity.MenuItem>();
            foreach (var item in ovm.MenuItems)
            {
                Entity.MenuItem mi = _unitOfWork.MenuItemRepository.GetByID(item.Id);
                menuItems.Add(mi);
                sum += mi.Price;
            }
            order.MenuItems = menuItems;
            order.TotalPrice = sum;
            List<Entity.User> users = new List<Entity.User>();
            foreach (var user in ovm.Users)
            {
                users.Add(_unitOfWork.UserRepository.GetByID(user.Id));
            }

            List<Entity.User> errorUsers = _helper.OrderTypeExistsForUsersToday(order, users, _unitOfWork);

            if (errorUsers.Count > 0)
            {
                string error = "ERROR: ";

                foreach (var u in errorUsers)
                {
                    error += u.Name + ", ";
                }

                if (errorUsers.Count == 1)
                {
                    error += "has already placed an order of type [" + order.DeliveryType + "] today!";
                }
                else
                {
                    error += "have already placed an order of type [" + order.DeliveryType + "] today!";
                }
                return error;
            }
            foreach (var user in users)
            {
                order.User = user;
                _unitOfWork.OrderRepository.Insert(order);
                _unitOfWork.Save();
            }
            return "Success";
        }

        public string CreateMenu(MenuViewModel menu)
        {
            DateTime today = DateTime.Today;
            EmailServiceCustom esc = new EmailServiceCustom();
            List<Entity.MenuItem> menuItemsDb = new List<Entity.MenuItem>();
            foreach (var item in menu.MenuItems)
            {
                menuItemsDb.Add(new Entity.MenuItem { Description = item.Description, Id = item.Id, FoodItem = item.FoodItem, Price = item.Price });
            }

            var menuToday = _unitOfWork.MenuRepository
                .Get(x => x.Date.Year == today.Year && x.Date.Month == today.Month && x.Date.Day == today.Day,
                    includeProperties: "MenuItems").Single();

            esc.SendAllEmails();
            if (menuToday != null)
            {
                var orders = _unitOfWork.OrderRepository
                    .Get(x => x.Date.Year == today.Year && x.Date.Month == today.Month && x.Date.Day == today.Day,
                        includeProperties: "MenuItems, User");

                foreach (var order in orders)
                {
                    esc.OrderCancelledNotification(order);
                }
                _unitOfWork.MenuRepository.Delete(menuToday);
            }

            
            _unitOfWork.MenuRepository.Insert(new Entity.Menu{Date = today, ClosingTime = menu.ClosingTime, MenuItems = menuItemsDb});
            _unitOfWork.Save();

            return "Menu created";
        }

    }



    public class MapperHelper
    {
        public List<MenuItemViewModel> MenuItemsToMenuItemViewModels(List<Entity.MenuItem> menuItems)
        {
            List<MenuItemViewModel> mivm = new List<MenuItemViewModel>();

            foreach (var item in menuItems)
            {
                mivm.Add(new MenuItemViewModel
                {
                    Description = item.Description,
                    FoodItem = item.FoodItem,
                    Id = item.Id,
                    Price = item.Price,
                    OrderCount = item.OrderCount
                });
            }
            return mivm;
        }

        public List<UserViewModel> UsersToUserViewModels(List<Entity.User> users)
        {
            List<UserViewModel> uvm = new List<UserViewModel>();

            foreach (var item in users)
            {
                uvm.Add(new UserViewModel
                {
                    Name = item.Name,
                    Email = item.Email,
                    Id = item.Id,
                    ImageUrl = item.ImageUrl,
                    Location = item.Location
                });
            }
            return uvm;
        }

        public List<OrderViewModel> OrdersToOrderViewModels(List<Entity.Order> orders)
        {
            List<OrderViewModel> ovm = new List<OrderViewModel>();

            foreach (var item in orders)
            {
                ovm.Add(new OrderViewModel
                {
                    Comment = item.Comment,
                    Date = item.Date,
                    DeliveryType = item.DeliveryType,
                    Id = item.Id,
                    KitchenComment = item.KitchenComment,
                    Price = item.TotalPrice,
                    Status = item.Status
                });
            }

            return ovm;
        }

        public List<Entity.User> OrderTypeExistsForUsersToday(Entity.Order order, List<Entity.User> users, UnitOfWork unitOfWork)
        {
            List<Entity.User> usersWithOrdersToday = new List<Entity.User>();
            DateTime today = DateTime.Today;


            foreach (var user in users)
            {
                bool hasOrderedToday = false;

                List<Entity.Order> orders = unitOfWork.OrderRepository.Get(o =>
                    o.Date.Year == today.Year && o.Date.Month == today.Month && o.Date.Day == today.Day &&
                    o.User.Id == user.Id).ToList();

                if (orders.Count > 0)
                {
                    foreach (var o in orders)
                    {
                        if (o.DeliveryType == order.DeliveryType)
                        {
                            hasOrderedToday = true;
                        }
                    }

                    if (hasOrderedToday)
                    {
                        usersWithOrdersToday.Add(user);
                    }
                }
            }
            return usersWithOrdersToday;
        }
    }
}