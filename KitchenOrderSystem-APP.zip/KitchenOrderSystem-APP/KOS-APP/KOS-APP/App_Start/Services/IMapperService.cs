﻿using System.Collections.Generic;
using WebApplication1.Models;
using WebApplication1.Models.Database;

namespace WebApplication1.Services
{
    public interface IMapperService
    {
        List<UserViewModel> CreateUsersFromEmployeeApi(string url);
        MenuViewModel GetMenu(int menuId);
        List<MenuItemViewModel> MenuItems(int orderId);
        List<MenuItemViewModel> MenuItemsToMenuItemViewModels(List<Entity.MenuItem> menuItems);
        OrderMenuViewModel OrderMenu(int userId);
        List<OrderViewModel> OrdersByUserEmail(string email);
        List<OrderViewModel> OrdersToday();
        List<OrderViewModel> OrdersToOrderViewModels(List<Entity.Order> orders);
        List<OrderViewModel> OrderToday(int userId);
        List<UserViewModel> RemoveUnlistedUsers(string url);
        MenuViewModel TodaysMenu();
        UserViewModel User(int userId);
        UserViewModel UserData(string email);
        List<UserViewModel> Users();
        List<Employee> UsersAsEmployees();
        List<UserViewModel> UsersToUserViewModels(List<Entity.User> users);
    }
}