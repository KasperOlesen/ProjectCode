﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using WebApplication1.Models;
using WebApplication1.Models.Database;

namespace WebApplication1.Services
{
    public class MapperService : IMapperService
    {
        //private UnitOfWork unitOfWork = new UnitOfWork();
        private readonly IBoundary _bd;

        public MapperService(IBoundary bd)
        {
            this._bd = bd;
        }

        public MapperService()
        {
            this._bd = new Boundary();
        }


        public List<UserViewModel> CreateUsersFromEmployeeApi(string url)
        {
            List<Employee> emps = JsonConvert.DeserializeObject<List<Employee>>(new ApiService().Get(url));
            List<Entity.User> usersList = emps.Select(emp => new Entity.User
            {
                Email = emp.Email,
                ImageUrl = emp.OriginalImageFilePath,
                Location = "Meldahlsgade, Copenhagen",
                Name = emp.DisplayName
            })
                .ToList();

            List<Entity.User> users = _bd.AddUsers(usersList);

            List<UserViewModel> uvms = UsersToUserViewModels(users);

            return uvms;
        }

        public List<UserViewModel> RemoveUnlistedUsers(string url)
        {
            List<Employee> emps = JsonConvert.DeserializeObject<List<Employee>>(new ApiService().Get(url));
            List<Entity.User> usersList = emps.Select(emp => new Entity.User
            {
                Email = emp.Email
            })
                .ToList();

            List<Entity.User> users = _bd.RemoveUnlistedUsers(usersList);

            List<UserViewModel> uvms = UsersToUserViewModels(users);

            return uvms;
        }

        public List<Employee> UsersAsEmployees()
        {
            List<Entity.User> users = _bd.GetAllUsers();
            List<Employee> employees = new List<Employee>();
            foreach (var user in users)
            {
                employees.Add(new Employee
                {
                    DisplayName = user.Name,
                    Department = user.Location,
                    //OriginalImageFilePath = user.ImageUrl,
                    Email = user.Email
                });
            }
            return employees;
        }

        public OrderMenuViewModel OrderMenu(int userId)
        {
            Entity.Menu menu = _bd.GetMenuByDate(DateTime.Today);
            List<Entity.Order> orders = _bd.GetOrdersTodayByUser(userId);
            OrderMenuViewModel omvm = new OrderMenuViewModel
            {
                Orders = new List<OrderViewModel>()
            };

            foreach (var order in orders)
            {
                if (order.Status != null)
                {
                    omvm.Orders.Add(new OrderViewModel
                    {
                        Id = order.Id,
                        Comment = order.Comment,
                        Date = order.Date,
                        DeliveryType = order.DeliveryType,
                        KitchenComment = order.KitchenComment,
                        Status = order.Status,
                        MenuItems = MenuItemsToMenuItemViewModels(order.MenuItems),
                        Price = order.TotalPrice,
                        Users = UsersToUserViewModels(new List<Entity.User> { order.User })
                    });
                }
            }

            if (omvm.Orders.Any()) return omvm;
            if (menu != null)
            {
                omvm.Menu = new MenuViewModel
                {
                    Date = menu.Date,
                    ClosingTime = menu.ClosingTime,
                    Id = menu.Id,
                    MenuItems = MenuItemsToMenuItemViewModels(menu.MenuItems)
                };
            }
            else
            {
                omvm.Menu = new MenuViewModel
                {
                    MenuItems = new List<MenuItemViewModel> { new MenuItemViewModel() }
                };
            }


            return omvm;
        }
        public MenuViewModel TodaysMenu()
        {
            MenuViewModel todaysMenu;
            Entity.Menu menu = _bd.GetMenuByDate(DateTime.Today);

            if (menu != null)
            {
                todaysMenu = new MenuViewModel
                {
                    Id = menu.Id,
                    ClosingTime = menu.ClosingTime,
                    Date = menu.Date,
                    MenuItems = new List<MenuItemViewModel>()
                };

                foreach (var menuItem in menu.MenuItems)
                {
                    todaysMenu.MenuItems.Add(new MenuItemViewModel
                    {
                        Description = menuItem.Description,
                        FoodItem = menuItem.FoodItem,
                        Id = menuItem.Id,
                        Price = menuItem.Price
                    });
                }
                todaysMenu.MenuItems = todaysMenu.MenuItems.OrderByDescending(x => x.Id).Reverse().ToList();
            }
            else
            {
                todaysMenu = new MenuViewModel();
            }


            return todaysMenu;
        }

        public List<OrderViewModel> OrdersByUserEmail(string email)
        {
            List<Entity.Order> orders = _bd.GetOrdersByUserEmail(email);

            return orders.Select(order => new OrderViewModel
            {
                Comment = order.Comment,
                Date = order.Date,
                DeliveryType = order.DeliveryType,
                Id = order.Id,
                KitchenComment = order.KitchenComment,
                Price = order.TotalPrice,
                Status = order.Status,
                MenuItems = MenuItemsToMenuItemViewModels(order.MenuItems),
                Users = UsersToUserViewModels(new List<Entity.User> { order.User })
            })
                .ToList();
        }

        public MenuViewModel GetMenu(int menuId)
        {
            MenuViewModel todaysMenu;
            Entity.Menu menu = _bd.GetMenu(menuId);
            if (menu != null)
            {
                todaysMenu = new MenuViewModel
                {
                    Id = menu.Id,
                    Date = menu.Date,
                    MenuItems = new List<MenuItemViewModel>()
                };

                foreach (var menuItem in menu.MenuItems)
                {
                    todaysMenu.MenuItems.Add(new MenuItemViewModel
                    {
                        Description = menuItem.Description,
                        FoodItem = menuItem.FoodItem,
                        Id = menuItem.Id,
                        Price = menuItem.Price
                    });
                }
            }
            else
            {
                todaysMenu = new MenuViewModel();
            }
            return todaysMenu;
        }

        public List<UserViewModel> Users()
        {
            List<Entity.User> dbUsers = _bd.GetAllUsers();

            return dbUsers.Select(user => new UserViewModel
            {
                Email = user.Email,
                Id = user.Id,
                ImageUrl = user.ImageUrl,
                Location = user.Location,
                Name = user.Name
            })
                .OrderByDescending(x => x.Name).Reverse().ToList();
        }



        public UserViewModel User(int userId)
        {
            Entity.User user = _bd.GetUser(userId);
            return user != null ? new UserViewModel { Email = user.Email, Id = user.Id, Name = user.Name, Location = user.Location, ImageUrl = user.ImageUrl } : new UserViewModel();
        }


        public List<MenuItemViewModel> MenuItemsToMenuItemViewModels(List<Entity.MenuItem> menuItems)
        {
            return menuItems.Select(item => new MenuItemViewModel
            {
                Description = item.Description,
                FoodItem = item.FoodItem,
                Id = item.Id,
                Price = item.Price,
                OrderCount = item.OrderCount
            })
                .ToList();
        }

        public List<UserViewModel> UsersToUserViewModels(List<Entity.User> users)
        {
            return users.Select(item => new UserViewModel
            {
                Name = item.Name,
                Email = item.Email,
                Id = item.Id,
                ImageUrl = item.ImageUrl,
                Location = item.Location
            })
                .ToList();
        }

        public List<OrderViewModel> OrdersToOrderViewModels(List<Entity.Order> orders)
        {
            return orders.Select(item => new OrderViewModel
            {
                Comment = item.Comment,
                Date = item.Date,
                DeliveryType = item.DeliveryType,
                Id = item.Id,
                KitchenComment = item.KitchenComment,
                Price = item.TotalPrice,
                Status = item.Status,
                MenuItems = MenuItemsToMenuItemViewModels(item.MenuItems)
            })
                .ToList();
        }

        public List<OrderViewModel> OrdersToday()
        {

            List<Entity.Order> orders = _bd.GetOrdersToday();

            return orders.Select(order => new OrderViewModel
            {
                Comment = order.Comment,
                Date = order.Date,
                DeliveryType = order.DeliveryType,
                Id = order.Id,
                KitchenComment = order.KitchenComment,
                MenuItems = MenuItemsToMenuItemViewModels(order.MenuItems),
                Price = order.TotalPrice,
                Status = order.Status,
                Users = UsersToUserViewModels(new List<Entity.User> { order.User })
            })
                .ToList();
        }

        public List<OrderViewModel> OrderToday(int userId)
        {
            List<Entity.Order> orders = _bd.GetOrdersTodayByUser(userId);
            List<OrderViewModel> ovms = new List<OrderViewModel>();

            foreach (var order in orders)
            {
                ovms.Add(new OrderViewModel
                {
                    Comment = order.Comment,
                    Date = order.Date,
                    DeliveryType = order.DeliveryType,
                    Id = order.Id,
                    KitchenComment = order.KitchenComment,
                    MenuItems = MenuItemsToMenuItemViewModels(order.MenuItems),
                    Price = order.TotalPrice,
                    Status = order.Status,
                    Users = UsersToUserViewModels(new List<Entity.User> { order.User })
                });
            }

            return ovms;
        }

        public UserViewModel UserData(string email)
        {
            Entity.User user = _bd.GetUserData(email);
            UserViewModel uvm = new UserViewModel
            {
                Email = user.Email,
                Id = user.Id,
                ImageUrl = user.ImageUrl,
                Location = user.Location,
                Name = user.Name,
                Orders = OrdersToOrderViewModels(user.Orders)
            };

            return uvm;
        }

        public List<MenuItemViewModel> MenuItems(int orderId)
        {
            List<Entity.MenuItem> menuItems = _bd.GetMenuItemsByOrderId(orderId);

            return menuItems.Select(item => new MenuItemViewModel
            {
                Description = item.Description,
                FoodItem = item.FoodItem,
                Id = item.Id,
                OrderCount = item.OrderCount,
                Price = item.Price
            })
                .ToList();
        }

    }

    public class MapEntity
    {

        private readonly Boundary _bd;

        public MapEntity(Boundary bd)
        {
            this._bd = bd;
        }

        public MapEntity()
        {
            this._bd = new Boundary();
        }
        public string CreateOrder(OrderViewModel ovm)
        {

            Entity.Order order = new Entity.Order
            {
                Date = DateTime.Now,
                Comment = ovm.Comment,
                DeliveryType = ovm.DeliveryType,
                Status = "Pending"

            };

            Entity.Menu menu = _bd.GetMenuByDate(DateTime.Today);

            List<Entity.MenuItem> menuItems = (from item in menu.MenuItems from mi in ovm.MenuItems where item.Id == mi.Id select item).ToList();

            order.MenuItems = menuItems;

            List<Entity.User> users = ovm.Users.Select(user => _bd.GetUser(user.Id)).ToList();

            string result = "Failed to create order";

            if (menuItems.Count > 0)
            {
                result = _bd.CreateOrder(order, users);
            }

            return result;
        }
        //public string CreateOrder(OrderMenuViewModel omvm)
        //{
        //    Entity.Order order = new Entity.Order
        //    {
        //        Date = DateTime.Now,
        //        Comment = omvm.Order.Comment,
        //        DeliveryType = omvm.Order.DeliveryType,
        //        Status = "Pending"

        //    };
        //    List<Entity.MenuItem> menuItems = omvm.Order.MenuItems.Select(item => _bd.GetMenuItem(item.Id)).ToList();

        //    order.MenuItems = menuItems;
        //    List<Entity.User> users = new List<Entity.User>();
        //    foreach (var user in omvm.Order.Users)
        //    {
        //        users.Add(_bd.GetUser(user.Id));
        //    }

        //    string result = _bd.CreateOrder(order, users);

        //    return result;
        //}

        public OrderStatusViewModel ChangeOrderStatus(OrderStatusViewModel osvm)
        {
            MapperService ms = new MapperService();
            OrderStatusViewModel pendingOrdersViewModel = new OrderStatusViewModel();
            pendingOrdersViewModel.OrderViewModels = new List<OrderViewModel>();
            List<Entity.Order> orders = new List<Entity.Order>();

            foreach (var ovm in osvm.OrderViewModels)
            {
                orders.Add(new Entity.Order
                {
                    Id = ovm.Id,
                    KitchenComment = ovm.KitchenComment,
                    Status = ovm.Status,
                    TotalPrice = ovm.Price
                });
            }

            List<Entity.Order> pendingOrders = _bd.ChangeOrderStatus(orders);

            foreach (var pendingOrder in pendingOrders)
            {
                pendingOrdersViewModel.OrderViewModels.Add(new OrderViewModel
                {
                    Comment = pendingOrder.Comment,
                    Date = pendingOrder.Date,
                    DeliveryType = pendingOrder.DeliveryType,
                    Id = pendingOrder.Id,
                    KitchenComment = pendingOrder.KitchenComment,
                    MenuItems = ms.MenuItemsToMenuItemViewModels(pendingOrder.MenuItems),
                    Price = pendingOrder.TotalPrice,
                    Status = pendingOrder.Status,
                    Users = ms.UsersToUserViewModels(new List<Entity.User> { pendingOrder.User })
                });
            }

            return pendingOrdersViewModel;
        }

        public string DeleteOrder(int id)
        {
            return _bd.DeleteOrder(id) ? "Success" : "Failed to delete order";
        }

        public List<Entity.MenuItem> MenuItemViewModelsToMenuItems(List<MenuItemViewModel> menuItemViewModels)
        {
            List<Entity.MenuItem> menuItems = new List<Entity.MenuItem>();
            foreach (var menuItemViewModel in menuItemViewModels)
            {
                menuItems.Add(new Entity.MenuItem
                {
                    Description = menuItemViewModel.Description,
                    FoodItem = menuItemViewModel.FoodItem,
                    Id = menuItemViewModel.Id,
                    OrderCount = menuItemViewModel.OrderCount,
                    Price = menuItemViewModel.Price
                });
            }
            return menuItems;
        }

        public List<Entity.User> UserViewModelsToUsers(List<UserViewModel> userViewModels)
        {
            List<Entity.User> users = new List<Entity.User>();
            foreach (var user in userViewModels)
            {
                users.Add(new Entity.User
                {
                    Name = user.Name,
                    Email = user.Email,
                    Id = user.Id,
                    ImageUrl = user.ImageUrl,
                    Location = user.Location
                });
            }
            return users;
        }
    }
}

