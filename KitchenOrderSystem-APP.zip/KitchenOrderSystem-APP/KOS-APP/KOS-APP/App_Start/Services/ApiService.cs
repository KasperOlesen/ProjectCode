﻿using System.Collections.Generic;
using System.IO;
using System.Net;
using Newtonsoft.Json;
using WebApplication1.Models;
using WebApplication1.Models.Database;

namespace WebApplication1.Services
{
    public class ApiService
    {
        public string Get(string uri)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
                request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                using (Stream stream = response.GetResponseStream())
                using (StreamReader reader = new StreamReader(stream))
                {
                    return reader.ReadToEnd();
                }
            }
            catch (WebException e)
            {
                return e.ToString();
            }
            
        }

        public List<Entity.User> BuildUsersFromString(string users)
        {
            List<Employee> employees = JsonConvert.DeserializeObject<List<Employee>>(users);
            List<Entity.User> usersList = new List<Entity.User>();
            foreach (var emp in employees)
            {
                Entity.User user = new Entity.User
                {
                    Email = emp.Email,
                    ImageUrl = emp.OriginalImageFilePath,
                    Location = "Meldahlsgade, Copenhagen",
                    Name = emp.DisplayName
                };
                usersList.Add(user);
            }
            return usersList;
        }

    }


}