
var webpack = require('webpack');
var path = require('path');
var ExtractTextPlugin = require('extract-text-webpack-plugin');

process.noDeprecation = true; 

module.exports = function() {
  var extractCss = new ExtractTextPlugin('[name].css')
	

  var config = {
    entry: path.resolve(__dirname, './Webroot/index.js'),
    output: {
      path: path.resolve(__dirname, './Webroot/dist/'),
      publicPath: '/',
      filename: '[name].js'
    },
    resolve: {
      extensions: ['.js', '.jsx']
    },
	plugins: [
	  extractCss
	],
    module: {
      rules: [
	  {
        loader: "babel-loader",
        include: [
          path.resolve("./Webroot"),
          ],
        test: /\.jsx?$/,
        options: {
          plugins: ['transform-runtime', 'transform-class-properties'],
          presets: ['es2015', 'react', 'stage-2'],
          },
          
      },{
		test: /\.scss$/i,
		loader: extractCss.extract(['css-loader', 'sass-loader'])
	  },{
		test: /\.css$/i,
		loader: extractCss.extract(['css-loader'])
	  }
	  ]
    }
  };

  return config
}

