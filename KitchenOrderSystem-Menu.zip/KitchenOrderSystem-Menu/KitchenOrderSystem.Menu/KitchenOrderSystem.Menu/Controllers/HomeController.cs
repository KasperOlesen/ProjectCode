﻿
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using System.Web.UI;
using KitchenOrderSystem.Menu.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;


namespace KitchenOrderSystem.Menu.Controllers
{

    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return RedirectToAction("Index", "TvMenu");
        }
    }
}
