﻿using System;
using System.Configuration;
using System.Web.Mvc;
using Castle.Core.Internal;
using Newtonsoft.Json;
using KitchenOrderSystem.Menu.Models;
using KitchenOrderSystem.Menu.Services;

namespace KitchenOrderSystem.Menu.Controllers
{
    public class TvMenuController : Controller
    {
        private static string _code = string.Empty;
        private string _data = string.Empty;
        public ActionResult Index()
        {
            InstagramService instagramService = new InstagramService();

            _data = instagramService.GetInstagramData();

            if (_data.IsNullOrEmpty())
            {
                _code = TempData["instacode"] as string;
                if (!_code.IsNullOrEmpty())
                {
                    _data = instagramService.GenerateAccessToken(_code);
                }
                else
                {
                    var clientId = ConfigurationManager.AppSettings["instagram.clientid"];
                    var redirectUri = ConfigurationManager.AppSettings["instagram.redirecturi"];
                    Response.Redirect("https://api.instagram.com/oauth/authorize/?client_id=" + clientId +
                                      "&redirect_uri=" + redirectUri + "&response_type=code");
                }
            }

            var menuViewModel = new MapperService().TodaysMenu();

            var model = new InstagramMenuViewModel { Data = _data, MenuVm = (MenuViewModel)menuViewModel };

            return View(model);
        }
    }
}