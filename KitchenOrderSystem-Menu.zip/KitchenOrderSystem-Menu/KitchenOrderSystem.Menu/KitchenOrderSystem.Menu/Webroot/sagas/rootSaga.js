import { fork } from 'redux-saga/effects'
import 'babel-polyfill'

import menuSaga from './menuSaga'
import instagramSaga from './instagramSaga'


export default function* root(){

  yield [
    fork(menuSaga),
    fork(instagramSaga),
  ]
}