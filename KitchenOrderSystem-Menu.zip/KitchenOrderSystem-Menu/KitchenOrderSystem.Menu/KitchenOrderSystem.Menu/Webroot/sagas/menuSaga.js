﻿import {fork, put, select, call} from 'redux-saga/effects'
import {takeEvery, takeLatest} from 'redux-saga'
import { handleRequest } from './serverSaga'
import { setMenu } from '../reducers/menuReducer'


const POST_MENU_REQUEST = 'POST_MENU_REQUEST'
const GET_MENU_REQUEST = 'GET_MENU_REQUEST'
const SET_MENU_REQUEST = 'SET_MENU_REQUEST'


export function setMenuRequest(menu) {return {type: SET_MENU_REQUEST, menu}}
export function postMenuRequest(data) {return {type: POST_MENU_REQUEST, data}}
export function getMenuRequest() {return {type: GET_MENU_REQUEST}}


function* applyMenu(action) {
  yield put(setMenu(action.menu))
}


function* postNewMenu(action){
  let response = yield call(handleRequest, '/admin/menu' ,'POST', action.data)
  alert(response)
}


function* getMenu(){ 
  let response = yield call(handleRequest, "/admin/menu", "GET")

  if(response){
    yield put(setMenu(response))
  }
}

export default function* menuSaga(){
  yield [
    fork(function*() {
      yield takeEvery(POST_MENU_REQUEST, postNewMenu)
    }),
    fork(function*() {
      yield takeEvery(GET_MENU_REQUEST, getMenu)
    }),
    fork(function*(){
      yield takeEvery(SET_MENU_REQUEST, applyMenu)
    })
  ]
}



