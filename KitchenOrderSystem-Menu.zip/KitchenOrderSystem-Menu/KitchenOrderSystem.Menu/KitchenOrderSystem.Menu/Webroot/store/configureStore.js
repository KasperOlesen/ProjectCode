﻿import { createStore, applyMiddleware, compose } from 'redux'
import 'babel-polyfill'
import createSagaMiddleware, { END } from 'redux-saga'
import rootReducer from './reducers'
import logger from 'redux-logger'


export default function configureStore(initialState){
  const sagaMiddleware = createSagaMiddleware()

  const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

  const store = createStore(
    rootReducer,
    initialState,
    applyMiddleware(sagaMiddleware, logger())
  )

  store.runSaga = sagaMiddleware.run
  store.close = () => store.dispatch(END)
  return store
}