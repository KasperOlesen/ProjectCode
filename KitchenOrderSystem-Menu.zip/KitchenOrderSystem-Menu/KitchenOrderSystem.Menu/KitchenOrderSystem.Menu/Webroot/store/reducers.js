﻿import { combineReducers } from 'redux'
import { reducer as reduxFormReducer } from 'redux-form'

import menuViewList from '../reducers/menuReducer'
import instagramList from '../reducers/instagramReducer'


export default combineReducers({
  menuViewList,
  instagramList,
})