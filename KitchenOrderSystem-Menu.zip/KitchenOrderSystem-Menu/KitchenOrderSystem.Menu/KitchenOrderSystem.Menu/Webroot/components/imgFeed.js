import React from 'react'
import Slider from 'react-slick'
import "slick-carousel/slick/slick.css"

export default class InstagramCarousel extends React.Component {
  constructor(props) {
    super(props)

  }

  render() {
    const settings = {
      dots: false,
      infinite: true,
      fade: true,
      speed: 3500,
      autoplaySpeed: 10000,
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: false,
      autoplay: true,
      pauseOnHover: false,
      easing: 'linear',
    }

    const { instagramData } = this.props

    let images

    if (instagramData.data) {
      images = instagramData.data.map((slide, index) => {
        return (
          <div key={index}>
            <img src={slide.images.standard_resolution.url} />
          </div>
        )
      })
    }

    return (
      <div className='pageContent'>
        <div className='imageFeed'>
          <Slider {...settings}>
            {images}
          </Slider>
        </div>
      </div>
    )
  }
}