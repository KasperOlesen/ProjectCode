import React from 'react'



export default class MenuList extends React.Component {
  constructor(props) {
    super(props)
  }


  render() {

    const { menuList } = this.props
    let listElements
    

    if (menuList) {
      listElements = menuList.map((item) => {

        let title, description = ''

        if(item.FoodItem){
          title = item.FoodItem.toUpperCase()
        }
        if(item.Description){
          description = item.Description.toUpperCase()
        }

        return (
          <div className='menuBox1' key={item.Id}>
            <div className='menuHeader1'> {title} </div>
            <div className='menuText1'> {description} </div>
          </div>
        )
      })
    }

    return (
        <div className='pageContent'>
          {listElements}
        </div>
    )


  }



}