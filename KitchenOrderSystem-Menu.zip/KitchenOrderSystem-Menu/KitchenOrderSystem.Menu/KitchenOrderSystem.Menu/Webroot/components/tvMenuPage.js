﻿import '../css/main.css'
import '../css/tvMenu.css'
import React, { Component } from 'react'
import InstagramCarousel from './imgFeed'
import MenuList from './menuList'
import { connect } from 'react-redux'
import { menuSelector, setMenu } from '../reducers/menuReducer'
import { setMenuRequest } from '../sagas/menuSaga'
import { setInterval } from 'timers';
import { instagramSelector } from '../reducers/instagramReducer';
import { setImgData } from '../sagas/instagramSaga'


const mapStateToProps = (state) => {
  return {
    MenuItems: menuSelector.MenuItems(state),
    ClosingTime: menuSelector.ClosingTime(state),
    Id: menuSelector.Id(state),
    Date: menuSelector.Date(state),
    MenuApplied: menuSelector.menuApplied(state),
    instagramData: instagramSelector.data(state),
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    setMenu: (menu) => dispatch(setMenuRequest(menu)),
    setImages: (data) => dispatch(setImgData(data))
  }
}

class menuViewList extends React.Component {

  constructor(props) {
    super(props)
  }

  componentWillMount() {



    const instagramData = JSON.parse(this.props.data.Data)

    this.props.setMenu(this.props.data.MenuVm)
    this.props.setImages(instagramData) 
  }

  componentDidMount() {
     setInterval(function(){ window.location.assign('https://kosadmin.prod.ibn.host/menu/') }, (5 * 60 * 1000));
  }


  render() {


  let currentTime = new Date()

    return (
      <div className='tvContent'>
        {
          this.props.MenuApplied && 
          this.props.ClosingTime > currentTime ? 
                                    <MenuList 
                                    menuList={this.props.MenuItems} 
                                    /> : 
                                    <InstagramCarousel
                                    instagramData={this.props.instagramData} 
                                    />
        }
      </div>

    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(menuViewList)



