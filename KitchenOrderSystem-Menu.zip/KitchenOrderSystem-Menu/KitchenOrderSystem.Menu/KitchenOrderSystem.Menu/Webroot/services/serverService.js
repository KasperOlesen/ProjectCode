﻿import React, { Component } from 'react'

export function callServerApi(url, method, bodyData) {

  let methodType = method.toLowerCase()

  return new Promise((resolve, reject) => {

    let r;
    switch (methodType) {
      case 'post':
        r = {
          credentials: 'include',
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(bodyData)
        }
        break;
      case 'put':
        r = {
          credentials: 'include',
          method: 'PUT',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(bodyData)
        }
        break;
      case 'get':
        r = {
          credentials: 'include',
          method: 'GET'
        }
        break;
    }


    if (r) {

      console.log("URL: ", url)
      fetch(url, r)
        .then((response) => {
          if (response.status >= 200 && response.status < 300) {
            return response.json()
          } else {

            var error = new Error(response.statusText)
            error.response = response
            return 'Error: ' + error.response.status

          }
        })
        .then((res) => {
          console.log("Response:", url, res)
          /*           alert(res) */
          resolve(res)
        })
        .catch((error) => {
          alert("Der er opstået en fejl.")
          console.log("Error:", url, error)
          //location.reload();
        })

    }
  })
}
