﻿import menuViewList from '../components/tvMenuPage'

let renderings = {}

function setupRendering(key, render) {
    renderings[key] = render
}

setupRendering('menuViewList', menuViewList)

module.exports = renderings

