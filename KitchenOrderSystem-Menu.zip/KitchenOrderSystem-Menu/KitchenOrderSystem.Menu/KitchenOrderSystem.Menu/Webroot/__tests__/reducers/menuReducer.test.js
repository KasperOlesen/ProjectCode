import menuViewReducer, { setMenu } from '../../reducers/menuReducer'
import { menuList } from '../../stubs/menuList'
import React from 'react'


describe('Menu View Reducer', () => {
  it('has correct default state', () => {
    expect(menuViewReducer(undefined, { 
      type: 'unexpected' 
      })).toEqual({
        Id: '', 
        ClosingTime: '',
        Date: '', 
        MenuItems: [],
        menuApplied: false    
      })
  })


  it('can set a menu', () => {
    expect(menuViewReducer(undefined, setMenu(menuList))).toEqual(menuList.menu)
  })
})