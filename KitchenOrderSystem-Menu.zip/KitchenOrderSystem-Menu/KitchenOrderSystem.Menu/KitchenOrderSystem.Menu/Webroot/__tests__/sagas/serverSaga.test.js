 import sinon from "sinon";
import * as obj from "../../services/serverService";
import { handleRequest } from '../../sagas/serverSaga'
import { runSaga } from "redux-saga";
import { sagaMock as menu, menuList} from '../../stubs/menuList'
import { setMenu } from '../../reducers/menuReducer'
import { setMenuRequest } from '../../sagas/MenuSaga'
import { expectSaga } from 'redux-saga-test-plan'

const serverStub = sinon.stub(obj, 'callServerApi')


serverStub.callsFake(() => {
  return {
    menu: menuList.menu
  }
})

const saga = handleRequest
const dispatched = {}

describe('serverSaga', () => {
  it('can retrieve todays menu', async () => {
    await runSaga(
      {
        dispatch: action => dispatched.push(action),
        getState: () => ({})
      },
        saga,
        'test-url',
        'GET'
    ).done
  
    expect(serverStub.calledOnce).toBeTruthy()
    expect(dispatched).toContainEqual(setMenu(menuList))
  
  })

  it("handleRequest returns", () => {
    return expectSaga(handleRequest)
    .returns(menuList)
    .run()
  })

})    


