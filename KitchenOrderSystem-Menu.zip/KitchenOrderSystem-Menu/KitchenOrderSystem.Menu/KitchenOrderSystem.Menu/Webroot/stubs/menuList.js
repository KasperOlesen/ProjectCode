

const menuList = {
  menu: {
    Date: '2018-03-13T23:00:00.000Z', 
    Id: '10', 
    ClosingTime: '2018-03-13T23:00:00.000Z',
    MenuItems: [{
      id: "22", 
      foodItem: "Paprikagryde", 
      description: "Kylling, paprika og grønsager", 
      price: 100
      },{
      id: "33", 
      foodItem: "Kyllingesandwich", 
      description: "m. avocado, skinke og karrysalat", 
      price: 50
      },{
      id: "44", 
      foodItem: "Hestebøffer", 
      description: "m. sovs og kartofler", 
      price: 10
      },{
      id: "6", 
      foodItem: "Borsch", 
      description: "Russisk rødebedesuppe", 
      price: 5
      }],
      menuApplied: true   
  }                    
}


const sagaMock = {
  
    Date: '2018-03-13T23:00:00.000Z', 
    Id: '10', 
    ClosingTime: '2018-03-13T23:00:00.000Z',
    MenuItems: [{
      id: "22", 
      foodItem: "Paprikagryde", 
      description: "Kylling, paprika og grønsager", 
      price: 100
      },{
      id: "33", 
      foodItem: "Kyllingesandwich", 
      description: "m. avocado, skinke og karrysalat", 
      price: 50
      }],
      menuApplied: true   
                     
}

module.exports = {menuList, sagaMock}

