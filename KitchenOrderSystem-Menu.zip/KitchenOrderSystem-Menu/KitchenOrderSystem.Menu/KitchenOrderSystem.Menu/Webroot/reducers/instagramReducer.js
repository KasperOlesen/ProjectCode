import iassign from 'immutable-assign'

const SET_IMAGES = "SET_IMAGES"
export function setImages(data) {return {type: SET_IMAGES, data}}

iassign.freeze = true;

const initialState = {
  data: {}
}

function instagramReducer(state = iassign(initialState, (s) => s), action){
  switch(action.type){
    case SET_IMAGES:
      return iassign(
        state,
        function (original) {

          original.data = action.data

          return original
        }
      )
    default:
      return state
  }
}

export const instagramSelector = {
  data: state => state.instagramList.data
}

export default instagramReducer
