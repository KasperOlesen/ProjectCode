import iassign from 'immutable-assign'
import { fixFormat } from '../assembly/datetimeAssembler'


const SET_MENU = "SET_MENU"
const SET_MENU_ITEMS = "SET_MENU_ITEMS"
const REMOVE_ITEM_FROM_MENU = "REMOVE_ITEM_FROM_MENU"
const SET_CLOSING_TIME = "SET_CLOSING_TIME"

export function setMenu(newMenu) { return { type: SET_MENU, newMenu } }
export function removeItemFromMenu(item) { return { type: REMOVE_ITEM_FROM_MENU, item } }
export function setMenuItems(menuItems) { return { type: SET_MENU_ITEMS, menuItems } }
export function setClosingTime(time) { return { type: SET_CLOSING_TIME, time } }

iassign.freeze = true

const initialState = {
  Id: '',
  ClosingTime: '',
  Date: '',
  MenuItems: [],
  menuApplied: false
}

function menuReducer(state = iassign(initialState, (s) => s), action) {
  switch (action.type) {
    case SET_MENU:
      return iassign(
        state,
        function (s) {

          if (action.newMenu) {
            s.MenuItems = action.newMenu.MenuItems
            s.Id = action.newMenu.Id
            s.Date = fixFormat(action.newMenu.Date)
            s.ClosingTime = fixFormat(action.newMenu.ClosingTime)
            s.menuApplied = true
          }
          return s
        }
      )
    case SET_MENU_ITEMS:
      return iassign(
        state,
        function (s) { s.MenuItems = action.menuItems; return s }
      )
    case REMOVE_ITEM_FROM_MENU:
      return iassign(
        state,
        function (s) {
          const index = s.MenuItems.indexOf(action.item)
          return s.MenuItems.splice(index, 1)
        }
      )
    case SET_CLOSING_TIME:
      return iassign(
        state,
        function (s) { s.ClosingTime = action.time; return s }
      )
    default:
      return state
  }
}

export const menuSelector = {
  Date: state => state.menuViewList.Date,
  ClosingTime: state => state.menuViewList.ClosingTime,
  Id: state => state.menuViewList.Id,
  MenuItems: state => state.menuViewList.MenuItems,
  menuApplied: state => state.menuViewList.menuApplied
}

export default menuReducer


