﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using KitchenOrderSystem.Menu.Models.Database;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using KitchenOrderSystem.Menu.Models;

namespace KitchenOrderSystem.Menu.Services
{
    public class ApiService
    {
        public string Get(string uri)
        {
            try
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri);
                request.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;

                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                using (Stream stream = response.GetResponseStream())
                using (StreamReader reader = new StreamReader(stream))
                {
                    return reader.ReadToEnd();
                }
            }
            catch (WebException e)
            {
                return e.ToString();
            }
            
        }

        public string GetInstagramAccessToken(string code)
        {
            NameValueCollection parameters = new NameValueCollection
            {
                { "client_id", ConfigurationManager.AppSettings["instagram.clientid"].ToString() },
                { "client_secret", ConfigurationManager.AppSettings["instagram.clientsecret"].ToString() },
                { "grant_type", "authorization_code" },
                { "redirect_uri", ConfigurationManager.AppSettings["instagram.redirecturi"].ToString() },
                { "code", code }
            };
            string accessToken = string.Empty;
            try
            {
                WebClient client = new WebClient();
                var result = client.UploadValues("https://api.instagram.com/oauth/access_token", "POST", parameters);
                var response = System.Text.Encoding.Default.GetString(result);

                var jsResult = (JObject)JsonConvert.DeserializeObject(response);
                accessToken = (string)jsResult["access_token"];

            }
            catch (WebException e)
            {
                Console.WriteLine(e);
            }

            return accessToken;
        }

        public string GetInstagramDataWithToken(string accessToken)
        {
            var res = Get("https://api.instagram.com/v1/users/self/media/recent/?access_token=" + accessToken);

            return res;
        }

        public string GetLocalImages()
        {
            string path = System.IO.Directory.GetCurrentDirectory() + @"\LocalImages";
            //string path = @"\LocalImages";

            string[] filePaths = Directory.GetFiles(path);

            string json = "{\"data\":{\"data\":[";

            string urls = "";
            foreach (var file in filePaths)
            {
                urls += "{\"images\":{\"standard_resolution\":{\"url\":\"" + file.Replace("\\", "/") + "\"}}},";
            }

            urls = urls.Remove(urls.Length - 1);

            json += urls + "]}}";

            return json;
        }

        public void RemoveAccessToken()
        {
            new MapperService().DeleteInstagramAccessToken();
        }
    }


}