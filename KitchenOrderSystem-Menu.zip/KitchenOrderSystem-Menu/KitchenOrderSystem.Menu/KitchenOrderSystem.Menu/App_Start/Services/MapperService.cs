﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.WebPages;
using KitchenOrderSystem.Menu.Models.Database;
using KitchenOrderSystem.Menu.Models;
using Newtonsoft.Json;

namespace KitchenOrderSystem.Menu.Services
{
    public class MapperService : IMapperService
    {
        //private UnitOfWork unitOfWork = new UnitOfWork();
        private readonly IBoundary _bd;

        public MapperService(IBoundary bd)
        {
            this._bd = bd;
        }

        public MapperService()
        {
            this._bd = new Boundary();
        }

        public InstagramDataViewModel InstagramData()
        {
            Entity.InstagramData instagramData = _bd.GetInstagramData();
            InstagramDataViewModel idvm = new InstagramDataViewModel();
            if (instagramData.AccessToken != null)
            {
                idvm.AccessToken = instagramData.AccessToken;
                idvm.ClientId = instagramData.ClientId;
                idvm.ClientSecret = instagramData.ClientSecret;
                idvm.RedirectUri = instagramData.RedirectUri;
            }

            return idvm;
        }

        public void DeleteInstagramAccessToken()
        {
            _bd.DeleteAccessToken();
        }

        public void SetInstagramData(string accessToken, string clientId, string clientSecret, string redirectUri)
        {
            _bd.SetInstagramData(new Entity.InstagramData{AccessToken = accessToken, ClientId = clientId, ClientSecret = clientSecret, RedirectUri = redirectUri});
        }

       
        public MenuViewModel TodaysMenu()
        {
            MenuViewModel todaysMenu;
            Entity.Menu menu = _bd.GetMenuByDate(DateTime.Today);

            if (menu != null)
            {
                todaysMenu = new MenuViewModel
                {
                    Id = menu.Id,
                    ClosingTime = menu.ClosingTime,
                    Date = menu.Date,
                    MenuItems = new List<MenuItemViewModel>()
                };

                foreach (var menuItem in menu.MenuItems)
                {
                    todaysMenu.MenuItems.Add(new MenuItemViewModel
                    {
                        Description = menuItem.Description,
                        FoodItem = menuItem.FoodItem,
                        Id = menuItem.Id,
                        Price = menuItem.Price
                    });
                }
                todaysMenu.MenuItems = todaysMenu.MenuItems.OrderByDescending(x => x.Id).Reverse().ToList();
            }
            else
            {
                todaysMenu = new MenuViewModel();
            }
            
            
            return todaysMenu;
        }

       

        public MenuViewModel GetMenu(int menuId)
        {
            MenuViewModel todaysMenu;
            Entity.Menu menu = _bd.GetMenu(menuId);
            if (menu != null)
            {
                todaysMenu = new MenuViewModel
                {
                    Id = menu.Id,
                    Date = menu.Date,
                    MenuItems = new List<MenuItemViewModel>()
                };

                foreach (var menuItem in menu.MenuItems)
                {
                    todaysMenu.MenuItems.Add(new MenuItemViewModel
                    {
                        Description = menuItem.Description,
                        FoodItem = menuItem.FoodItem,
                        Id = menuItem.Id,
                        Price = menuItem.Price
                    });
                }
            }
            else
            {
                todaysMenu = new MenuViewModel();
            }
            return todaysMenu;
        }

      

        public List<MenuItemViewModel> MenuItemsToMenuItemViewModels(List<Entity.MenuItem> menuItems)
        {
            return menuItems.Select(item => new MenuItemViewModel
            {
                Description = item.Description,
                FoodItem = item.FoodItem,
                Id = item.Id,
                Price = item.Price,
                OrderCount = item.OrderCount
            })
                .ToList();
        }

       

    }

    public class MapEntity
    {

        private readonly Boundary _bd;

        public MapEntity(Boundary bd)
        {
            this._bd = bd;
        }

        public MapEntity()
        {
            this._bd = new Boundary();
        }
        

        public List<Entity.MenuItem> MenuItemViewModelsToMenuItems(List<MenuItemViewModel> menuItemViewModels)
        {
            List<Entity.MenuItem> menuItems = new List<Entity.MenuItem>();
            foreach (var menuItemViewModel in menuItemViewModels)
            {
                menuItems.Add(new Entity.MenuItem
                {
                    Description = menuItemViewModel.Description,
                    FoodItem = menuItemViewModel.FoodItem,
                    Id = menuItemViewModel.Id,
                    OrderCount = menuItemViewModel.OrderCount,
                    Price = menuItemViewModel.Price
                });
            }
            return menuItems;
        }
    }
}

