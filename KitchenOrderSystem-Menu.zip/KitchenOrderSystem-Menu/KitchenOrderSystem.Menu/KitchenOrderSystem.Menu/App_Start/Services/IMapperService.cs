﻿using System.Collections.Generic;
using KitchenOrderSystem.Menu.Models.Database;
using KitchenOrderSystem.Menu.Models;

namespace KitchenOrderSystem.Menu.Services
{
    public interface IMapperService
    {
        void DeleteInstagramAccessToken();
        MenuViewModel GetMenu(int menuId);
        InstagramDataViewModel InstagramData();
        List<MenuItemViewModel> MenuItemsToMenuItemViewModels(List<Entity.MenuItem> menuItems);
        void SetInstagramData(string accessToken, string clientId, string clientSecret, string redirectUri);
        MenuViewModel TodaysMenu();
    }
}