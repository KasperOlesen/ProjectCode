﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using KitchenOrderSystem.Menu.Models.Database;
using KitchenOrderSystem.Menu.Models;

namespace KitchenOrderSystem.Menu.Models
{
    public class MenuViewModel
    {
        public int Id { get; set; }
        public DateTime ClosingTime { get; set; }
        public DateTime Date { get; set; }
        public List<MenuItemViewModel> MenuItems { get; set; }

        public override string ToString()
        {
            return $"Id: {Id}, ClosingTime: {ClosingTime}, Date: {Date}, MenuItems: {MenuItems}";
        }
    }
}