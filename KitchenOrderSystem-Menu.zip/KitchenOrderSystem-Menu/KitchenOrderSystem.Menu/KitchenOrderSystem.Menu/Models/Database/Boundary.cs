﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using KitchenOrderSystem.Menu;
using KitchenOrderSystem.Menu.Models.Database;
using Newtonsoft.Json;
using static KitchenOrderSystem.Menu.Models.Database.Entity;

namespace KitchenOrderSystem.Menu.Models.Database
{
    public class Boundary : IBoundary
    {
        private Entity.KitchenAppContext _kitchenAppContext;
        public Boundary()
        {
            _kitchenAppContext = new Entity.KitchenAppContext();
        }

        public Boundary(Entity.KitchenAppContext kitchenAppContext)
        {
            _kitchenAppContext = kitchenAppContext;
        }

        public void SetDbContext(Entity.KitchenAppContext kitchenAppContext)
        {
            _kitchenAppContext = kitchenAppContext;
        }


        public Entity.Menu GetMenuByDate(DateTime date)
        {
            Entity.Menu menu;
            using (var db = new Entity.KitchenAppContext())
            {
                var query = db.Menus
                    .Where(m => m.Date == date).Include(m => m.MenuItems).FirstOrDefault();
                menu = query;
            }
            return menu;
        }

        public Entity.Menu GetMenu(int menuId)
        {
            Entity.Menu menu;
            using (var db = new Entity.KitchenAppContext())
            {
                var query = db.Menus
                    .Where(m => m.Id == menuId).Include(m => m.MenuItems).FirstOrDefault();
                menu = query;
            }
            return menu;
        }


        public MenuItem GetMenuItem(int id)
        {
            MenuItem menuItem;
            using (var db = new Entity.KitchenAppContext())
            {
                menuItem = db.MenuItems.SingleOrDefault(mi => mi.Id == id);
            }
            return menuItem;
        }

        public bool DeleteUser(int userId)
        {
            bool result;
            using (var db = new Entity.KitchenAppContext())
            {
                var user = db.Users.Single(u => u.Id == userId);
                var orders = db.Orders.Where(o => o.User.Id == userId);
                db.Orders.RemoveRange(orders);
                db.Users.Remove(user);
                result = db.SaveChanges() > 0;
            }
            return result;
        }


        public Entity.InstagramData GetInstagramData()
        {
            Entity.InstagramData instagramData;
            using (var db = new Entity.KitchenAppContext())
            {
                instagramData = db.Instagram.Count() == 1 ? db.Instagram.Single() : new Entity.InstagramData();
            }

            return instagramData;
        }

        public void SetInstagramData(Entity.InstagramData instagramData)
        {
            using (var db = new Entity.KitchenAppContext())
            {
                db.Instagram.RemoveRange(db.Instagram);
                db.Instagram.Add(instagramData);
                db.SaveChanges();
            }
        }

        public void DeleteAccessToken()
        {
            using (var db = new Entity.KitchenAppContext())
            {
                db.Instagram.RemoveRange(db.Instagram);
                db.SaveChanges();
            }
        }

    }


}