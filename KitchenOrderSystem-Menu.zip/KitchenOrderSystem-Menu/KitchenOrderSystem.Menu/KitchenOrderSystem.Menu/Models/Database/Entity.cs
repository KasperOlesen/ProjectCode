﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace KitchenOrderSystem.Menu.Models.Database
{
    public class Entity
    {
        public class AdminUser
        {
            public int Id { get; set; }
            public string UserName { get; set; }
            public string Password { get; set; }

        }
        public class User
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string Location { get; set; }
            public string Email { get; set; }
            public string ImageUrl { get; set; }
            public virtual List<Order> Orders { get; set; }
        }

        public class Order
        {
            public int Id { get; set; }
            public DateTime Date { get; set; }
            public string DeliveryType { get; set; }
            public string Status { get; set; }
            public string Comment { get; set; }
            public string KitchenComment { get; set; }
            public double TotalPrice { get; set; }
            public virtual List<MenuItem> MenuItems { get; set; }
            public User User { get; set; }

        }

        public class MenuItem
        {
            public int Id { get; set; }
            public string FoodItem { get; set; }
            public string Description { get; set; }
            public double Price { get; set; }
            public int OrderCount { get; set; }
            public virtual List<Order> Orders { get; set; }
        }

        public class Menu
        {
            public int Id { get; set; }
            public DateTime Date { get; set; }
            public DateTime ClosingTime { get; set; }
            public virtual List<MenuItem> MenuItems { get; set; }
        }

        public class InstagramData
        {
            public int Id { get; set; }
            public string AccessToken { get; set; }
            public string ClientId { get; set; }
            public string ClientSecret { get; set; }
            public string RedirectUri { get; set; }
        }

        public class KitchenAppContext : DbContext
        {
            public KitchenAppContext() : base("KitchenApplication.Models.Database.Entity+KitchenAppContext")
            { }
            public DbSet<AdminUser> AdminUsers { get; set; }
            public DbSet<User> Users { get; set; }
            public DbSet<Order> Orders { get; set; }
            public DbSet<MenuItem> MenuItems { get; set; }
            public DbSet<Menu> Menus { get; set; }
            public DbSet<InstagramData> Instagram { get; set; }


        }
    }
}