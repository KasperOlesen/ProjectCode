﻿using System;
using System.Collections.Generic;

namespace KitchenOrderSystem.Menu.Models.Database
{
    public interface IBoundary
    {
        void DeleteAccessToken();
        Entity.InstagramData GetInstagramData();
        Entity.Menu GetMenu(int menuId);
        Entity.Menu GetMenuByDate(DateTime date);
        Entity.MenuItem GetMenuItem(int id);
        void SetDbContext(Entity.KitchenAppContext kitchenAppContext);
        void SetInstagramData(Entity.InstagramData instagramData);

    }
}