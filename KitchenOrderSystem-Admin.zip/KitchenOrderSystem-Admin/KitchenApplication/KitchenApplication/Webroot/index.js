

require('expose-loader?React!react')
require('expose-loader?ReactDOM!react-dom')
require('expose-loader?Renderings!./rendering/initRenderings')

