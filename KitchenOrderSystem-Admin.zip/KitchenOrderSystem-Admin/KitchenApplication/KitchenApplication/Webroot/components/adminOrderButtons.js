import React from 'react'
import { connect } from 'react-redux'




class AdminOrderButtons extends React.Component {

  constructor(props) {
    super(props)
  }

  render() {

    const { accept, decline } = this.props

    return (
      <div>
        <div>
          <button type='button' label='Godkend' onClick={accept} className='btn btn-default btn-xs actionBtn'>Godkend</button>
          <button type='button' label='Afvis' onClick={decline} className='btn btn-default btn-xs ' >Afvis</button>
        </div>



      </div>
    )
  }
}



export default AdminOrderButtons