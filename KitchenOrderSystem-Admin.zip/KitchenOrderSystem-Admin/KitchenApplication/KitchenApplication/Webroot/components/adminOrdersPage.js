import ReactTable from 'react-table'
import 'react-table/react-table.css'
import React from 'react'
import { connect } from 'react-redux'
import { ReactTableDefaults } from 'react-table'
import { applyOrders, orderAccept, orderDecline, orderComment, orderPrice, processHandledOrders } from '../sagas/orderSaga'
import { orderSelector } from '../reducers/orderReducer'
import AdminRoutes from './adminRoutes'
import AdminOrderButtons from './adminOrderButtons'
import '../css/adminOrderPage.css'



const tableProps = {
	noDataText: 'Ingen ordrer fundet',
	showPagination: false,
	defaultPageSize: 40,
	className: '-striped -highlight',
	minRows: 2
}




const mapStateToProps = state => {
	return {
		Orders: orderSelector.Orders(state)
	}
}


const mapDispatchToProps = (dispatch) => {
	return {
		applyOrderStatus: (order) => dispatch(handleOrderStatus(order)),
		setOrders: (orders) => dispatch(applyOrders(orders)),
		acceptOrder: (orderId) => dispatch(orderAccept(orderId)),
		declineOrder: (orderId) => dispatch(orderDecline(orderId)),
		commentOrder: (orderId, comment) => dispatch(orderComment(orderId, comment)),
		setPrice: (orderId, price) => dispatch(orderPrice(orderId, price)),
		processOrders: (orders) => dispatch(processHandledOrders(orders))

	}
}

class OrderView extends React.Component {

	constructor(props) {
		super(props)
		this.renderEditableKitchenComment = this.renderEditableKitchenComment.bind(this)
		this.renderEditablePrice = this.renderEditablePrice.bind(this)
	}

	componentWillMount() {
		this.props.setOrders(this.props.data)
	}

	componentDidUpdate() {
		/* 		this.setButtonActive() */
	}

	/* 	setButtonActive() {
			console.log(document.getElementsByClassName("processOrderBtn"))
		} */


	renderEditableKitchenComment(cellInfo) {

		return (
			<div
				className={'kitchenCommentField'}
				contentEditable
				suppressContentEditableWarning
				onBlur={(e) => (
					this.props.commentOrder(cellInfo.row._original.Id, e.target.textContent)
				)}
				dangerouslySetInnerHTML={{
					__html: cellInfo.row.KitchenComment
				}}
			/>
		);
	}

	renderEditablePrice(cellInfo) {

		return (
			<div
				className={'priceField'}
				contentEditable
				suppressContentEditableWarning
				onBlur={(e) => (
					this.props.setPrice(cellInfo.row._original.Id, e.target.textContent)
				)}
				dangerouslySetInnerHTML={{
					__html: cellInfo.row.Price
				}}
			/>
		);
	}


	render() {

		let orders = this.props.Orders

		const columns = [{
			Header: 'Navn',
			id: 'Name',
			accessor: 'Users',
			width: 185,
			Cell: row => {
				const user = row.original.Users.map(user => user.Name)
				return user
			}
		}, {
			Header: 'Type',
			accessor: 'DeliveryType',
			width: 90
		}, {
			Header: 'Bestilling',
			id: 'FoodItem',
			accessor: 'MenuItems',
			width: 200,
			Cell: row => {
				const foodItems = row.original.MenuItems.map((item) => (
					<li key={item.Id}>- {item.FoodItem}</li>
				))
				return <ul>{foodItems}</ul>
			}
		}, {
			Header: 'Note',
			accessor: 'Comment',
			width: 250
		}, {
			Header: 'Kommentar fra køkkenet',
			accessor: 'KitchenComment',
			width: 300,
			Cell: this.renderEditableKitchenComment
		}, {
			Header: 'Pris',
			accessor: 'Price',
			width: 55,
			Cell: this.renderEditablePrice
		}, {
			Header: 'Action',
			accessor: 'Status',
			Cell: row => (
				<AdminOrderButtons
					accept={() => this.props.acceptOrder(row.original.Id)}
					decline={() => this.props.declineOrder(row.original.Id)}
				/>
			),
		}]


		return (
			<div className='standardPageLayout'>
				<div>
					<AdminRoutes />
					<br />
					<div>
						<div>
							<button className='processOrderBtn' onClick={() => this.props.processOrders(this.props.Orders)}>Gennemfør</button>
						</div>
						<br />
						<ReactTable
							data={orders}
							columns={columns}
							{...tableProps}
							getTrProps={(state, rowInfo) => {
								if (rowInfo && rowInfo.row) {
									if (rowInfo.row.Status && rowInfo.row.Status === 'Accepted') {
										return {
											style: {
												background: '#b8fcb8'
											}
										}
									} else if (rowInfo.row.Status && rowInfo.row.Status === 'Declined') {
										return {
											style: {
												background: '#f7b2b2'
											}
										}
									} else {
										return {}
									}
								} else {
									return {}
								}
							}}
						/>
						<br />
						<div>
							<button className='processOrderBtn' onClick={() => this.props.processOrders(this.props.Orders)}>Gennemfør</button>
						</div>
						<br />
					</div>
				</div>
			</div>
		)
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(OrderView)