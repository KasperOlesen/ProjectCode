import React from 'react'
import { connect } from 'react-redux'


class AdminRoutes extends React.Component {

  constructor(props){
    super(props)
  }


  render(){


    const routes = [
      {
      key: 0,  
      title: 'Menu',
      link: 'menu'
      },
       {
      key: 1,
      title: 'Bestillinger',
      link: 'orders'
      },
      {
      key: 2,
      title: 'Månedens udtræk',
      link: 'finance'
      },
      {
      key: 3,
      title: 'Avanceret',
      link: 'advanced'
      },
      {
      key: 4,  
      title: 'Log ud',
      link: 'logoff'
      } 
    ]





  return (
    <div>
      <ul className='adminRoutes'>
        { routes.map((route) => {
            return (
              <li className='' key={route.key}><a href={`/admin/${route.link}`}> {route.title} </a> | </li>       
            )
            }) 
        }
      </ul>
    </div>

  )

  }
}
export default connect()(AdminRoutes)