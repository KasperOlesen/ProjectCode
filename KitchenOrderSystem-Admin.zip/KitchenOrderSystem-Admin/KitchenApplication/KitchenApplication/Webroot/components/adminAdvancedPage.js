import React, { Component } from 'react'
import { connect } from 'react-redux'
import { getHistoryDataRequest, deleteHistoryDataReqest } from '../sagas/historySaga'
import { historySelector } from '../reducers/historyReducer'
import { Field, reduxForm } from 'redux-form'
import AdminRoutes from './adminRoutes'
import HistoryForm from './adminHistoryForm'
import HistoryElement from './adminHistoryElement'
import '../css/adminAdvancedPage.css'

const mapStateToProps = (state) => {
  return {
    userData: {
      email: historySelector.Email(state),
      id: historySelector.Id(state),
      ImageUrl: historySelector.ImageUrl(state),
      location: historySelector.Location(state),
      name: historySelector.Name(state)
    },
    orderHistory: {
      orders: historySelector.Orders(state)
    }
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    getHistory: (email) => dispatch(getHistoryDataRequest(email)),
    deleteHistory: (email) => dispatch(deleteHistoryDataReqest(email))
  }
}


class HistoryView extends React.Component {
  constructor(props) {
    super(props)
  }

  componentWillMount() {
  }

  componentDidMount() {

  }

  render() {

    return (
      <div>
        <div className='standardPageLayout'>
          <AdminRoutes />
          <br />
          <br />
          <div >
            <div >
              <HistoryForm
                searchHistory={this.props.getHistory}
                deleteHistory={this.props.deleteHistory}
              />
            </div>
            <br />
            <br />
            <br />
            <hr />
            { this.props.userData.id && <HistoryElement
              userInfo={this.props.userData}
              orderInfo={this.props.orderHistory}
            />}
          </div>
        </div>
      </div>
    )
  }
}

HistoryView = reduxForm({
  form: 'historySearchForm',
  /* validate */
})(HistoryView)

export default connect(mapStateToProps, mapDispatchToProps)(HistoryView)