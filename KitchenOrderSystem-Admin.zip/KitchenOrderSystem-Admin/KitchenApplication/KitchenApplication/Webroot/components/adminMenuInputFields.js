import React, { Component } from 'react'
import { connect } from 'react-redux'
import { reduxForm, Field, FieldArray } from 'redux-form'
import validate from './validateMenuForm'
import '../css/adminSetMenu.css'


//Component responsible for building each field
//export only used for testing
export const renderField = ({ input, label, type, className, meta: { touched, error } }) => (
  <div>
    <input {...input} type={type} placeholder={label} className={className} style={touched && error ? { border: '2px solid #ff0000' } : null} />
  </div>
);

//Component responsible for building all needed fields for each MenuItem
//export only used for testing
export const renderMenuItem = ({ fields, meta: { touched, error, submitFailed } }) => (
  <div className='foodItemList'>
    {fields.map((MenuItem, index) => (
      <div className='listItem' key={index}>
        <div><p className='foodItemNumber'> {index + 1}  - </p></div>
        <Field
          name={`${MenuItem}.FoodItem`}
          type='text'
          component={renderField}
          label='Titel'
          className='foodItemTitle'
        />
        <Field
          name={`${MenuItem}.Description`}
          type='text'
          component={renderField}
          label='Beskrivelse'
          className='foodItemDescription'
        />
        <button
          type='button'
          title='Fjern'
          onClick={() => fields.remove(index)}
          className='remItemRow'
          tabIndex='-1'
        >X
        </button>
        <br />
        <br />
      </div>
    ))}

    <div>
      <button
        type='button'
        disabled={fields.length >= 10}
        onClick={() => fields.length <= 9 && fields.push({})}
        className='addItemRow'
      >Tilføj Ret
        </button>
      {submitFailed && error && <span>{error}</span>}
    </div>
  </div>
);



export class MenuInputFields extends React.Component {

  constructor(props) {
    super(props)
  }


  render() {

    let currentDate = new Date()
    let formattedDate = currentDate.toLocaleDateString('en-GB')

    const { handleSubmit, pristine, reset, submitting, submitForm } = this.props

    return (
      <form className='adminInputForm' onSubmit={handleSubmit(submitForm)}>
        <div className='foodItemNumber formHeader'></div>
        <label className='formHeader blackUnderline' >Dato: {formattedDate}</label>
        <br />
        <br />
        <br />
        <div>
          <div className='foodItemNumber formHeader'></div>
          <div className='foodItemTitle formHeader blackUnderline'>Titel</div>
          <div className='foodItemDescription formHeader blackUnderline'>Beskrivelse </div>
        </div>
        <br />
        <br />
        <br />
        <FieldArray name='MenuItems' component={renderMenuItem} />
        <br />
        <div className=''>
          <button
            className='btn btn-default saveMenuBtn'
            type='submit'
            disabled={pristine || submitting}
          >Gem Menu
          </button>
          <label></label>
        </div>

      </form>
    )
  }
}

MenuInputFields = reduxForm({
  form: 'inputItemList',
  validate
})(MenuInputFields)


export default MenuInputFields
