import React, { Component } from 'react'
import { connect } from 'react-redux'
import { reduxForm, Field, FieldArray } from 'redux-form'
import { menuSelector } from '../reducers/menuReducer'
import { postMenuRequest, setMenuRequest } from '../sagas/menuSaga'
import MenuInputFields from './adminMenuInputFields'
import AdminRoutes from './adminRoutes'


const mapStateToProps = (state) => {

  let initValues

  if (menuSelector.menuApplied(state)) {
    initValues = {
      MenuItems: menuSelector.MenuItems(state)
    }
  }
  return {
    initialValues: initValues
  }
}

const mapDispatchToProps = (dispatch) => {
  return {
    setMenu: (menu) => dispatch(setMenuRequest(menu)),
    submitForm: (newMenu) => dispatch(postMenuRequest(newMenu))
  }
}


class AdminSetMenuView extends React.Component {

  constructor(props) {
    super(props)
  }

  componentWillMount() {
    this.props.setMenu(this.props.data)
  }



  render() {

    return (
      <div>
        <div className='standardPageLayout'>
          <AdminRoutes />
          <br />
          <br />
          <div>
            <MenuInputFields
              initialValues={this.props.initialValues}
              submitForm={this.props.submitForm} />
          </div>
        </div>
      </div>
    )
  }
}


export default connect(mapStateToProps, mapDispatchToProps)(AdminSetMenuView)