import ReactTable from 'react-table'
import 'react-table/react-table.css'
import React from 'react'
import { connect } from 'react-redux'
import { ReactTableDefaults } from 'react-table'
import { setFinanceDataRequest, getFinanceDataRequest } from '../sagas/financeSaga'
import { financeSelector } from '../reducers/financeReducer'
import AdminRoutes from './adminRoutes'
import '../css/adminFinancePage.css'



const tableProps = {
  noDataText: 'Ingen ordrer fundet',
  showPagination: false,
  defaultPageSize: 200,
  className: '-striped -highlight',
  minRows: 2,
}


const mapStateToProps = state => {
  return {
    financeData: financeSelector.data(state)
  }
}


const mapDispatchToProps = (dispatch) => {
  return {
    setData: (data) => dispatch(setFinanceDataRequest(data)),
    getData: (month) => dispatch(getFinanceDataRequest(month))
  }
}

class FinanceView extends React.Component {

  constructor(props) {
    super(props)
    this.state = { month: new Date().getMonth() + 1 }
    this.handleChange = this.handleChange.bind(this);
  }

  componentWillMount() {
    this.props.setData(this.props.data)
  }

  componentDidMount() {
  }

  handleChange(event) {
    this.setState({ month: event.target.value })
  }



  render() {

    const columns = [{
      Header: 'Navn',
      id: 'Name',
      accessor: 'User.Name',
      width: 230
    }, {
      Header: 'Email',
      accessor: 'User.Email',
      width: 230,
      Cell: row => (
        row.original.User.Email.toLowerCase()
      )
    }, {
      Header: 'Bestillinger',
      id: 'orders',
      accessor: 'Orders',
      width: 170,
      Cell: row => {
        const orders = row.original.Orders.map((order) => (
          <li key={order.Id}>- {order.Date} - {order.Price} kr.</li>
        ))
        return <ul className=''>{orders}</ul>
      }
    }, {
      Header: 'Total',
      accessor: 'TotalPrice',
      width: 100,
      Cell: row => (
        <span className='centerText'> {row.original.TotalPrice + " kr."} </span>
      )
    }]


    return (
      <div className='financePageLayout'>
        <div>
          <AdminRoutes />
          <br />
          <div>
            <div>
              <select id='monthSelector' value={this.state.month} onChange={this.handleChange} className='financeMonthSelector'>
                <option value='1'>Januar</option>
                <option value='2'>Februar</option>
                <option value='3'>Marts</option>
                <option value='4'>April</option>
                <option value='5'>Maj</option>
                <option value='6'>Juni</option>
                <option value='7'>Juli</option>
                <option value='8'>August</option>
                <option value='9'>September</option>
                <option value='10'>Oktober</option>
                <option value='11'>November</option>
                <option value='12'>December</option>
              </select>
              <button className='loadDataBtn' onClick={() => this.props.getData(this.state.month)} >Indlæs data</button>
              <button className='sendDataBtn'  >Send til regnskab</button>
            </div>
            <br />
            <br />
            <div className='financeTable'>
              <ReactTable
                data={this.props.financeData}
                columns={columns}
                {...tableProps }
              />
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(FinanceView)