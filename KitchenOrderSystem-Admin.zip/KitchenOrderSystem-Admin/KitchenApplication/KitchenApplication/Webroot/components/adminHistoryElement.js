import React, { Component } from 'react'



class HistoryElement extends React.Component {
  constructor(props) {
    super(props)
  }

  render() {

    const { orderInfo, userInfo } = this.props
    let completeHistory

    if (orderInfo.orders) {
      completeHistory = orderInfo.orders.map((order) => {

        return (
          <div className='historyOrderDetails' key={order.Id}>
            <b>ID: </b>{order.Id} - <b>Dato: </b> {order.Date.split('T')[0]} - <b>Pris: </b> {order.Price} - <b>Status: </b> {order.Status}
            <br />
            <b>Type: </b> {order.DeliveryType}
            <br />
            <b>Kommentar: </b> {order.Comment}
            <br />
            <b>Kommentar fra køkkenet: </b> {order.KitchenComment}
            <br />
            <b>Bestilling: </b> {order.MenuItems}
          </div>
        )
      })
    }

    return (
      <div>
        <div>
          <h2>{userInfo.name}</h2>
          <b>ID:</b> {userInfo.id}<br />
          <b>Email:</b> {userInfo.email}<br />
          <b>Afdeling:</b> {userInfo.location}<br />
        </div>
        <br />
        <h3>Købshistorik:</h3>
        <div>
          {completeHistory}
        </div>
      </div>
    )
  }
}


export default HistoryElement