
//regex patterns to match against
const timeFormat = /^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/
const specialCharsTextInput = /^[^|<>\"&]*$/
const emptyTextInput = /^[ \t\r\n]*$/

/*
//Error texts
//Deprecated - using border-color on inputboxes instead
const requiredErrText = '*Required'
const timeErrText = ' *Forkert input - Skriv TT:mm'
*/
const noItemsErrText = { _error: ' *Tilføj minimum 1 ret' } 



const validate = values => {

  const errors = {}

  if (!values.ClosingTime || emptyTextInput.test(values.ClosingTime)) {
    errors.ClosingTime = true
  }
  if (values.ClosingTime && !timeFormat.test(values.ClosingTime)){
    errors.ClosingTime = true
  }
  
  if (!values.MenuItems || !values.MenuItems.length) {
    errors.MenuItems = noItemsErrText
  } else {
    const MenuItemsArrayErrors = []
    values.MenuItems.forEach((MenuItem, MenuItemIndex) => {
      const MenuItemErrors = {}
      if ( !MenuItem.FoodItem || emptyTextInput.test(MenuItem.FoodItem)) {
        MenuItemErrors.FoodItem = true
        MenuItemsArrayErrors[MenuItemIndex] = MenuItemErrors
      } 
/*       if ( !MenuItem.Description || emptyTextInput.test(MenuItem.Description)) {
        MenuItemErrors.Description = true
        MenuItemsArrayErrors[MenuItemIndex] = MenuItemErrors
      }  */
    })
    if (MenuItemsArrayErrors.length) {
      errors.MenuItems = MenuItemsArrayErrors
    }
  }

  return errors
}

export default validate


/* 
|| !specialCharsTextInput.test(MenuItem.FoodItem) || !emptyTextInput.test(MenuItem.FoodItem) 


|| !specialCharsTextInput.test(MenuItem.Description) || !emptyTextInput.test(MenuItem.Description)


*/