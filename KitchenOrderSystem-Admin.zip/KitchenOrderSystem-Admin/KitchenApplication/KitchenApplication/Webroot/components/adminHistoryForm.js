import React, { Component } from 'react'
import { Field, reduxForm } from 'redux-form'


class HistoryForm extends React.Component {
  constructor(props) {
    super(props)
  }

  render() {

    const { handleSubmit, pristine, submitting, deleteHistory, searchHistory, orderInfo } = this.props

    return (
        <form onSubmit={handleSubmit(searchHistory)}>
          <div>
            <label className='searchLabel'>Søg: </label>
            <div>
              <Field
                name='email'
                component='input'
                type='email'
                className='searchInput'
                placeholder='Indtast email...'
                required
              />
            </div>
            <button
              className='searchBtn'
              type='submit'
              disabled={pristine || submitting}
            >Søg
            </button>
            <button
              className='deleteBtn'
              onClick={deleteHistory}
              disabled={pristine || submitting}
            >Slet Data
            </button>
          </div>
        </form>
    )
  }
}

HistoryForm = reduxForm({
  form: 'historySearchForm',
  /* validate */
})(HistoryForm)

export default HistoryForm