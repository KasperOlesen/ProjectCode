import React from 'react'
import configureStore from 'redux-mock-store'
import Adapter from 'enzyme-adapter-react-15'
import * as sinon from 'sinon'
import * as Enzyme from 'enzyme'
import { Provider } from 'react-redux'
import { mount, shallow, render } from 'enzyme'
import { menuList } from '../../stubs/menuList'
import { MenuInputFields, renderField } from '../../components/adminMenuInputFields'

Enzyme.configure({ adapter: new Adapter() })


 // This works but only if the reduxForm wrapper 
 // in adminMenuInputFields is removed/commented out
describe('<MenuInputFields />', () => {
  
  let subject
  let handleSubmit, pristine, reset, submitting, submitForm, touched, error
  
  beforeEach(() => {
    submitting = false
    pristine = true
    error = null
    reset = null
    handleSubmit = fn => fn
  })
  const buildSubject = () => {
    submitForm = sinon.spy()
    const props = {
      submitForm,
      fields: {
        ClosingTime: {
          value: '',
          touched: touched,
          error: error
        }
      },
      initialValues: {
        ClosingTime: '14:00',
        MenuItems: {
          FoodItem: 'test',
          Description: 'test',
          Price: '66'
        }
      },
      handleSubmit,
      reset
    }
    return render(<MenuInputFields {...props}/>)
  }

  it('has one FieldArray', () => {
    subject = buildSubject()
    expect(subject.find('FieldArray').length).toEqual(1)
  })



 
  it('it calls submitForm once when submitting', () => {
    subject = buildSubject()
    subject.find('form').simulate('submit')
    expect(submitForm.calledOnce).toBeTruthy()
  })

/*   
  //This doesnt work
  it('loads initial value of ClosingTime into input-box ', () => {
    subject = buildSubject()
    let form = subject.find('Field')
    let closingTime = form.find('ClosingTime')
    expect(closingTime).toEqual('14:00') 
    

//    expect(closingTime.text()).toEqual('14:00')
  })

  //This doesnt work
  it('Renders the "tilføj" button', () => {
    subject = buildSubject()
    let button = subject.find('.addItemRow')
    expect(button.text()).toEqual('Tilføj') 
  }) */
    
})

//TODO NEXT WEEK
//1. Change error to true
//2. Give the <span> error </span> a css-class
//3. find error block
//4. expect it to exist and the text to say required
/* describe('renderField', () => {
  let subject
  it('renders an inputfield', () => {
  
    const input = {name: 'ClosingTime', value:''}
    const label = 'TT:mm'
    const meta = {touched: false, error: ''}
    const type = 'text'
    const className = ''
    const element = renderField({input, label, type, className, meta})
    
    subject = shallow(element)

  console.log(subject.debug())  

    expect(subject.find({type: 'text'}).to.have.length(1))


  })
}) */


