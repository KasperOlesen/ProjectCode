import { expectSaga, takeEveryEffect } from 'redux-saga-test-plan'
import { call, put, takeLatest, takeEvery } from "redux-saga/effects";
import { handleRequest } from '../../sagas/serverSaga'
import menuSaga, { setMenuRequest } from '../../sagas/MenuSaga'
import { applyMenu } from '../../sagas/MenuSaga'
import { menuList } from '../../stubs/menuList'
import { setMenu } from '../../reducers/menuReducer';

it("Sets a new menu", () => {

  return expectSaga(menuSaga)
  .put(setMenu(menuList))
  .dispatch(setMenuRequest(menuList))
  .run()
})

