import iassign from 'immutable-assign'

const SET_HISTORY_DATA = 'SET_HISTORY_DATA'
export function setHistoryData(data) { return { type: SET_HISTORY_DATA, data } }

iassign.freeze = true;

const initialState = {
  Email: '',
  Id: '',
  ImageUrl: '',
  Location: '',
  Name: '',
  Orders: []
}

function historyReducer(state = iassign(initialState, (s) => s), action) {
  switch (action.type) {
    case SET_HISTORY_DATA:
      return iassign(
        state,
        function (original) {
          original.Email = action.data.Email
          original.Id = action.data.Id
          original.ImageUrl = action.data.ImageUrl
          original.Location = action.data.Location
          original.Name = action.data.Name
          original.Orders = action.data.Orders
          return original
        }
      )
    default:
      return state
  }
}

export const historySelector = {
  Email: state => state.historyList.Email,
  Id: state => state.historyList.Id,
  ImageUrl: state => state.historyList.ImageUrl,
  Location: state => state.historyList.Location,
  Name: state => state.historyList.Name,
  Orders: state => state.historyList.Orders
}

export default historyReducer