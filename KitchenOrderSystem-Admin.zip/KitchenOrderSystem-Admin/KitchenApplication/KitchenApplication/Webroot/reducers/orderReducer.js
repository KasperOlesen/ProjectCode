import iassign from 'immutable-assign'

const SET_ORDERS = "SET_ORDERS"
const ADD_ORDER = "ADD_ORDER"
const ACCEPT_ORDER = "ACCEPT_ORDER"
const DECLINE_ORDER = 'DECLINE_ORDER'
const COMMENT_ORDER = 'COMMENT_ORDER'
const SET_ORDER_PRICE = 'SET_ORDER_PRICE'

export function setOrders(orders) { return { type: SET_ORDERS, orders } }
export function acceptOrder(orderId) { return { type: ACCEPT_ORDER, orderId } }
export function declineOrder(orderId) { return { type: DECLINE_ORDER, orderId } }
export function commentOrder(orderId, comment) { return { type: COMMENT_ORDER, orderId, comment } }
export function setOrderPrice(orderId, price) { return { type: SET_ORDER_PRICE, orderId, price } }

iassign.freeze = true

const initialState = {
  "orders": [
    {
      "Id": "",
      "DeliveryType": "",
      "Comment": "",
      "KitchenComment": "",
      "Status": "",
      "Price": "",
      "Users": [],
      "MenuItems": []
    }
  ],
  "isChanged": false
}



function orderReducer(state = iassign(initialState, (s) => s), action) {
  let orderIndex
  switch (action.type) {
    case SET_ORDERS:
      return iassign(
        state,
        function (original) {

          original.orders = action.orders

          return original
        }
      )
    case ACCEPT_ORDER:
      orderIndex = state.orders.findIndex(o => o.Id === action.orderId)
      return iassign(
        state,
        (s) => s.orders[orderIndex],
        (order) => {
          order.Status = "Accepted"
          return order
        }
      )
    case DECLINE_ORDER:
      orderIndex = state.orders.findIndex(o => o.Id === action.orderId)
      return iassign(
        state,
        (s) => s.orders[orderIndex],
        (order) => {
          order.Status = "Declined"
          return order
        }
      )
    case COMMENT_ORDER:
      orderIndex = state.orders.findIndex(o => o.Id === action.orderId)
      return iassign(
        state,
        (s) => s.orders[orderIndex],
        (order) => {
          order.KitchenComment = action.comment
          return order
        }
      )
    case SET_ORDER_PRICE:
      orderIndex = state.orders.findIndex(o => o.Id === action.orderId)
      return iassign(
        state,
        (s) => s.orders[orderIndex],
        (order) => {
          order.Price = action.price
          return order
        }
      )
    default:
      return state
  }
}

export const orderSelector = {
  Orders: state => state.orderList.orders,
  isChanged: state => state.orderList.isChanged
}

export default orderReducer


