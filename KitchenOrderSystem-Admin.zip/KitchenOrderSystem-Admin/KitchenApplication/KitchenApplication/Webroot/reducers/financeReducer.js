import iassign from 'immutable-assign'

const SET_FINANCE_DATA = "SET_FINANCE_DATA"
export function setFinanceData(data) { return { type: SET_FINANCE_DATA, data } }

iassign.freeze = true;

const initialState = {
  data: []
}

function financeReducer(state = iassign(initialState, (s) => s), action) {
  switch (action.type) {
    case SET_FINANCE_DATA:
      return iassign(
        state,
        function (original) {
          original.data = action.data
          return original
        }
      )
    default:
      return state
  }
}

export const financeSelector = {
  data: state => state.financeList.data
}

export default financeReducer
