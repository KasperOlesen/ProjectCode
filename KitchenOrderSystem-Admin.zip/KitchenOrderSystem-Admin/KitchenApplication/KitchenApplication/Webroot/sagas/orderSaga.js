import { fork, put, select, call } from 'redux-saga/effects'
import { takeEvery, takeLatest } from 'redux-saga'
import { handleRequest } from './serverSaga'
import { setOrders, acceptOrder, declineOrder, commentOrder, setOrderPrice } from '../reducers/orderReducer'
import { fixFormat } from '../assembly/datetimeAssembler';

const SET_ORDERS_REQUEST = 'SET_ORDERS_REQUEST'
const SET_ORDER_PRICE_REQUEST = 'SET_ORDER_PRICE_REQUEST'
const ORDER_ACCEPT_REQUEST = 'ORDER_ACCEPT_REQUEST'
const ORDER_DECLINE_REQUEST = 'ORDER_DECLINE_REQUEST'
const ORDER_COMMENT_REQUEST = 'ORDER_COMMENT_REQUEST'

const ORDER_HANDLING_DONE_REQUEST = 'ORDER_HANDLING_DONE_REQUEST'

export function orderPrice(orderId, price) { return { type: SET_ORDER_PRICE_REQUEST, orderId, price } }
export function orderAccept(orderId) { return { type: ORDER_ACCEPT_REQUEST, orderId } }
export function orderDecline(orderId) { return { type: ORDER_DECLINE_REQUEST, orderId } }
export function orderComment(orderId, comment) { return { type: ORDER_COMMENT_REQUEST, orderId, comment } }

export function applyOrders(orders) { return { type: SET_ORDERS_REQUEST, orders } }
export function processHandledOrders(orders) { return { type: ORDER_HANDLING_DONE_REQUEST, orders } }



function* handleOrders(action) {
  if (action.orders) {
    action.orders.map((order) => {
      order.Date = fixFormat(order.Date)
    })
    yield put(setOrders(action.orders))
  }
}

function* setAccepted(action) {
  yield put(acceptOrder(action.orderId))
}

function* setDeclined(action) {
  yield put(declineOrder(action.orderId))
}

function* setComment(action) {
  yield put(commentOrder(action.orderId, action.comment))
}

function* processOrders(action) {
  let dataObj = { OrderViewModels: [] }
  action.orders.map((order) => {
    dataObj.OrderViewModels.push({ Id: order.Id, Status: order.Status, Price: order.Price, KitchenComment: order.KitchenComment })
  })

  let response = yield call(handleRequest, "/admin/OrderStatus", "PUT", dataObj)

  if (response) {
    yield put(setOrders(response.OrderViewModels))
    alert('Ordrer håndteret')
  }
}

function* setPrice(action) {
  yield put(setOrderPrice(action.orderId, action.price))
}

export default function* orderSaga() {
  yield [
    fork(function* () {
      yield takeEvery(SET_ORDERS_REQUEST, handleOrders)
    }),
    fork(function* () {
      yield takeEvery(ORDER_ACCEPT_REQUEST, setAccepted)
    }),
    fork(function* () {
      yield takeEvery(ORDER_DECLINE_REQUEST, setDeclined)
    }),
    fork(function* () {
      yield takeEvery(ORDER_COMMENT_REQUEST, setComment)
    }),
    fork(function* () {
      yield takeEvery(ORDER_HANDLING_DONE_REQUEST, processOrders)
    }),
    fork(function* () {
      yield takeEvery(SET_ORDER_PRICE_REQUEST, setPrice)
    })
  ]
}