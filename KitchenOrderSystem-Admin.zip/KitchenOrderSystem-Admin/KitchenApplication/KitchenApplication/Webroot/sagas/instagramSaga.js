import { fork, put, select, call } from 'redux-saga/effects'
import { takeEvery, takeLatest } from 'redux-saga'
import { handleRequest } from './serverSaga'
import { setImages } from '../reducers/instagramReducer'

const SET_IMG_DATA_REQUEST = 'SET_IMG_DATA_REQUEST'

export function setImgData(data) { return { type: SET_IMG_DATA_REQUEST, data } }

function shuffle(array) {
  let currentIndex = array.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}


function* setImageData(action) {
  if (action.data) {
    //TODO:
    //Make shuffle actually work
    //let shuffledImages = shuffle(action.data)
    console.log(action.data)
     yield put(setImages(action.data))
  } else {
    //TODO
    //Handle error when fetching instagram
  }
}

export default function* instagramSaga() {
  yield [
    fork(function* () {
      yield takeEvery(SET_IMG_DATA_REQUEST, setImageData)
    })
  ]
}
