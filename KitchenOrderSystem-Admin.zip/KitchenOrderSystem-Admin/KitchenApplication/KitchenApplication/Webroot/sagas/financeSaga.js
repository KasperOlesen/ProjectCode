import { fork, put, select, call } from 'redux-saga/effects'
import { takeEvery, takeLatest } from 'redux-saga'
import { handleRequest } from './serverSaga'
import { setFinanceData } from '../reducers/financeReducer'
import { fixFormat, getDate } from '../assembly/datetimeAssembler'

const SET_FINANCE_DATA_REQUEST = 'SET_FINANCE_DATA_REQUEST'
const GET_FINANCE_DATA_REQUEST = 'GET_FINANCE_DATA_REQUEST'

export function setFinanceDataRequest(data) { return { type: SET_FINANCE_DATA_REQUEST, data } }
export function getFinanceDataRequest(month) { return { type: GET_FINANCE_DATA_REQUEST, month } }


function formatOrderDates(financeData) {

  let fullDateObj = ''
  let data = financeData

  try {
    data.map((orderData) => {
      orderData.Orders.map((order) => {
        fullDateObj = fixFormat(order.Date)
        order.Date = getDate(fullDateObj)
      })
    })
  } catch (e) {

  }
  return data
}

function* setFinanceDataSaga(action) {

  if (action.data) {
    let formatedData = formatOrderDates(action.data)
    yield put(setFinanceData(formatedData))
  } else {
    //TODO
    //Handle error 
  }
}

function* getFinanceDataSaga(action) {

  let response = yield call(handleRequest, '/admin/monthlyOrders?month=' + action.month, 'GET')

  if (response) {
    let formatedData = formatOrderDates(response)
    yield put(setFinanceData(formatedData))
  }
}

export default function* financeSaga() {
  yield [
    fork(function* () {
      yield takeEvery(SET_FINANCE_DATA_REQUEST, setFinanceDataSaga)
    }),
    fork(function* () {
      yield takeEvery(GET_FINANCE_DATA_REQUEST, getFinanceDataSaga)
    })
  ]
}

