import { fork, put, call } from 'redux-saga/effects'
import { takeLatest, takeEvery } from 'redux-saga'
import { handleRequest } from './serverSaga'
import { setHistoryData } from '../reducers/historyReducer'
import { fixFormat, getDate } from '../assembly/datetimeAssembler'


const GET_HISTORY_DATA_REQUEST = 'GET_HISTORY_DATA_REQUEST'
const DELETE_HISTORY_DATA_REQUEST = 'DELETE_HISTORY_DATA_REQUEST'

export function getHistoryDataRequest(email) { return { type: GET_HISTORY_DATA_REQUEST, email } }
export function deleteHistoryDataReqest(email) { return { type: DELETE_HISTORY_DATA_REQUEST, email } }

function* getHistoryDataSaga(action) {

  const email = "kasperpontoppidan@gmail.com"

  let response = yield call(handleRequest, '/admin/userData?email=' + email, 'GET')

  if (response) {
    yield put(setHistoryData(response))
  }
}

function* deleteHistoryDataSaga(action) {
  let response = yield call(handleRequest, '/admin/deleteHistory', 'POST', action.email)
  alert(response)
}


export default function* historySaga() {
  yield [
    fork(function* () {
      yield takeEvery(GET_HISTORY_DATA_REQUEST, getHistoryDataSaga)
    }),
    fork(function* () {
      yield takeEvery(DELETE_HISTORY_DATA_REQUEST, deleteHistoryDataSaga)
    })
  ]
}
