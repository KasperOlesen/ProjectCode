import { fork } from 'redux-saga/effects'
import 'babel-polyfill'

import serverSaga from './serverSaga'
import financeSaga from './financeSaga'
import menuSaga from './menuSaga'
import orderSaga from './orderSaga'
import instagramSaga from './instagramSaga'
import historySaga from './historySaga'

export default function* root(){

  yield [
    fork(menuSaga),
    fork(orderSaga),
    fork(instagramSaga),
    fork(financeSaga),
    fork(historySaga),
  ]
}