﻿import { combineReducers } from 'redux'
import { reducer as reduxFormReducer } from 'redux-form'

import menuViewList from '../reducers/menuReducer'
import orderList from '../reducers/orderReducer'
import instagramList from '../reducers/instagramReducer'
import financeList from '../reducers/financeReducer'
import historyList from '../reducers/historyReducer'

export default combineReducers({
  menuViewList,
  orderList,
  instagramList,
  financeList,
  historyList,
  form: reduxFormReducer,
})