﻿import menuViewList from '../components/tvMenuPage'
import AdminSetMenuView from '../components/adminSetMenuPage'
import MenuInputFields from '../components/adminMenuInputFields'
import AdminRoutes from '../components/adminRoutes'
import OrderView from '../components/adminOrdersPage'
import FinanceView from '../components/adminFinancePage'
import HistoryView from '../components/adminAdvancedPage'

let renderings = {}

function setupRendering(key, render) {
    renderings[key] = render
}

setupRendering('menuViewList', menuViewList)
setupRendering('AdminSetMenuView', AdminSetMenuView)
setupRendering('MenuInputFields', MenuInputFields)
setupRendering('AdminRoutes', AdminRoutes)
setupRendering('OrderView', OrderView)
setupRendering('FinanceView', FinanceView)
setupRendering('HistoryView', HistoryView)

module.exports = renderings

