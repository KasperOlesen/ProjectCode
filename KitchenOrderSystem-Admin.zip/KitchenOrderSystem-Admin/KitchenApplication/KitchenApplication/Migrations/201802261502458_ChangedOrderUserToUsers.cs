namespace KitchenApplication.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ChangedOrderUserToUsers : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Orders", "User_Id", "dbo.Users");
            DropIndex("dbo.Orders", new[] { "User_Id" });
            CreateTable(
                "dbo.UserOrders",
                c => new
                    {
                        User_Id = c.Int(nullable: false),
                        Order_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.User_Id, t.Order_Id })
                .ForeignKey("dbo.Users", t => t.User_Id, cascadeDelete: true)
                .ForeignKey("dbo.Orders", t => t.Order_Id, cascadeDelete: true)
                .Index(t => t.User_Id)
                .Index(t => t.Order_Id);
            
            DropColumn("dbo.Orders", "User_Id");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Orders", "User_Id", c => c.Int());
            DropForeignKey("dbo.UserOrders", "Order_Id", "dbo.Orders");
            DropForeignKey("dbo.UserOrders", "User_Id", "dbo.Users");
            DropIndex("dbo.UserOrders", new[] { "Order_Id" });
            DropIndex("dbo.UserOrders", new[] { "User_Id" });
            DropTable("dbo.UserOrders");
            CreateIndex("dbo.Orders", "User_Id");
            AddForeignKey("dbo.Orders", "User_Id", "dbo.Users", "Id");
        }
    }
}
