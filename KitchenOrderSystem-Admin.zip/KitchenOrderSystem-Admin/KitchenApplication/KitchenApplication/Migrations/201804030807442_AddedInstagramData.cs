namespace KitchenApplication.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedInstagramData : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.InstagramDatas",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        AccessToken = c.String(),
                        ClientId = c.String(),
                        ClientSecret = c.String(),
                        RedirectUri = c.String(),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.InstagramDatas");
        }
    }
}
