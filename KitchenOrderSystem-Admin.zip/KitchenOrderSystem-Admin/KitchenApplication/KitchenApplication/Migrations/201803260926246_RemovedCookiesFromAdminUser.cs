namespace KitchenApplication.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class RemovedCookiesFromAdminUser : DbMigration
    {
        public override void Up()
        {
            DropColumn("dbo.AdminUsers", "Cookie");
        }
        
        public override void Down()
        {
            AddColumn("dbo.AdminUsers", "Cookie", c => c.String());
        }
    }
}
