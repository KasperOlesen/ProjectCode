namespace KitchenApplication.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedCookieToAdmin : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.AdminUsers", "Cookie", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("dbo.AdminUsers", "Cookie");
        }
    }
}
