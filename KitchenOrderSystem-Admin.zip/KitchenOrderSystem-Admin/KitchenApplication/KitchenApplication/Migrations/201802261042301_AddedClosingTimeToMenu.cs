namespace KitchenApplication.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedClosingTimeToMenu : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Menus", "ClosingTime", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Menus", "ClosingTime");
        }
    }
}
