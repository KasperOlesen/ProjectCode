namespace KitchenApplication.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ReversedOrderUsersToUser : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.UserOrders", "User_Id", "dbo.Users");
            DropForeignKey("dbo.UserOrders", "Order_Id", "dbo.Orders");
            DropIndex("dbo.UserOrders", new[] { "User_Id" });
            DropIndex("dbo.UserOrders", new[] { "Order_Id" });
            AddColumn("dbo.Orders", "User_Id", c => c.Int());
            CreateIndex("dbo.Orders", "User_Id");
            AddForeignKey("dbo.Orders", "User_Id", "dbo.Users", "Id");
            DropTable("dbo.UserOrders");
        }
        
        public override void Down()
        {
            CreateTable(
                "dbo.UserOrders",
                c => new
                    {
                        User_Id = c.Int(nullable: false),
                        Order_Id = c.Int(nullable: false),
                    })
                .PrimaryKey(t => new { t.User_Id, t.Order_Id });
            
            DropForeignKey("dbo.Orders", "User_Id", "dbo.Users");
            DropIndex("dbo.Orders", new[] { "User_Id" });
            DropColumn("dbo.Orders", "User_Id");
            CreateIndex("dbo.UserOrders", "Order_Id");
            CreateIndex("dbo.UserOrders", "User_Id");
            AddForeignKey("dbo.UserOrders", "Order_Id", "dbo.Orders", "Id", cascadeDelete: true);
            AddForeignKey("dbo.UserOrders", "User_Id", "dbo.Users", "Id", cascadeDelete: true);
        }
    }
}
