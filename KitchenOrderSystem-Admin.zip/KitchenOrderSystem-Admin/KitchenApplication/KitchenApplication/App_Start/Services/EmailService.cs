﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Web;
using CsvHelper;
using KitchenApplication.Models.Database;
using WebApplication1.App_Start.Services;
using WebApplication1.Models;

namespace KitchenApplication.Services
{
    public class EmailServiceCustom
    {
        private static EmailServiceCustom instance;
        private static List<MailConfiguration> _emails;
        private string _kitchenEmail;

        public static EmailServiceCustom Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new EmailServiceCustom();
                }
                return instance;
            }
        }

        public EmailServiceCustom()
        {
            _emails = new List<MailConfiguration>();
            _kitchenEmail = ConfigurationManager.AppSettings["kitchen.email"];
        }
        public void AddOutgoingEmail(MailConfiguration mailConfiguration)
        {
            _emails.Add(mailConfiguration);
            mailConfiguration = null;
        }

        public void SendAllEmails()
        {
            MailHandler mh = new MailHandler();
            foreach (var email in _emails)
            {
                mh.SendMail(email);
            }
            FlushEmails();
        }


        public static void FlushEmails()
        {
            _emails.Clear();
        }

        public void OrderNotification(Entity.User user, Entity.Order order)
        {
            string dishes = "";
            foreach (var item in order.MenuItems)
            {
                dishes += (item.FoodItem + " - " + item.Description);
            }

            MailConfiguration mailConf = new MailConfiguration
            {
                Subject = "Your order has been received!",
                Bodytext = "Hi " + user.Name + " Your order: " + "\n" + dishes + "\n" + "If you did not place this order, please contact kitchen staff immediately.",
                Recipients = new[] { user.Email },
                From = new MailAddress(_kitchenEmail)
            };

            AddOutgoingEmail(mailConf);
        }

        public void OrderStatusNotification(Entity.User user, Entity.Order order)
        {
            string dishes = "";
            foreach (var item in order.MenuItems)
            {
                dishes += item.FoodItem + " - " + item.Description;
            }

            MailConfiguration mailConf = new MailConfiguration
            {
                Subject = "The status of your latest order has been changed to " + order.Status,
                Bodytext = "Hi " + user.Name + " Your order: " + "\n" + dishes + "\n" + "If you did not place this order, please contact kitchen staff immediately.",
                Recipients = new[] { user.Email },
                From = new MailAddress(_kitchenEmail)
            };

            AddOutgoingEmail(mailConf);
        }

        public void OrderCancelledNotification(Entity.Order order)
        {
            string dishes = "";
            foreach (var item in order.MenuItems)
            {
                dishes += item.FoodItem + " - " + item.Description;
            }

            MailConfiguration mailConf = new MailConfiguration
            {
                Subject = "Your order today has been cancelled due to changes to the menu",
                Bodytext = "Hi " + order.User.Name + " Your order of: " + "\n" + dishes + "\n" + " has been cancelled due to changes to today's menu. Please place a new order.",
                Recipients = new[] { order.User.Email },
                From = new MailAddress(_kitchenEmail)
            };

            AddOutgoingEmail(mailConf);
        }

        public void FinanceReport(List<MonthlyReportViewModel> report, string recipient)
        {
            
            string fileName =
                @"C:\Users\kponto01\source\repos\KicthenInternalProject\KitchenApplication\KitchenApplication\finances_" +
                DateTime.Now.ToShortDateString() + ".csv";

            FinanceReportService financeReportService = new FinanceReportService(fileName, report, recipient);

            Attachment atc = financeReportService.Report();

            Attachment[] attachments = { atc };

            string[] recipients = { recipient };

            MailConfiguration mailConf = new MailConfiguration
            {
                Subject = "Kitchen finance",
                Bodytext = "See attached file for kitchen order finances",
                Attachments = attachments,
                From = new MailAddress(_kitchenEmail),
                Recipients = recipients
            };
            attachments = null;
            atc = null;
            fileName = null;
            AddOutgoingEmail(mailConf);
        }
    }



    public class MailConfiguration
    {
        public MailAddress From { get; set; }
        public string Subject { get; set; }
        public string Bodytext { get; set; }


        public Attachment[] Attachments { get; set; }
        public string[] Recipients { get; set; }

        public MailConfiguration(MailAddress from, string subject, string bodytext, Attachment[] attachments, string[] recipients)
        {
            Subject = subject;
            Bodytext = bodytext;
            Attachments = attachments;
            From = from;
            Recipients = recipients;

        }
        public MailConfiguration()
        {
        }
    }

    public class MailHandler
    {
        public string Host { get; set; }
        public int Port { get; set; }
        public string MailUser { get; set; }
        public string MailPw { get; set; }
        private readonly SmtpClient _smtp;

        public MailHandler()
        {
            MailUser = "mgntxdev";
            MailPw = "Abcd_1234";
            Host = "smtp.sendgrid.net";
            Port = 25;
            _smtp = new SmtpClient(Host, Port)
            {
                Credentials = new NetworkCredential(MailUser, MailPw)
            };
        }

        public bool SendMail(MailConfiguration mailConf)
        {
            var email = new MailMessage
            {
                From = mailConf.From,
                Body = mailConf.Bodytext,
                Subject = mailConf.Subject
            };

            if (mailConf.Attachments != null)
            {
                foreach (var attachment in mailConf.Attachments)
                {
                    email.Attachments.Add(attachment);
                }
            }

            if (mailConf.Recipients != null)
            {
                foreach (var recipient in mailConf.Recipients)
                {
                    email.To.Add(recipient);
                }
            }

            _smtp.EnableSsl = false;

            bool status = false;

            try
            {
                using (_smtp)
                {
                    _smtp.Send(email);
                }
                //_smtp.Send(email);
                status = true;

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            email.Dispose();
            return status;
        }
    }
}