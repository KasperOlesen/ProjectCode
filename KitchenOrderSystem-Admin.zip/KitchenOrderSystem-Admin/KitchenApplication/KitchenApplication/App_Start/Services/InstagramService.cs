﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Castle.Core.Internal;
using KitchenApplication.Models;
using WebApplication1.Models;

namespace WebApplication1.App_Start.Services
{
    public class InstagramService
    {

        private string _token;
        private ApiService _apiService;
        private MapperService _ms;

        public InstagramService()
        {
            _apiService = new ApiService();
            _token = string.Empty;
            _ms = new MapperService();
        }

        public InstagramService(ApiService apiService, MapperService ms, string token)
        {
            this._apiService = apiService;
            this._token = token;
            this._ms = ms;
        }


        public string GetAccessToken()
        {
            try
            {
                _token = _ms.InstagramData().AccessToken;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                _token = "Failed";
            }
            return _token;
        }

        public string GetInstagramData()
        {
            string data = string.Empty;
            if (_token.IsNullOrEmpty())
            {
                try
                {
                    _token = _ms.InstagramData().AccessToken;

                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    _token = "Failed";
                }
            }

            try
            {
                data = _apiService.GetInstagramDataWithToken(_token);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                data = _apiService.GetLocalImages();
            }

            return data;
        }

        public string GenerateAccessToken(string code)
        {
            _token = _apiService.GetInstagramAccessToken(code);

            if (!_token.IsNullOrEmpty())
            {
                _ms.SetInstagramData(_token, null, null, null);
            }

            return GetInstagramData();
        }
    }
}