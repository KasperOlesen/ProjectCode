﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Web;
using KitchenApplication.Models;

namespace WebApplication1.App_Start.Services
{
    public class DataExpirationHandler
    {
        private bool isRunning;
        public void StartThread()
        {
            if (!isRunning)
            {
                BackgroundWorker work = new BackgroundWorker();
                work.DoWork += new DoWorkEventHandler(DataDeletion);
                work.RunWorkerAsync();
            }
            
        }

        public void DataDeletion(object sender, DoWorkEventArgs e)
        {

            isRunning = true;
            while (true)
            {
                MapEntity me = new MapEntity();

                MapperService ms = new MapperService();

                var orders = ms.AllOrders();
                DateTime today = DateTime.Today;
                foreach (var order in orders)
                {
                    if (today < order.Date.AddMonths(-2))
                    {
                        me.DeleteOrder(order.Id);
                    }
                }
                Thread.Sleep(24 * 60 * 60 * 1000);

            }
            
        }
    }
}