﻿using System.Collections.Generic;
using KitchenApplication.Models.Database;
using WebApplication1.Models;

namespace KitchenApplication.Models
{
    public interface IMapperService
    {
        List<OrderViewModel> AllOrders();
        List<UserViewModel> CreateUsersFromEmployeeApi(string url);
        void DeleteInstagramAccessToken();
        MenuViewModel GetMenu(int menuId);
        List<MonthlyReportViewModel> GetMonthlyReport();
        List<MonthlyReportViewModel> GetMonthlyReport(int month);
        InstagramDataViewModel InstagramData();
        List<MenuItemViewModel> MenuItems(int orderId);
        List<MenuItemViewModel> MenuItemsToMenuItemViewModels(List<Entity.MenuItem> menuItems);
        OrderMenuViewModel OrderMenu(int userId);
        List<OrderViewModel> OrdersByUserEmail(string email);
        List<OrderViewModel> OrdersToday();
        List<OrderViewModel> OrdersToOrderViewModels(List<Entity.Order> orders);
        OrderViewModel OrderToday(int userId);
        List<UserViewModel> RemoveUnlistedUsers(string url);
        void SetInstagramData(string accessToken, string clientId, string clientSecret, string redirectUri);
        MenuViewModel TodaysMenu();
        UserViewModel User(int userId);
        UserViewModel UserData(string email);
        List<UserViewModel> Users();
        List<Employee> UsersAsEmployees();
        List<UserViewModel> UsersToUserViewModels(List<Entity.User> users);
    }
}