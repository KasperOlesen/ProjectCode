﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Web;
using KitchenApplication.Models.Database;
using WebApplication1.Models;
using CsvHelper;
using KitchenApplication;
using KitchenApplication.Models;
using KitchenApplication.Services;

namespace WebApplication1.App_Start.Services
{

    public class MonthlyReport
    {
        public int UserID { get; set; }
        public string Name { get; set; }
        public List<OrderCsvModel> Orders { get; set; }
        public double Total { get; set; }
    }

    public class OrderCsvModel
    {
        public int OrderID { get; set; }
        public DateTime Date { get; set; }
        public double Price { get; set; }
    }

    public class DataExport
    {
        public void ConvertToCsvAndSend(List<MonthlyReportViewModel> mrs, string email)
        {
            List<OrderCsvModel> ocms = new List<OrderCsvModel>();
            List<MonthlyReport> MonthlyReports = new List<MonthlyReport>();
            foreach (var mr in mrs)
            {
                double total = 0;
                foreach (var order in mr.Orders)
                {
                    total += order.Price;
                    ocms.Add(new OrderCsvModel
                    {
                        OrderID = order.Id,
                        Date = order.Date,
                        Price = order.Price
                    });
                }

                MonthlyReports.Add(new MonthlyReport
                {
                    Orders = ocms,
                    UserID = mr.User.Id,
                    Name = mr.User.Name,
                    Total = total
                });
            }

            using (var mem = new MemoryStream())
            using (var writer = new StreamWriter(@"TestCsvOutput.csv"))
            using (var csvWriter = new CsvWriter(writer))
            {
                csvWriter.Configuration.Delimiter = ";";
                //csvWriter.Configuration.HasHeaderRecord = true;
                csvWriter.Configuration.AutoMap<MonthlyReport>();

                csvWriter.WriteHeader<MonthlyReport>();
                csvWriter.WriteRecords("\n");
                csvWriter.WriteRecords(MonthlyReports);

                writer.Flush();
                var result = Encoding.UTF8.GetString(mem.ToArray());
                Console.WriteLine(result);
            }

            var from = new MailAddress("khp@magnetix");
            string subject = "test subject";
            string bodytext = "test body";

            string fileName = @"TestCsvOutput.csv";

            FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            StreamReader s = new StreamReader(fs);


            string[] recipients = { email };

            Attachment atc = new Attachment(fileName);
            Attachment[] attachments = {atc};

            EmailServiceCustom es = new EmailServiceCustom();
            es.AddOutgoingEmail(new MailConfiguration(from, subject, bodytext, attachments, recipients));
            
            es.SendAllEmails();
        }
    }
}