﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using KitchenApplication.Models.Database;

namespace KitchenApplication.App_Start.Services
{
    public class DBTestSetup
    {
        private List<Entity.User> users;
        private List<Entity.MenuItem> menuItems;

        public DBTestSetup()
        {
            users = new List<Entity.User>();
            menuItems = new List<Entity.MenuItem>();
        }


        public void SetupTestMenu()
        {
            Boundary bd = new Boundary();

            var menuItem1 = new Entity.MenuItem { FoodItem = "Ged", Description = "Med hår", Price = 25.0 };
            var menuItem2 = new Entity.MenuItem { FoodItem = "Burger", Description = "med salat", Price = 25.7 };
            var menuItem3 = new Entity.MenuItem { FoodItem = "Hund", Description = "Some text here", Price = 25.3 };
            var menuItem4 = new Entity.MenuItem { FoodItem = "Kylling", Description = "This text is here ere ere", Price = 25.3 };
            var menuItem5 = new Entity.MenuItem { FoodItem = "Horse", Description = "This is a text to test", Price = 25.3 };
            var menuItem6 = new Entity.MenuItem { FoodItem = "Flower", Description = "Green stuff is important too", Price = 25.3 };
            var menuItem7 = new Entity.MenuItem { FoodItem = "Ost", Description = "Dont forget the cheeese!", Price = 25.3 };
            var menuItem8 = new Entity.MenuItem { FoodItem = "Antilope", Description = "Weird animal to have on a menu", Price = 25.3 };
            var menuItem9 = new Entity.MenuItem { FoodItem = "Næsehorn", Description = "Nu bliver det interessant", Price = 25.3 };
            var menuItem10 = new Entity.MenuItem { FoodItem = "Giraf", Description = "Der er langt ned", Price = 25.3 };


            menuItems = new List<Entity.MenuItem> { menuItem1, menuItem2, menuItem3, menuItem4, menuItem5, menuItem6, menuItem7, menuItem8, menuItem9, menuItem10 };

            bd.CreateMenu(menuItems, DateTime.Today, DateTime.Now.AddHours(2));
        }

        public void SetupTestUsers()
        {
            var user1 = new Entity.User
            {
                Name = "Karsten-Arne",
                Location = "Kbh",
                Email = "Karsten-Arne@mail.dk",
                ImageUrl = "image/url/dot/png",
                //MarkedForDeletion = DateTime.MaxValue,
                Orders = new List<Entity.Order>()
            };
            var user2 = new Entity.User
            {
                Name = "Abel-Ort",
                Location = "Århus",
                Email = "abelort@mail.dk",
                ImageUrl = "image/url/dot/png",
                //MarkedForDeletion = DateTime.Now,
                Orders = new List<Entity.Order>()
            };
            var user3 = new Entity.User
            {
                Name = "Androt",
                Location = "Kbh",
                Email = "Androt@mail.dk",
                ImageUrl = "image/url/dot/png",
                //MarkedForDeletion = DateTime.MaxValue,
                Orders = new List<Entity.Order>()
            };
            var user4 = new Entity.User
            {
                Name = "Jar-Jar Binks",
                Location = "Naboo",
                Email = "meesajarjar@mail.dk",
                ImageUrl = "image/url/dot/png",
                //MarkedForDeletion = DateTime.MaxValue,
                Orders = new List<Entity.Order>()
            };
            var user5 = new Entity.User
            {
                Name = "Kasper Hornum Pontoppidan",
                Location = "København",
                Email = "kasperpontoppidan@gmail.com",
                ImageUrl = "image/url/dot/png",
                //MarkedForDeletion = DateTime.MaxValue,
                Orders = new List<Entity.Order>()
            };

            users = new List<Entity.User> { user1, user2, user3, user4, user5 };

            using (var db = new Entity.KitchenAppContext())
            {
                foreach (var user in users)
                {
                    db.Users.Add(user);
                }
                db.SaveChanges();
            }
        }

        public void SetupTestOrders()
        {
            Boundary bd = new Boundary();

            foreach (var user in users)
            {
                var order1 = new Entity.Order
                {
                    Date = DateTime.Now,
                    Comment = "riigeligt smør",
                    MenuItems = menuItems,
                    DeliveryType = "pickup",
                    User = user
                };
                bd.CreateOrder(order1, users);
            }

            foreach (var user in users)
            {
                var order1 = new Entity.Order
                {
                    Date = DateTime.Now,
                    Comment = "riigeligt smør2",
                    MenuItems = menuItems,
                    DeliveryType = "late lunch",
                    User = user
                };
                bd.CreateOrder(order1, users);
            }
            var order = new Entity.Order
            {
                Date = DateTime.Now,
                Comment = "riigeligt smør2",
                MenuItems = menuItems,
                DeliveryType = "Meeting",
                User = users[0]
            };

            bd.CreateOrder(order, new List<Entity.User> {users[0]});
        }

        public void FlushTestDB()
        {
            using (var db = new Entity.KitchenAppContext())
            {
                db.Orders.RemoveRange(db.Orders);
                db.Users.RemoveRange(db.Users);
                db.Menus.RemoveRange(db.Menus);
                db.MenuItems.RemoveRange(db.MenuItems);
                db.AdminUsers.RemoveRange(db.AdminUsers);
                db.SaveChanges();
            }
        }

        public void CreateTemporaryAdminUser()
        {
            using (var db = new Entity.KitchenAppContext())
            {
                var adminUsers = db.AdminUsers.ToList();

                if (!adminUsers.Any())
                {
                    db.AdminUsers.Add(new Entity.AdminUser
                    {
                        UserName = "admin",
                        Password = "kitchen"
                    });
                    db.SaveChanges();
                }
            }
        }
    }
}