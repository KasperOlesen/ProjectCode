﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using KitchenApplication.Models.Database;

namespace WebApplication1.App_Start.Services
{
    public class Auth
    {
        public Entity.AdminUser AdminLogin(string email, string password)
        {
            return new Boundary().AdminLogin(email, password);
        }
    }
}