﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Web;
using CsvHelper;
using KitchenApplication.Services;
using WebApplication1.Models;

namespace WebApplication1.App_Start.Services
{
    public class FinanceReportService
    {
        private string _fileName;
        private List<MonthlyReportViewModel> _reports;
        private string _recipient;

        public FinanceReportService(string fileName, List<MonthlyReportViewModel> reports, string recipient)
        {
            _fileName = fileName;
            _reports = reports;
            _recipient = recipient;
        }
        public Attachment Report()
        {
            List<OrderCsvModel> ocms = new List<OrderCsvModel>();
            List<MonthlyReport> MonthlyReports = new List<MonthlyReport>();
            foreach (var mr in _reports)
            {
                double total = 0;
                foreach (var order in mr.Orders)
                {
                    total += order.Price;
                    ocms.Add(new OrderCsvModel
                    {
                        OrderID = order.Id,
                        Date = order.Date,
                        Price = order.Price
                    });
                }

                MonthlyReports.Add(new MonthlyReport
                {
                    Orders = ocms,
                    UserID = mr.User.Id,
                    Name = mr.User.Name,
                    Total = total
                });
            }

            using (var mem = new MemoryStream())
            using (var writer = new StreamWriter(_fileName))
            using (var csvWriter = new CsvWriter(writer))
            {
                csvWriter.Configuration.Delimiter = ";";
                csvWriter.Configuration.AutoMap<MonthlyReport>();

                csvWriter.WriteHeader<MonthlyReport>();
                csvWriter.WriteRecords("\n");
                csvWriter.WriteRecords(MonthlyReports);
            }

            Attachment atc = new Attachment(_fileName);

            return atc;
        }
    }
}