﻿
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using System.Web.UI;
using Castle.Core.Internal;
using KitchenApplication.App_Start.Services;
using KitchenApplication.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using WebApplication1.App_Start.Services;
using WebApplication1.Models;

namespace KitchenApplication.Controllers
{

    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            DBTestSetup dbt = new DBTestSetup();
            dbt.FlushTestDB();
            dbt.CreateTemporaryAdminUser();
            dbt.SetupTestUsers();
            dbt.SetupTestMenu();
            dbt.SetupTestOrders();
            return RedirectToAction("Index", "Menu");
        }
    }
}
