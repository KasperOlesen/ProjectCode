﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using Castle.Core.Internal;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class EmployeeController : ApiController
    {
        private static List<Employee> employeeList = null;
        private static object _lock = new object();
        [HttpGet]
        [Route("api/Employee/GetAll")]
        public List<Employee> GetAll()
        {
            BuildEmployeeListIfEmpty();
            return employeeList;
        }


        private void BuildEmployeeListIfEmpty()
        {
            if (employeeList == null)
            {

                lock (_lock)
                {
                    if (employeeList == null)
                    {
                        string imageUrlPath = "/EmployeeImages/ImageCache/";
                        string ldapPath = ConfigurationManager.AppSettings["LDAPSettings"];
                        //string imagePath = HttpContext.Current.Server.MapPath(imageUrlPath);

                        //Directory.CreateDirectory(imagePath);

                        List<Employee> tempList = new List<Employee>();
                        DirectorySearcher search = new DirectorySearcher(new DirectoryEntry(ldapPath, "device", "Abcd_1234"));

                        search.Filter = "(&(objectClass=user)(objectCategory=person))";

                        search.PropertiesToLoad.Add("objectGUID");
                        search.PropertiesToLoad.Add("mail");
                        search.PropertiesToLoad.Add("displayname");
                        search.PropertiesToLoad.Add("thumbnailPhoto");
                        search.PropertiesToLoad.Add("memberOf");
                        search.PropertiesToLoad.Add("department");
                        search.PropertiesToLoad.Add("givenName");
                        search.PropertiesToLoad.Add("sn");
                        search.PropertiesToLoad.Add("title");
                        search.PropertiesToLoad.Add("sAMAccountName");
                        search.PropertiesToLoad.Add("Mobile");
                        search.PropertiesToLoad.Add("Manager");
                        search.PropertiesToLoad.Add("Co");
                        search.PropertiesToLoad.Add("Company");
                        search.PropertiesToLoad.Add("userAccountControl");


                        SearchResultCollection results = search.FindAll();
                        foreach (SearchResult result in results)
                        {
                            int status = (int)result.Properties["userAccountControl"][0];
                            if (status == 514 || status == 66050)
                            {
                                continue;
                            }

                            bool inMagnetixGroup = false;

                            foreach (var m in result.Properties["memberOf"])
                            {
                                string group = m.ToString();
                                if (group.Contains("CN=\\#UG-M-O365-Exclaimer-DKCPH2-Magnetix-Signature"))
                                {
                                    inMagnetixGroup = true;
                                    break;
                                }
                            }

                            if (inMagnetixGroup)
                            {


                                Employee e = new Employee();
                                e.Id = new Guid(result.Properties["objectGUID"][0] as byte[]);




                                if (result.Properties["thumbnailPhoto"].Count > 0)
                                {
                                    string fileName = result.Properties["DisplayName"][0].ToString().ToLower().Replace(" ", "-") + ".jpg";
                                    //e.OriginalImageFilePath = Request.RequestUri.Scheme + "://" + Request.RequestUri.Authority + imageUrlPath + fileName;
                                    

                                    byte[] bytesFromAd = result.Properties["thumbnailPhoto"][0] as byte[];
                                    using (MemoryStream ms = new MemoryStream())
                                    {
                                        ms.Write(bytesFromAd, 0, bytesFromAd.Length);
                                        ms.Position = 0L;
                                        var image = Image.FromStream(ms);
                                        //image.Save(imagePath + fileName);
                                        image.Dispose();
                                    }
                                }
                                else
                                {
                                    //e.OriginalImageFilePath = Request.RequestUri.Scheme + "://" + Request.RequestUri.Authority + "/EmployeeImages/" + "Unknown.jpg";

                                }
                                

                                e.GivenName = result.Properties["givenName"].Count > 0 ? result.Properties["givenName"][0].ToString() : "";
                                e.LastName = result.Properties["sn"].Count > 0 ? result.Properties["sn"][0].ToString() : "";
                                e.DisplayName = result.Properties["displayname"][0].ToString();
                                e.Department = result.Properties["department"].Count > 0 ? result.Properties["department"][0].ToString() : "";
                                e.Email = result.Properties["mail"].Count > 0 ? result.Properties["mail"][0].ToString() : "";
                                e.Title = result.Properties["title"].Count > 0 ? result.Properties["title"][0].ToString() : "";
                                e.ADUsername = result.Properties["sAMAccountName"].Count > 0 ? result.Properties["sAMAccountName"][0].ToString() : "";
                                e.Mobile = result.Properties["Mobile"].Count > 0 ? result.Properties["Mobile"][0].ToString() : "";
                                e.Country = result.Properties["Co"].Count > 0 ? result.Properties["Co"][0].ToString() : "";
                                e.Company = result.Properties["Company"].Count > 0 ? result.Properties["Company"][0].ToString() : "";
                                e.Manager = result.Properties["Manager"].Count > 0 ? result.Properties["Manager"][0].ToString() : "";
                                //e.ADGroups = groups;

                                tempList.Add(e);

                            }
                        }

                        foreach (var temp in tempList)
                        {
                            if (!temp.Manager.IsNullOrEmpty())
                            {
                                if (tempList.Any(x => x.DisplayName == temp.Manager.Split(',')[0].Split('=')[1]))
                                {
                                    temp.Manager = tempList.SingleOrDefault(x => x.DisplayName == temp.Manager.Split(',')[0].Split('=')[1]).Id.ToString();
                                }
                            }
                        }
                        employeeList = tempList;
                    }
                }
            }
        }


        [HttpGet]
        [Route("api/Employee/GetByDisplayName/{displayName}")]
        public Employee GetByDisplayName(string displayName)
        {
            BuildEmployeeListIfEmpty();
            return employeeList.Where(x => x.DisplayName.Equals(displayName, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();

        }
        [HttpGet]
        [Route("api/Employee/GetById/{Id}")]
        public Employee GetById(Guid Id)
        {
            BuildEmployeeListIfEmpty();
            return employeeList.Where(x => x.Id == Id).FirstOrDefault();

        }
        [HttpGet]
        [Route("api/Employee/GetByADUsername/{username}")]
        public Employee GetByADUsername(string username)
        {
            BuildEmployeeListIfEmpty();
            return employeeList.Where(x => x.ADUsername.Equals(username, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();

        }
    }
}