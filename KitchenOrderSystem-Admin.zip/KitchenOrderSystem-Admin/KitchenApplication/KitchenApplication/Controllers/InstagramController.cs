﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class InstagramController : Controller
    {
        // GET: Instagram
        public ActionResult Index()
        {
            string code = string.Empty;
            if (!string.IsNullOrEmpty(Request["code"]))
            {
                code = Request["code"].ToString();
            }
            TempData["instacode"] = code;
            return RedirectToAction("Index", "Menu", new {area = ""});
        }
    }
}