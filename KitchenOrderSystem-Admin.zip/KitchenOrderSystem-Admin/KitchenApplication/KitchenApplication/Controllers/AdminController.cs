﻿using System;
using System.Web;
using System.Web.Mvc;
using KitchenApplication.Models;
using Newtonsoft.Json;
using WebApplication1.App_Start.Services;
using WebApplication1.Models;
using System.Web.Security;
using Castle.Core.Internal;
using KitchenApplication.Models.Database;
using KitchenApplication.Services;

namespace WebApplication1.Controllers
{
    [Authorize(Roles = "admin")]
    public class AdminController : Controller
    {

        [AllowAnonymous]
        public ActionResult Index()
        {
            return RedirectToAction("Menu");
        }

        public ActionResult Menu()
        {
            var model = new MapperService().TodaysMenu();

            //var model = new MapperServiceDAL().TodaysMenu();

            return View(model);
        }

        [Route("admin/orders/today")]
        public ActionResult Orders()
        {
            var model = new MapperService().OrdersToday();

            //var model = new MapperServiceDAL().OrdersToday();

            return View(model);
        }

        public ActionResult OrdersByEmail()
        {
            var model = new MapperService().OrdersByUserEmail(HttpContext.Request.Headers.Get("email"));

            //var model = new MapperServiceDAL().OrdersByUserEmail(HttpContext.Request.Headers.Get("email"));

            return View(model);
        }

        [HttpPost]
        public ActionResult Menu(MenuViewModel mvm)
        {

            MapEntity pm = new MapEntity();
            var result = pm.CreateMenu(mvm.MenuItems, mvm.Date, mvm.ClosingTime);

            //var result = new MapperServiceDAL().CreateMenu(mvm);

            var json = JsonConvert.SerializeObject(result);

            return new ContentResult { Content = json, ContentType = "application/json" };
        }

        [HttpPut]
        public ActionResult OrderStatus(OrderStatusViewModel osvm)
        {

            string json = "";
            if (osvm.Equals(null))
            {
                json = JsonConvert.SerializeObject("Orders invalid");
            }
            else
            {
                MapEntity pm = new MapEntity();

                var result = pm.ChangeOrderStatus(osvm);

                json = JsonConvert.SerializeObject(result);
            }
            return new ContentResult { Content = json, ContentType = "application/json" };
        }

        [HttpPost]
        public ActionResult DeleteHistory(string email)
        {
            var result = new MapEntity().DeleteHistory(email);

            var json = JsonConvert.SerializeObject(result);

            return new ContentResult { Content = json, ContentType = "application/json" };
        }

        [HttpPost]
        public ActionResult DeleteOrder(string id)
        {
            var result = new MapEntity().DeleteOrder(Int32.Parse(id));

            var json = JsonConvert.SerializeObject(result);

            return new ContentResult { Content = json, ContentType = "application/json" };
        }

        public ActionResult UserData(string email)
        {
            UserViewModel model = new UserViewModel();
            if (!email.IsNullOrEmpty())
            {
                model = new MapperService().UserData(email);
            }

            var json = JsonConvert.SerializeObject(model);

            return new ContentResult { Content = json, ContentType = "application/json" };
        }

        public ActionResult Finance()
        {
            var model = new MapperService().GetMonthlyReport();

            return View(model);
        }

        public ActionResult MonthlyOrders(string month)
        {
            var model = new MapperService().GetMonthlyReport(Int32.Parse(month));

            var json = JsonConvert.SerializeObject(model);

            return new ContentResult { Content = json, ContentType = "application/json" };
        }

        [HttpPost]
        public ActionResult MonthlyReportToEmail(string email)
        {

            EmailServiceCustom esc = EmailServiceCustom.Instance;
            esc.FinanceReport(new MapperService().GetMonthlyReport(), email);
            esc.SendAllEmails();
            return new ContentResult { Content = JsonConvert.SerializeObject("Email sent"), ContentType = "application/json" };
        }

        public ActionResult RemoveUnlistedUsers()
        {
            var model = new MapperService().RemoveUnlistedUsers("http://kitchenproject/api/employee/GetAll");

            var json = JsonConvert.SerializeObject(model);

            return new ContentResult { Content = json, ContentType = "application/json" };
        }

        public ActionResult LogOff()
        {
            return RedirectToAction("LogOff", "Account");
        }

        public ActionResult Advanced()
        {
            return View();
        }

        public ActionResult AcceptAllOrders()
        {
            new MapperService().AcceptAllOrders();

            return RedirectToAction("Advanced", "Admin");
        }

        public ActionResult Users()
        {
            var model = new MapperService().Users();

            var json = JsonConvert.SerializeObject(model);

            return View(model);
        }
    }
}