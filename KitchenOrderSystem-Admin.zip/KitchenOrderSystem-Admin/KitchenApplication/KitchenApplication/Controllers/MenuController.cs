﻿using System;
using System.Configuration;
using System.Web.Mvc;
using Castle.Core.Internal;
using KitchenApplication.Models;
using Newtonsoft.Json;
using WebApplication1.App_Start.Services;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class MenuController : Controller
    {
        private static string code = string.Empty;
        private string data = string.Empty;
        public ActionResult Index()
        {
            InstagramService instagramService = new InstagramService();

            data = instagramService.GetInstagramData();

            if (data.IsNullOrEmpty())
            {
                code = TempData["instacode"] as string;
                if (!code.IsNullOrEmpty())
                {
                    data = instagramService.GenerateAccessToken(code);
                }
                else
                {
                    var clientId = ConfigurationManager.AppSettings["instagram.clientid"];
                    var redirectUri = ConfigurationManager.AppSettings["instagram.redirecturi"];
                    Response.Redirect("https://api.instagram.com/oauth/authorize/?client_id=" + clientId +
                                      "&redirect_uri=" + redirectUri + "&response_type=code");
                }
            }

            var menuViewModel = new MapperService().TodaysMenu();

            var model = new InstagramMenuViewModel { Data = data, MenuVm = menuViewModel };

            return View(model);
        }
    }
}