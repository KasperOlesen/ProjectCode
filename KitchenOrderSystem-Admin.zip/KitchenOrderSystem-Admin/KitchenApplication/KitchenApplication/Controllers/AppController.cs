﻿using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using KitchenApplication.Models;
using Newtonsoft.Json;
using WebApplication1.App_Start.Services;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class AppController : Controller
    {
        public ActionResult Index()
        {
            var model = new MapperService().Users();

            return View(model);
        }


        public ActionResult Order(string id)
        {
            MapperService ms = new MapperService();
            var model = ms.OrderMenu(Int32.Parse(id));

            return View(model);
        }

        [HttpPost]
        public ActionResult Order(OrderViewModel ovm)
        {
            MapEntity pm = new MapEntity();

            var result = pm.CreateOrder(ovm);

            var json = JsonConvert.SerializeObject(result);

            return new ContentResult { Content = json, ContentType = "application/json" };

            //MapperServiceDAL msd = new MapperServiceDAL();

            //var result = msd.CreateOrder(ovm);

            //var json = JsonConvert.SerializeObject(result);

            //return new ContentResult { Content = json, ContentType = "application/json" };
        }

        [HttpPut]
        public ActionResult CancelOrder(OrderStatusViewModel osvm)
        {
            MapEntity pm = new MapEntity();

            var result = pm.ChangeOrderStatus(osvm);

            var json = JsonConvert.SerializeObject(result);

            return new ContentResult { Content = json, ContentType = "application/json" };
        }

        public ActionResult Users()
        {
            var model = new MapperService().UsersAsEmployees();

            var json = JsonConvert.SerializeObject(model);

            return new ContentResult { Content = json, ContentType = "application/json" };
        }

        public ActionResult Employees()
        {
            //var model = new MapperService().CreateUsersFromEmployeeApi("https://employeeapi.prod.ibn.host/api/Employee/GetAll");

            var model = new MapperService().CreateUsersFromEmployeeApi("http://kitchenproject/api/employee/GetAll");

            //var model = new MapperService().Users();

            var json = JsonConvert.SerializeObject(model);

            return new ContentResult { Content = json, ContentType = "application/json" };
        }
    }
}