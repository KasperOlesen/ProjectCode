﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using KitchenApplication.Models.Database;
using WebApplication1.Models;

namespace KitchenApplication.Models
{
    public class MenuViewModel
    {
        public int Id { get; set; }
        public DateTime ClosingTime { get; set; }
        public DateTime Date { get; set; }
        public List<MenuItemViewModel> MenuItems { get; set; }

        public override string ToString()
        {
            return $"Id: {Id}, ClosingTime: {ClosingTime}, Date: {Date}, MenuItems: {MenuItems}";
        }
    }
}