﻿using System;
using System.Collections.Generic;

namespace KitchenApplication.Models.Database
{
    public interface IBoundary
    {
        List<Entity.User> AddUsers(List<Entity.User> usersList);
        Entity.AdminUser AdminLogin(string email, string password);
        List<Entity.Order> ChangeOrderStatus(List<Entity.Order> orders);
        bool CreateMenu(List<Entity.MenuItem> menuItems, DateTime date, DateTime closingTime);
        string CreateOrder(Entity.Order order, List<Entity.User> users);
        void CreateUser(Entity.User user);
        void DeleteAccessToken();
        bool DeleteOrder(int orderId);
        bool DeleteUser(int userId);
        List<Entity.Order> GetAcceptedOrdersByMonth(int month);
        List<Entity.Order> GetAllOrders();
        List<Entity.User> GetAllUsers();
        Entity.InstagramData GetInstagramData();
        Entity.Order GetLatestOrderByUserEmail(string email);
        Entity.Menu GetMenu(int menuId);
        Entity.Menu GetMenuByDate(DateTime date);
        Entity.MenuItem GetMenuItem(int id);
        List<Entity.MenuItem> GetMenuItemsByOrderId(int orderId);
        List<Entity.User> GetMonthlyReport();
        List<Entity.User> GetMonthlyReport(int month);
        Entity.Order GetOrder(int orderId);
        List<Entity.Order> GetOrdersByDate(DateTime date);
        List<Entity.Order> GetOrdersByMonth(int month);
        List<Entity.Order> GetOrdersByUser(Entity.User user);
        List<Entity.Order> GetOrdersByUserEmail(string email);
        List<Entity.Order> GetOrdersToday();
        Entity.Order GetOrderTodayByUser(int userId);
        Entity.User GetUser(int id);
        Entity.User GetUserData(string email);
        List<Entity.User> GetUserOrdersByDate(DateTime date);
        List<Entity.User> RemoveUnlistedUsers(List<Entity.User> usersList);
        void SetDbContext(Entity.KitchenAppContext kitchenAppContext);
        void SetInstagramData(Entity.InstagramData instagramData);
        void AcceptAllOrders();
        void DeleteExpiredOrders(DateTime today);
    }
}