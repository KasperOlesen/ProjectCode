﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using Castle.Core.Internal;
using KitchenApplication.Services;
using Newtonsoft.Json;
using WebApplication1.App_Start.Services;
using WebApplication1.Models;
using WebApplication1.Models.Database;
using static KitchenApplication.Models.Database.Entity;

namespace KitchenApplication.Models.Database
{
    public class Boundary : IBoundary
    {
        private KitchenAppContext _kitchenAppContext;
        public Boundary()
        {
            _kitchenAppContext = new KitchenAppContext();
        }

        public Boundary(KitchenAppContext kitchenAppContext)
        {
            _kitchenAppContext = kitchenAppContext;
        }

        public void SetDbContext(KitchenAppContext kitchenAppContext)
        {
            _kitchenAppContext = kitchenAppContext;
        }

        public Order GetOrderTodayByUser(int userId)
        {
            Order order = new Order();
            DateTime today = DateTime.Today;
            using (var db = new KitchenAppContext())
            {
                if (db.Orders.Any(o =>
                    o.User.Id == userId && o.Date.Year == today.Year && o.Date.Month == today.Month &&
                    o.Date.Day == today.Day))
                {
                    order = db.Orders.Include(o => o.User).Include(o => o.MenuItems).Single(o => o.User.Id == userId && o.Date.Year == today.Year && o.Date.Month == today.Month && o.Date.Day == today.Day);
                }

            }
            new Log<Order>(order).Read();
            return order;
        }

        public List<Order> GetOrdersByUserEmail(string email)
        {
            List<Order> orders = new List<Order>();

            using (var db = new KitchenAppContext())
            {
                orders = db.Orders.Include(o => o.MenuItems).Include(o => o.User).Where(o => o.User.Email == email).ToList();
            }
            new Log<List<Order>>(orders).Read();
            return orders;
        }

        public List<Order> GetOrdersByMonth(int month)
        {
            List<Order> orders = new List<Order>();

            using (var db = new KitchenAppContext())
            {
                orders = db.Orders.Where(o => o.Date.Month == month).ToList();
            }
            new Log<List<Order>>(orders).Read();
            return orders;
        }

        public List<User> GetAllUsers()
        {
            List<User> users = new List<User>();
            //Get all users ordered by name A - Z
            using (var db = new KitchenAppContext())
            {
                var query = db.Users.Include(u => u.Orders).ToList();
                users = query;
            }
            new Log<List<User>>(users).Read();
            return users;
        }

        public List<User> GetUserOrdersByDate(DateTime date)
        {
            List<User> users = new List<User>();
            using (var db = new KitchenAppContext())
            {
                var query = db.Users
                            .Include(u => u.Orders).ToList();

                foreach (var user in query)
                {
                    users.Add(new User { Email = user.Email, Location = user.Location, Name = user.Name, Id = user.Id, Orders = user.Orders.Where(o => o.Date == date).ToList() });
                }
            }
            new Log<List<User>>(users).Read();
            return users;
        }

        public User GetUserData(string email)
        {
            User user = new User();

            List<Order> orders = new List<Order>();

            List<MenuItem> menuItems = new List<MenuItem>();

            using (var db = new KitchenAppContext())
            {
                user = db.Users.Include(u => u.Orders).Single(u => u.Email == email);

                foreach (var order in user.Orders)
                {
                    menuItems = db.Orders.Include(o => o.MenuItems).Single(o => o.Id == order.Id).MenuItems;
                    orders.Add(new Order
                    {
                        Comment = order.Comment,
                        Date = order.Date,
                        DeliveryType = order.DeliveryType,
                        Id = order.Id,
                        KitchenComment = order.KitchenComment,
                        MenuItems = menuItems,
                        Status = order.Status,
                        TotalPrice = order.TotalPrice,
                        User = user
                    });
                }
            }
            user.Orders = orders;
            return user;
        }

        public List<MenuItem> GetMenuItemsByOrderId(int orderId)
        {
            List<MenuItem> menuItems = new List<MenuItem>();

            using (var db = new KitchenAppContext())
            {
                var query = db.MenuItems.Where(m => m.Orders.Any(o => o.Id == orderId));

                foreach (var menuItem in query)
                {
                    menuItems.Add(menuItem);
                }
            }

            return menuItems;
        }

        public List<Order> GetOrdersByDate(DateTime date)
        {
            List<Order> orders = new List<Order>();

            using (var db = new KitchenAppContext())
            {
                var query = db.Orders.Include(o => o.User).Include(o => o.MenuItems).Where(o => o.Date == date).ToList();

                orders = query;
            }
            new Log<List<Order>>(orders).Read();
            return orders;
        }

        public List<Order> GetOrdersByUser(User user)
        {
            List<Order> orders = null;

            using (var db = new KitchenAppContext())
            {
                var query = db.Users.Find(user.Id);

                try
                {
                    orders = query.Orders;
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e);
                }
            }
            new Log<List<Order>>(orders).Read();
            return orders;
        }

        public List<Order> GetOrdersToday()
        {
            List<Order> orders;

            DateTime today = DateTime.Today;

            using (var db = new KitchenAppContext())
            {
                var query = db.Orders.Include(o => o.User).Include(o => o.MenuItems).Where(o => o.Date.Year == today.Year && o.Date.Month == today.Month && o.Date.Day == today.Day && o.Status == "Pending");
                orders = query.ToList();
            }
            new Log<List<Order>>(orders).Read();
            return orders;
        }

        public Order GetOrder(int orderId)
        {
            Order order;

            using (var db = new KitchenAppContext())
            {
                if (db.Orders.Any(o => o.Id == orderId))
                {
                    order = db.Orders.Include(o => o.MenuItems).SingleOrDefault(o => o.Id == orderId);
                }
                else
                {
                    order = new Order();
                }
            }
            new Log<Order>(order).Read();
            return order;
        }

        public Order GetLatestOrderByUserEmail(string email)
        {
            Order order;
            Order newOrder = new Order();
            using (var db = new KitchenAppContext())
            {
                //var query = db.Users
                //    .Include(u => u.Orders)

                //users = db.Users.Where(u => u.Email == email).ToList();
                var query = db.Users.Where(u => u.Email == email)
                    .Include(u => u.Orders);

                try
                {
                    //var q = query.First().Orders[0].MenuItems;
                    order = query.FirstOrDefault().Orders.OrderByDescending(o => o.Date).FirstOrDefault();
                    newOrder.Date = order.Date;
                    newOrder.Status = order.Status;
                    newOrder.Comment = order.Comment;
                    newOrder.KitchenComment = order.KitchenComment;
                    newOrder.DeliveryType = order.DeliveryType;
                    newOrder.Id = order.Id;
                    newOrder.MenuItems = order.MenuItems;
                    double sum = 0.0;
                    foreach (var item in newOrder.MenuItems)
                    {
                        sum += item.Price;
                    }
                    newOrder.TotalPrice = sum;
                }
                catch (NullReferenceException e)
                {
                    Console.WriteLine(e);
                }
            }
            new Log<Order>(newOrder).Read();
            return newOrder;
        }

        public void CreateUser(User user)
        {
            using (var db = new KitchenAppContext())
            {
                db.Users.Add(user);
                db.SaveChanges();
            }
            new Log<User>(user).Write();
        }

        public List<Order> GetAcceptedOrdersByMonth(int month)
        {
            List<Order> orders;

            using (var db = new KitchenAppContext())
            {
                var query = db.Orders.Include(o => o.User).Where(o => o.Date.Month == month && o.Status == "Accepted");

                orders = query.ToList();
            }
            new Log<List<Order>>(orders).Read();
            return orders;
        }

        public Menu GetMenuByDate(DateTime date)
        {
            Menu menu;
            using (var db = new KitchenAppContext())
            {
                var query = db.Menus
                    .Where(m => m.Date == date).Include(m => m.MenuItems).FirstOrDefault();
                menu = query;
            }
            new Log<Menu>(menu).Read();
            return menu;
        }

        public Menu GetMenu(int menuId)
        {
            Menu menu;
            using (var db = new KitchenAppContext())
            {
                var query = db.Menus
                    .Where(m => m.Id == menuId).Include(m => m.MenuItems).FirstOrDefault();
                menu = query;
            }
            new Log<Menu>(menu).Read();
            return menu;
        }


        public bool CreateMenu(List<MenuItem> menuItems, DateTime date, DateTime closingTime)
        {

            Menu menu = new Menu();
            DateTime today = DateTime.Today;
            menu.MenuItems = new List<MenuItem>();
            menu.MenuItems.AddRange(menuItems);
            menu.Date = date;
            menu.ClosingTime = closingTime;

            bool result;
            using (var db = new KitchenAppContext())
            {
                if (db.Menus.Any(m => m.Date == date))
                {
                    var currentMenu = db.Menus.Where(m => m.Date == date).Include(m => m.MenuItems).Single();
                    var ordersToday = db.Orders.Where(o =>
                        o.Date.Year == today.Year && o.Date.Month == today.Month && o.Date.Day == today.Day).ToList();

                    db.Orders.RemoveRange(ordersToday);
                    db.MenuItems.RemoveRange(currentMenu.MenuItems);
                    db.Menus.Remove(currentMenu);
                }
                db.Menus.Add(menu);
                result = db.SaveChanges() > 0;
            }
            return result;
        }

        public User GetUser(int id)
        {
            User user;
            using (var db = new KitchenAppContext())
            {
                user = db.Users.SingleOrDefault(u => u.Id == id);
            }
            new Log<User>(user).Read();
            return user;
        }


        public List<Order> GetAllOrders()
        {

            List<Order> orders = new List<Order>();

            using (var db = new KitchenAppContext())
            {
                try
                {
                    orders = db.Orders.Include(o => o.User).Include(o => o.MenuItems).ToList();
                }
                catch (InvalidOperationException e)
                {
                    Console.WriteLine(e);
                }
            }
            new Log<List<Order>>(orders).Read();
            return orders;
        }

        public string CreateOrder(Order order, List<User> users)
        {

            //EmailServiceCustom es = new EmailServiceCustom();
            //double sum = 0;
            //foreach (var item in order.MenuItems)
            //{
            //    sum += item.Price;
            //}
            order.TotalPrice = 50;
            //DateTime today = DateTime.Today;
            bool result;

            using (var db = new KitchenAppContext())
            {

                List<MenuItem> mi = new List<MenuItem>();

                List<User> errorUsers = new ValidationHelpers().OrderTypeExistsForUsersToday(order, users);

                if (errorUsers.Count > 0)
                {
                    string error = "ERROR: ";

                    foreach (var u in errorUsers)
                    {
                        error += u.Name + ", ";
                    }

                    if (errorUsers.Count == 1)
                    {
                        error += "has already placed an order of type [" + order.DeliveryType + "] today!";
                    }
                    else
                    {
                        error += "have already placed an order of type [" + order.DeliveryType + "] today!";
                    }
                    return error;
                }

                foreach (var item in order.MenuItems)
                {
                    MenuItem menuItem = db.MenuItems.Single(m => m.Id == item.Id);
                    db.MenuItems.Single(m => m.Id == menuItem.Id).OrderCount += 1;
                    mi.Add(menuItem);
                }

                foreach (var user in users)
                {
                    //foreach (var item in order.MenuItems)
                    //{
                    //    db.MenuItems.First(m => m.Id == item.Id).Orders;
                    //}
                    db.Users.First(u => u.Id == user.Id).Orders.Add(new Order
                    {
                        Comment = order.Comment,
                        Date = order.Date,
                        DeliveryType = order.DeliveryType,
                        KitchenComment = order.KitchenComment,
                        MenuItems = mi,
                        TotalPrice = order.TotalPrice,
                        Status = "Pending"
                    });
                }
                //es.OrderNotification(user, GetLatestOrderByUserEmail(user.Email));

                result = db.SaveChanges() > 0;
            }
            new Log<Order>(order).Write();

            //es.SendAllEmails();
            return result ? "Order placed successfully" : "Failed to place order";
        }


        public List<Order> ChangeOrderStatus(List<Order> orders)
        {
            //User user;
            List<Order> pendingOrders = new List<Order>();
            using (var db = new KitchenAppContext())
            {
                foreach (var order in orders)
                {
                    if (order.Id != 0)
                    {

                        //user = db.Users.SingleOrDefault(u => u.Orders.Any(o => o.Id == orderId));
                        db.Orders.SingleOrDefault(x => x.Id == order.Id).Status = order.Status;
                        if (!order.KitchenComment.IsNullOrEmpty())
                        {
                            db.Orders.SingleOrDefault(x => x.Id == order.Id).KitchenComment = order.KitchenComment;
                        }
                        db.Orders.SingleOrDefault(x => x.Id == order.Id).TotalPrice = order.TotalPrice;
                        db.SaveChanges();
                        //order = db.Orders.Include(o => o.MenuItems).SingleOrDefault(o => o.Id == orderId);
                        pendingOrders = db.Orders.Where(x => x.Status == "Pending").Include(x => x.User).Include(x => x.MenuItems).ToList();
                    }
                }
            }

            //order = new Order();
            //EmailServiceCustom es = new EmailServiceCustom();
            //es.OrderStatusNotification(user, order);
            //es.SendAllEmails();
            return pendingOrders;
        }

        public MenuItem GetMenuItem(int id)
        {
            MenuItem menuItem;
            using (var db = new KitchenAppContext())
            {
                menuItem = db.MenuItems.SingleOrDefault(mi => mi.Id == id);
            }
            new Log<MenuItem>(menuItem).Read();
            return menuItem;
        }

        public bool DeleteUser(int userId)
        {
            bool result;
            using (var db = new KitchenAppContext())
            {
                var user = db.Users.Single(u => u.Id == userId);
                var orders = db.Orders.Where(o => o.User.Id == userId);
                db.Orders.RemoveRange(orders);
                db.Users.Remove(user);
                result = db.SaveChanges() > 0;
            }
            return result;
        }

        public int DeleteHistory(string email, DateTime today)
        {
            DateTime todayMinusTwoMonths = today.AddMonths(-2);
            int result = 0;
            using (var db = new KitchenAppContext())
            {
                var user = db.Users.Single(u => u.Email == email);
                var orders = db.Orders.Where(o => o.User.Id == user.Id && o.Date < todayMinusTwoMonths);
                if (orders.Any())
                {
                    db.Orders.RemoveRange(orders);
                    result = orders.Count();
                }
                db.SaveChanges();
            }
            return result;
        }

        public bool DeleteOrder(int orderId)
        {
            bool result;
            using (var db = new KitchenAppContext())
            {
                var order = db.Orders.Single(o => o.Id == orderId);
                db.Orders.Remove(order);
                result = db.SaveChanges() > 0;
            }

            return result;
        }

        public List<User> GetMonthlyReport()
        {
            List<User> users = new List<User>();
            int thisMonth = DateTime.Today.Month;
            List<Order> orders = new List<Order>();
            List<MenuItem> menuItems = new List<MenuItem>();
            using (var db = new KitchenAppContext())
            {

                var query = db.Users.Include(u => u.Orders).Where(u => u.Orders.Any(o => o.Status.Equals("Accepted") && o.Date.Month == thisMonth && o.Date.Year == DateTime.Today.Year)).ToList();

                foreach (var user in query)
                {
                    orders = user.Orders.Where(o =>
                            o.Status.Equals("Accepted") && o.Date.Month == thisMonth &&
                            o.Date.Year == DateTime.Today.Year)
                        .ToList();

                    foreach (var order in orders)
                    {
                        menuItems = db.Orders.Include(o => o.MenuItems).Single(o => o.Id == order.Id).MenuItems;
                        order.MenuItems = menuItems;
                    }
                    user.Orders = orders;

                    users.Add(user);
                }
            }
            //new Log<List<User>>(users).Read();
            return users;
        }

        public List<User> GetMonthlyReport(int month)
        {

            List<User> users = new List<User>();
            List<Order> orders = new List<Order>();
            List<MenuItem> menuItems = new List<MenuItem>();
            using (var db = new KitchenAppContext())
            {

                var query = db.Users.Include(u => u.Orders).Where(u => u.Orders.Any(o => o.Status.Equals("Accepted") && o.Date.Month == month && o.Date.Year == DateTime.Today.Year)).ToList();

                foreach (var user in query)
                {
                    orders = user.Orders.Where(o =>
                            o.Status.Equals("Accepted") && o.Date.Month == month &&
                            o.Date.Year == DateTime.Today.Year)
                        .ToList();

                    foreach (var order in orders)
                    {
                        menuItems = db.Orders.Include(o => o.MenuItems).Single(o => o.Id == order.Id).MenuItems;
                        order.MenuItems = menuItems;
                    }
                    user.Orders = orders;

                    users.Add(user);
                }
            }
            new Log<List<User>>(users).Read();
            return users;
        }

        public List<User> AddUsers(List<User> usersList)
        {
            List<User> usersToAdd = new List<User>();

            using (var db = new KitchenAppContext())
            {
                List<User> usersDb = db.Users.ToList();
                foreach (var user in usersList)
                {
                    bool exists = usersDb.Any(userDb => user.Email == userDb.Email);

                    if (!exists)
                    {
                        usersToAdd.Add(user);
                    }
                }
                db.Users.AddRange(usersToAdd);
                db.SaveChanges();
            }
            return usersToAdd;
        }

        public List<User> RemoveUnlistedUsers(List<User> usersList)
        {
            List<User> usersToRemove = new List<User>();
            using (var db = new KitchenAppContext())
            {
                List<User> usersDb = db.Users.ToList();

                usersToRemove.AddRange(usersDb.Where(userDb => usersList.All(user => userDb.Email != user.Email)));

                db.Users.RemoveRange(usersToRemove);

                db.SaveChanges();
            }
            return usersToRemove;
        }

        public AdminUser AdminLogin(string email, string password)
        {
            AdminUser au = new AdminUser();

            using (var db = new KitchenAppContext())
            {
                if (db.AdminUsers.Any(a => a.UserName == email && a.Password == password))
                {
                    au = db.AdminUsers.Single(a => a.UserName == email && a.Password == password);
                }
            }

            return au;
        }

        public InstagramData GetInstagramData()
        {
            InstagramData instagramData;
            using (var db = new KitchenAppContext())
            {
                instagramData = db.Instagram.Count() == 1 ? db.Instagram.Single() : new InstagramData();
            }

            return instagramData;
        }

        public void SetInstagramData(InstagramData instagramData)
        {
            using (var db = new KitchenAppContext())
            {
                db.Instagram.RemoveRange(db.Instagram);
                db.Instagram.Add(instagramData);
                db.SaveChanges();
            }
        }

        public void DeleteAccessToken()
        {
            using (var db = new KitchenAppContext())
            {
                db.Instagram.RemoveRange(db.Instagram);
                db.SaveChanges();
            }
        }

        public void AcceptAllOrders()
        {
            using (var db = new KitchenAppContext())
            {
                foreach (var order in db.Orders)
                {
                    order.Status = "Accepted";
                }
                db.SaveChanges();
            }
        }

        public void DeleteExpiredOrders(DateTime today)
        {

            using (var db = new KitchenAppContext())
            {
                var orders = db.Orders;

                foreach (var order in orders)
                {
                    if (order.Date < today.AddMonths(-2))
                    {
                        db.Orders.Remove(order);
                    }
                }
                db.SaveChanges();
            }
        }
    }


}