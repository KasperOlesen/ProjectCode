﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KitchenApplication.Models.Database;

namespace WebApplication1.Models.DAL
{
    interface IUserRepository : IDisposable
    {
        IEnumerable<Entity.User> GetUsers();

        Entity.User GetUserById(int userId);

        void InsertUser(Entity.User user);

        void DeleteUser(int userId);

        void UpdateUser(Entity.User user);

        void Save();
    }
}
