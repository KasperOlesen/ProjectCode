﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using KitchenApplication.Models;

namespace WebApplication1.Models
{
    public class InstagramMenuViewModel
    {
        public string Data { get; set; }

        public MenuViewModel MenuVm { get; set; }
    }
}