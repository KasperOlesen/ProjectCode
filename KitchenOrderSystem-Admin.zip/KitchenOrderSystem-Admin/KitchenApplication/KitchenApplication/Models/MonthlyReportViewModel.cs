﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using KitchenApplication.Models;
using KitchenApplication.Models.Database;

namespace WebApplication1.Models
{
    public class MonthlyReportViewModel
    {
        public List<OrderViewModel> Orders { get; set; }
        public double TotalPrice { get; set; }
        public UserViewModel User { get; set; }

        public override string ToString()
        {
            return $"Orders: {Orders}, TotalPrice: {TotalPrice}, User: {User}";
        }
    }
}