﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using KitchenApplication.Models;

namespace WebApplication1.Models
{
    public class UserViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Location { get; set; }
        public string Email { get; set; }
        public string ImageUrl { get; set; }
        public List<OrderViewModel> Orders { get; set; }

        public override string ToString()
        {
            return $"Id: {Id}, Name: {Name}, Location: {Location}, Email: {Email}, ImageUrl: {ImageUrl}";
        }
    }

    public static class UserViewModelExtensions
    {
        public static UserViewModel ToUserViewModel(this string user)
        {
            string[] userData = user.Split(',');

            return new UserViewModel{Name = userData[0], Email = userData[1], Location = userData[2]};
        }
    }
}