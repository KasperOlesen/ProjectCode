﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Employee
    {
        public string Email { get; set; }
        public Guid Id { get; set; }
        public string GivenName { get; set; }
        public string LastName { get; set; }
        public string DisplayName { get; set; }
        public string Department { get; set; }
        public string Title { get; set; }
        public string ADUsername { get; internal set; }
        public string Mobile { get; internal set; }
        public string Country { get; internal set; }
        public string Company { get; internal set; }
        public string Manager { get; internal set; }
        public string OriginalImageFilePath { get; internal set; }
    }
}