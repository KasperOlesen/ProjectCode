module.exports = {
verbose: true,
moduleDirectories: ["node_modules", "webroot"],
moduleFileExtensions: ["js", "jsx"],
transform: {
  "^.+\\.js$": "babel-jest"
}
}