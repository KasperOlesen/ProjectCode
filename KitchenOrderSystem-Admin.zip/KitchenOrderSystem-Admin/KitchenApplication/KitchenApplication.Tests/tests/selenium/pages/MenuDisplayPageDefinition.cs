﻿using KitchenApplication.Tests.tests.selenium.common;
using OpenQA.Selenium;

namespace KitchenApplication.Tests.tests.selenium.pages
{
    /// <summary>
    /// This is the page class to handle the methods on the display menu page
    /// </summary>
    class MenuDisplayPageDefinition : BasePageDefinition
    {
        /// <summary>
        /// The singleton instance
        /// </summary>
        public static readonly MenuDisplayPageDefinition Page = new MenuDisplayPageDefinition();

        /// <summary>
        /// Return the url to the page
        /// </summary>
        /// <returns></returns>
        public override string UrlToPage()
        {
            return string.Format("{0}/{1}", BrowserFactory.GetRunner().BaseUrl, "displayMenu");
        }

        public FieldBase MenuList
        {
            get
            {
                return new FieldBase(By.Id("menuList"));
            }
        }
    }
}
