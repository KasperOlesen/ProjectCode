﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using KitchenApplication.Tests.tests.selenium.common;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace KitchenApplication.Tests.tests.selenium.pages
{
    /// <summary>
    /// Implements a wrapper to get a html field element
    /// </summary>
    public class FieldBase
    {
        /// <summary>
        /// Delegate method to handle a method to get the field
        /// </summary>
        /// <returns></returns>
        public delegate IWebElement FindWebElement(FieldBase field);

        /// <summary>
        /// The delegate to find the DOM element if set
        /// </summary>
        private readonly FindWebElement _findWebElement;

        /// <summary>
        /// The find by delegate if set
        /// </summary>
        private readonly By _findBy;

        /// <summary>
        /// Creates the field
        /// </summary>
        /// <param name="findWebElement"></param>
        public FieldBase(FindWebElement findWebElement)
        {
            _findWebElement = findWebElement;
        }

        /// <summary>
        /// Create the field
        /// </summary>
        /// <param name="findBy"></param>
        public FieldBase(By findBy)
        {
            _findBy = findBy;
        }

        /// <summary>
        /// Wait for the field to appear. 
        /// </summary>
        /// <returns>True if it appear within the timeframe</returns>
        public bool WaitForField()
        {
            return GetFieldElement() != null;
        }

        /// <summary>
        /// Checks if the field is visible
        /// </summary>
        public bool IsVisible
        {
            get
            {
                try
                {
                    return FindElement() != null;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        /// <summary>
        /// Finds the DOM element
        /// </summary>
        /// <returns></returns>
        protected virtual IWebElement FindElement()
        {
            if (_findBy != null)
            {
                return BrowserFactory.GetRunner().WebDriver.FindElement(_findBy);
            }

            return _findWebElement(this);
        }

        /// <summary>
        /// Return the DOM element. It will wait for it to appear
        /// </summary>
        /// <returns></returns>
        public IWebElement GetFieldElement()
        {
            var waitableDriver = new WebDriverWait(BrowserFactory.GetRunner().WebDriver, TimeSpan.FromSeconds(20));
            var element = waitableDriver.Until(d => FindElement());
            return element;
        }

        /// <summary>
        /// The text of the DOM element. Not every field can be set
        /// </summary>
        public string Text
        {
            get { return GetFieldText(); }
            set { SetFieldText(value); }
        }

        /// <summary>
        /// Handles the getting of the field
        /// </summary>
        /// <returns></returns>
        protected virtual string GetFieldText()
        {
            IWebElement element = GetFieldElement();
            return (element != null) ? element.Text : null;
        }

        /// <summary>
        /// Handles setting the field
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        protected virtual bool SetFieldText(string text)
        {
            IWebElement element = GetFieldElement();
            if (element == null)
            {
                return false;
            }

            element.Clear();
            element.SendKeys(text);
            return true;
        }

        /// <summary>
        /// Handles that we click on the field
        /// </summary>
        public void Click()
        {
            IWebElement element = GetFieldElement();
            if (element != null)
            {
                element.Click();
            }
        }
    }
}
