﻿//using System.Reflection;



//    using Microsoft.VisualStudio.TestTools.UnitTesting;
//    using OpenQA.Selenium;
//    using OpenQA.Selenium.Chrome;
//    using OpenQA.Selenium.Firefox;
//    using OpenQA.Selenium.IE;
//    using OpenQA.Selenium.Remote;
//    using OpenQA.Selenium.PhantomJS;
//    using System;

//    //Standard template for utilizing selenium testing framework
//    //currently set to use firefox

//    [TestClass]
//    public class ChucksClass1
//    {
//        private string baseURL = "http://kitchenproject/";
 
//        private static IWebDriver driverFF;
//        private static IWebDriver driverGC;

//        public TestContext TestContext { get; set; }

//        [TestMethod]
//        [TestCategory("Selenium")]
//        [Priority(1)]
//        [Owner("Chrome")]

//        public void IsMenuVisible()
//        {
//            driverGC.Navigate().GoToUrl(baseURL);
//            driverGC.FindElement(By.Id("menuDiv"));
//        }

//        [TestCleanup()]
//        public void MyTestCleanup()
//        {
//            driverGC.Quit();
//        }

//        [AssemblyInitialize()]
//        public void Setup()
//        {
//            driverFF = new FirefoxDriver();
//            driverGC = new ChromeDriver();
//        }
//    }

