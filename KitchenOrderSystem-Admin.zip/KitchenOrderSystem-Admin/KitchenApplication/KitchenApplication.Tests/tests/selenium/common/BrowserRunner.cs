﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;

namespace KitchenApplication.Tests.tests.selenium.common
{
    /// <summary>
    /// This implements a small wrapper around handling the browser for the testing
    /// </summary>
    public class BrowserRunner
    {
        /// <summary>
        /// The name of the server
        /// </summary>
        private readonly string _baseUrl;
        public string BaseUrl { get { return _baseUrl; } }

        /// <summary>
        /// The web driver
        /// </summary>
        private IWebDriver _webDriver;
        public IWebDriver WebDriver
        {
            get { return _webDriver; }
        }

        /// <summary>
        /// Creates it
        /// </summary>
        /// <param name="baseUrl"></param>
        /// <param name="browserType"></param>
        internal BrowserRunner(string baseUrl, string browserType)
        {
            _baseUrl = baseUrl;

            if ("firefox".Equals(browserType))
            {
                _webDriver = new FirefoxDriver();
            }
            else
            {
                _webDriver = new ChromeDriver();
            }
        }

        /// <summary>
        /// Closes the browser test
        /// </summary>
        public void Close()
        {
            if (_webDriver != null)
            {
                _webDriver.Dispose();
                _webDriver = null;
            }
        }

        /// <summary>
        /// Clear all the cookies in the browser
        /// </summary>
        public void ClearCookies()
        {
            _webDriver.Manage().Cookies.DeleteAllCookies();
        }
    }
}

