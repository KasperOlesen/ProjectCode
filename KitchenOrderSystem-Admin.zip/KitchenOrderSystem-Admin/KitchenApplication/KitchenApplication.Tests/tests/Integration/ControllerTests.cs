﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using KitchenApplication.Models;
using KitchenApplication.Models.Database;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebApplication1.Controllers;
using WebApplication1.Models;

namespace KitchenApplication.Tests.tests.Integration
{
    [TestClass]
    public class ControllerTests
    {
        [TestInitialize]
        public void TestInitialize()
        {
            using (var db = new Entity.KitchenAppContext())
            {
                var user1 = new Entity.User
                {
                    Name = "Karsten-Arne",
                    Location = "Kbh",
                    Email = "Karsten-Arne@mail.dk",
                    Orders = new List<Entity.Order>()
                };
                var user2 = new Entity.User
                {
                    Name = "Abel-Ort",
                    Location = "Århus",
                    Email = "abelort@mail.dk",
                    Orders = new List<Entity.Order>()
                };
                var user3 = new Entity.User
                {
                    Name = "Androt",
                    Location = "Kbh",
                    Email = "Androt@mail.dk",
                    Orders = new List<Entity.Order>()
                };
                var user4 = new Entity.User
                {
                    Email = "kasperpontoppidan@gmail.com",
                    Location = "København",
                    Name = "Kasper Hornum Pontoppidan",
                    Orders = new List<Entity.Order>()
                };
                var order1 = new Entity.Order
                {
                    Date = DateTime.Now,
                    DeliveryType = "Pickup",
                    Comment = "TestInit",
                    KitchenComment = "Uden hår",
                    TotalPrice = 50,
                    MenuItems = new List<Entity.MenuItem>()
                };
                var order2 = new Entity.Order
                {
                    Date = DateTime.Now,
                    DeliveryType = "Pickup",
                    Comment = "TestInit",
                    KitchenComment = "Uden hår",
                    TotalPrice = 50,
                    MenuItems = new List<Entity.MenuItem>()
                };
                var order3 = new Entity.Order
                {
                    Date = DateTime.Now,
                    DeliveryType = "Pickup",
                    Comment = "TestInit",
                    KitchenComment = "Uden hår",
                    TotalPrice = 50,
                    MenuItems = new List<Entity.MenuItem>()
                };
                var menu = new Entity.Menu
                {
                    Date = DateTime.Today,
                    ClosingTime = DateTime.Now.AddHours(2),
                    MenuItems = new List<Entity.MenuItem>()
                };
                var menu2 = new Entity.Menu
                {
                    Date = DateTime.Today,
                    ClosingTime = DateTime.Now.AddHours(2),
                    MenuItems = new List<Entity.MenuItem>()
                };
                var menuItem1 = new Entity.MenuItem {FoodItem = "Ged", Description = "Med hår"};
                var menuItem2 = new Entity.MenuItem {FoodItem = "Burger", Description = "med salat"};
                var menuItem3 = new Entity.MenuItem {FoodItem = "Suppe", Description = "løgsuppe"};

                //table add
                order1.MenuItems.Add(menuItem1);
                order1.MenuItems.Add(menuItem2);
                order2.MenuItems.Add(menuItem3);
                order2.MenuItems.Add(menuItem2);
                order3.MenuItems.Add(menuItem1);
                order3.MenuItems.Add(menuItem3);

                user2.Orders.Add(order1);
                user3.Orders.Add(order2);
                user4.Orders.Add(order3);

                menu.MenuItems.Add(menuItem1);
                menu.MenuItems.Add(menuItem2);
                menu.MenuItems.Add(menuItem3);
                menu2.MenuItems.Add(menuItem1);
                menu2.MenuItems.Add(menuItem3);

                //db add
                db.Orders.Add(order1);
                db.Orders.Add(order2);

                db.Users.Add(user1);
                db.Users.Add(user2);
                db.Users.Add(user3);
                db.Users.Add(user4);

                db.Menus.Add(menu);

                db.MenuItems.Add(menuItem1);
                db.MenuItems.Add(menuItem2);
                db.MenuItems.Add(menuItem3);

                db.SaveChanges();
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            using (var db = new Entity.KitchenAppContext())
            {
                db.Orders.RemoveRange(db.Orders);
                db.Users.RemoveRange(db.Users);
                db.Menus.RemoveRange(db.Menus);
                db.MenuItems.RemoveRange(db.MenuItems);
                db.SaveChanges();
            }
        }


        [TestMethod]
        public void TestMenuIndexModelData()
        {
            var controller = new MenuController();

            var ms = new MapperService();

            Entity.Menu DbMenu = new Entity.Menu();
            MenuViewModel mvm;

            using (var db = new Entity.KitchenAppContext())
            {
                DbMenu = db.Menus.Single(x => x.Date == DateTime.Today);
                mvm = new MenuViewModel
                {
                    ClosingTime = DbMenu.ClosingTime,
                    Date = DbMenu.Date,
                    Id = DbMenu.Id,
                    MenuItems = ms.MenuItemsToMenuItemViewModels(DbMenu.MenuItems)
                };
            }


            var result = controller.Index() as ViewResult;

            var model = (InstagramMenuViewModel)result.ViewData.Model;

            Assert.AreEqual(mvm.Id, model.MenuVm.Id);
        }

        [TestMethod]
        public void TestMenuIndexModelDateToday()
        {
            var controller = new MenuController();

            var result = controller.Index() as ViewResult;

            var model = (InstagramMenuViewModel)result.ViewData.Model;

            Assert.AreEqual(DateTime.Today, model.MenuVm.Date);
        }
    }
}
