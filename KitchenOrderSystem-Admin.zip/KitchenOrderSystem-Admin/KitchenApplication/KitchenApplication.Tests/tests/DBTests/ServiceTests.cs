﻿using System;
using System.Collections.Generic;
using KitchenApplication.Models;
using KitchenApplication.Models.Database;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebApplication1.App_Start.Services;
using WebApplication1.Controllers;
using WebApplication1.Models;

namespace KitchenApplication.Tests.tests.DBTests
{
    [TestClass]
    public class ServiceTests
    {
        [TestMethod]
        public void TestWriteMonthlyReportToCsv()
        {
            DataExport dataExport = new DataExport();

            List<MonthlyReportViewModel> monthlyReports = new List<MonthlyReportViewModel>
            {
                new MonthlyReportViewModel
                {
                    Orders = new List<OrderViewModel>
                {
                    new OrderViewModel
                    {
                        Comment = "TestWrite",
                        Date = DateTime.Today,
                        DeliveryType = "TestWriteDel",
                        Id = 999999,
                        KitchenComment = "TestWriteKC",
                        MenuItems = new List<MenuItemViewModel>
                        {
                            new MenuItemViewModel
                            {
                                Description = "TestDescriptionWrite",
                                FoodItem = "TestFoodItemWRite",
                                Id = 9999999,
                                Price = 99
                            },
                            new MenuItemViewModel
                            {

                                Description = "TestDescriptionWrite2",
                                FoodItem = "TestFoodItemWRite2",
                                Id = 9999999,
                                Price = 100

                            }
                        },
                        Price = 199,
                        Status = "Accepted",
                        Users = new List<UserViewModel>
                        {
                            new UserViewModel
                            {
                                Email = "TestWriteEmail@mail.dk",
                                Id = 999999,
                                ImageUrl = "Test/Write/Image/Url/Png",
                                Location = "TestWriteLocation",
                                Name = "TestWriteName"
                            }
                        }
                    }
                },
                    User = new UserViewModel
                    {
                        Email = "TestWriteEmail@mail.dk",
                        Id = 999999,
                        ImageUrl = "Test/Write/Image/Url/Png",
                        Location = "TestWriteLocation",
                        Name = "TestWriteName"
                    }
                },
                new MonthlyReportViewModel
                {
                    Orders = new List<OrderViewModel>
                {
                    new OrderViewModel
                    {
                        Comment = "TestWrite2",
                        Date = DateTime.Today,
                        DeliveryType = "TestWriteDel2",
                        Id = 999997,
                        KitchenComment = "TestWriteKC2",
                        MenuItems = new List<MenuItemViewModel>
                        {
                            new MenuItemViewModel
                            {
                                Description = "TestDescriptionWrite2",
                                FoodItem = "TestFoodItemWRite2",
                                Id = 9999997,
                                Price = 59
                            },
                            new MenuItemViewModel
                            {

                                Description = "TestDescriptionWrite3",
                                FoodItem = "TestFoodItemWRite3",
                                Id = 9999997,
                                Price = 200

                            }
                        },
                        Price = 259,
                        Status = "Accepted",
                        Users = new List<UserViewModel>
                        {
                            new UserViewModel
                            {
                                Email = "TestWriteEmail2@mail.dk",
                                Id = 999997,
                                ImageUrl = "Test/Write/Image/Url/Png2",
                                Location = "TestWriteLocation2",
                                Name = "TestWriteName2"
                            }
                        }
                    }
                },
                    User = new UserViewModel
                    {
                        Email = "TestWriteEmail2@mail.dk",
                        Id = 999997,
                        ImageUrl = "Test/Write/Image/Url/Png2",
                        Location = "TestWriteLocation2",
                        Name = "TestWriteName2"
                    }
                }
            };

            dataExport.ConvertToCsvAndSend(monthlyReports, "kasperpontoppidan@gmail.com");
        }

        [TestMethod]
        public void TestLoggingWrite()
        {
            UserViewModel uvm = new UserViewModel
            {
                Email = "TestWriteEmail2@mail.dk",
                Id = 999997,
                ImageUrl = "Test/Write/Image/Url/Png2",
                Location = "TestWriteLocation2",
                Name = "TestWriteName2"
            };

            Log<UserViewModel> log = new Log<UserViewModel>(uvm);

            log.Write();
        }

        //public void TestLoggingRequest()
        //{
            
        //}

        //[TestMethod]
        //public void TestEmployeeApi()
        //{
        //    EmployeeApiService eas = new EmployeeApiService();

        //    List<Entity.User> users = eas.BuildUsersFromString(eas.Get("http://kitchenproject/app/users"));

        //    Assert.AreEqual(5, users.Count);
        //}

        //[TestMethod]
        //public void TestCreateUsersFromEmployeeApi()
        //{
        //    EmployeeApiService eas = new EmployeeApiService();
        //    string url = "http://kitchenproject/api/employee/GetAll";

        //    EmployeeController ec = new EmployeeController();
        //    var employees = ec.GetAll();

        //    //List<Entity.User> users = eas.BuildUsersFromString(eas.Get(url));

        //    Assert.AreEqual(198, employees.Count);
        //}
    }
}
