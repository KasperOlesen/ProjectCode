﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Mail;
using KitchenApplication.App_Start.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using KitchenApplication.Models.Database;
using KitchenApplication.Services;
using static KitchenApplication.Models.Database.Entity;

namespace KitchenApplication.Tests.tests.DBTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestInitialize]
        public void DBTestSetupInitialize()
        {
            using (var db = new KitchenAppContext())
            {
                var user1 = new User
                {
                    Name = "Karsten-Arne",
                    Location = "Kbh",
                    Email = "Karsten-Arne@mail.dk",
                    Orders = new List<Order>()
                };
                var user2 = new User
                {
                    Name = "Abel-Ort",
                    Location = "Århus",
                    Email = "abelort@mail.dk",
                    Orders = new List<Order>()
                };
                var user3 = new User
                {
                    Name = "Androt",
                    Location = "Kbh",
                    Email = "Androt@mail.dk",
                    Orders = new List<Order>()
                };
                var user4 = new User
                {
                    Email = "kasperpontoppidan@gmail.com",
                    Location = "København",
                    Name = "Kasper Hornum Pontoppidan",
                    Orders = new List<Order>()
                };
                var order1 = new Order
                {
                    Date = DateTime.Now,
                    DeliveryType = "Pickup",
                    Comment = "TestInit",
                    KitchenComment = "Uden hår",
                    TotalPrice = 50,
                    MenuItems = new List<MenuItem>()
                };
                var order2 = new Order
                {
                    Date = DateTime.Now,
                    DeliveryType = "Pickup",
                    Comment = "TestInit",
                    KitchenComment = "Uden hår",
                    TotalPrice = 50,
                    MenuItems = new List<MenuItem>()
                };
                var order3 = new Order
                {
                    Date = DateTime.Now.AddMonths(-3),
                    DeliveryType = "Pickup",
                    Comment = "TestInit",
                    KitchenComment = "Uden hår",
                    TotalPrice = 50,
                    MenuItems = new List<MenuItem>()
                };
                var menu = new Menu {Date = DateTime.Today, ClosingTime = DateTime.Now.AddHours(2), MenuItems = new List<MenuItem>()};
                var menu2 = new Menu {Date = DateTime.Today.AddDays(1), ClosingTime = DateTime.Now.AddHours(2), MenuItems = new List<MenuItem>()};
                var menuItem1 = new MenuItem {FoodItem = "Ged", Description = "Med hår"};
                var menuItem2 = new MenuItem {FoodItem = "Burger", Description = "med salat"};
                var menuItem3 = new MenuItem {FoodItem = "Suppe", Description = "løgsuppe"};

                

                //table add
                order1.MenuItems.Add(menuItem1);
                order1.MenuItems.Add(menuItem2);
                order2.MenuItems.Add(menuItem3);
                order2.MenuItems.Add(menuItem2);
                order3.MenuItems.Add(menuItem1);
                order3.MenuItems.Add(menuItem3);

                user2.Orders.Add(order1);
                user3.Orders.Add(order2);
                user4.Orders.Add(order3);

                menu.MenuItems.Add(menuItem1);
                menu.MenuItems.Add(menuItem2);
                menu.MenuItems.Add(menuItem3);
                menu2.MenuItems.Add(menuItem1);
                menu2.MenuItems.Add(menuItem3);

                //db add
                db.Orders.Add(order1);
                db.Orders.Add(order2);

                db.Users.Add(user1);
                db.Users.Add(user2);
                db.Users.Add(user3);
                db.Users.Add(user4);

                db.Menus.Add(menu);

                db.MenuItems.Add(menuItem1);
                db.MenuItems.Add(menuItem2);
                db.MenuItems.Add(menuItem3);

                db.SaveChanges();
            }
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            using (var db = new KitchenAppContext())
            {
                db.Orders.RemoveRange(db.Orders);
                db.Users.RemoveRange(db.Users);
                db.Menus.RemoveRange(db.Menus);
                db.MenuItems.RemoveRange(db.MenuItems);
                db.SaveChanges();
            }
        }

        [TestMethod]
        public void TestOrderDateExpired()
        {
            Boundary bd = new Boundary();

            bd.DeleteExpiredOrders(DateTime.Today.AddDays(1));
            User user = bd.GetAllUsers().Single(u => u.Email == "kasperpontoppidan@gmail.com");
            Assert.AreEqual(0, user.Orders.Count);
        }

        [TestMethod]
        public void TestOrderIsDeletedWhenExpired()
        {
            Boundary bd = new Boundary();

            //Order o = bd.GetAllUsers().Single(u => u.Email == "kasperpontoppidan@gmail.com").Orders.Single();

            bd.DeleteExpiredOrders(DateTime.Today.AddDays(1));

            Assert.IsFalse(bd.GetAllUsers().Single(u => u.Email == "kasperpontoppidan@gmail.com").Orders.Any());
        }

        [TestMethod]
        public void TestGetAllusers()
        {
            Boundary bd = new Boundary();
            List<User> users = bd.GetAllUsers();

            Assert.AreEqual(4, users.Count);
        }

        [TestMethod]
        public void TestGetOrdersByDate()
        {

            DateTime todayPlusFive = DateTime.Today.AddDays(5);
            Boundary bd = new Boundary();
            var menuItem1 = new MenuItem { FoodItem = "Ged", Description = "Med hår", Price = 25.0 };
            var menuItem2 = new MenuItem { FoodItem = "Burger", Description = "med salat", Price = 25.7 };
            var menuItem3 = new MenuItem { FoodItem = "Suppe", Description = "løgsuppe", Price = 25.3 };
            List<MenuItem> menuItems = new List<MenuItem> { menuItem1, menuItem2, menuItem3 };

            bd.CreateMenu(menuItems, todayPlusFive, todayPlusFive.AddHours(2));
            List<MenuItem> menuItemsDb = bd.GetMenuByDate(todayPlusFive).MenuItems;

            User user = bd.GetAllUsers()[0];
            Order order1 = new Order
            {
                Comment = "SetupTestOrder1Date1",
                Date = todayPlusFive,
                DeliveryType = "Late lunch",
                MenuItems = menuItemsDb
            };
            Order order2 = new Order
            {
                Comment = "SetupTestOrder2Date1",
                Date = todayPlusFive,
                DeliveryType = "Pickup",
                MenuItems = menuItemsDb
            };

            bd.CreateOrder(order1, new List<User> { user });
            bd.CreateOrder(order2, new List<User> { user });


            List<Order> orders = bd.GetOrdersByDate(todayPlusFive);

            Assert.AreEqual(1, orders.Count);
        }

        [TestMethod]
        public void TestSameTypeOrderRejected()
        {

            DateTime todayPlusFive = DateTime.Today.AddDays(5);
            Boundary bd = new Boundary();
            var menuItem1 = new MenuItem { FoodItem = "Ged", Description = "Med hår", Price = 25.0 };
            var menuItem2 = new MenuItem { FoodItem = "Burger", Description = "med salat", Price = 25.7 };
            var menuItem3 = new MenuItem { FoodItem = "Suppe", Description = "løgsuppe", Price = 25.3 };
            List<MenuItem> menuItems = new List<MenuItem> { menuItem1, menuItem2, menuItem3 };

            bd.CreateMenu(menuItems, todayPlusFive, todayPlusFive.AddHours(2));
            List<MenuItem> menuItemsDb = bd.GetMenuByDate(todayPlusFive).MenuItems;

            User user = bd.GetAllUsers()[0];
            Order order1 = new Order
            {
                Comment = "SetupTestOrder1Date1",
                Date = todayPlusFive,
                DeliveryType = "Late lunch",
                MenuItems = menuItemsDb
            };
            Order order2 = new Order
            {
                Comment = "SetupTestOrder2Date1",
                Date = todayPlusFive,
                DeliveryType = "Pickup",
                MenuItems = menuItemsDb
            };

            string success = bd.CreateOrder(order1, new List<User> { user });
            string fail = bd.CreateOrder(order2, new List<User> { user });

            Assert.AreNotEqual(success, fail);
        }

        [TestMethod]
        public void TestGetOrdersByUser()
        {
            Boundary bd = new Boundary();
            var user1 = new User
            {
                Name = "testGetOrderUser",
                Location = "Kbh",
                Email = "testGetOrderUser@mail.dk",
            };
            DateTime todayPlusFour = DateTime.Today.AddDays(4);
            var menuItem1 = new Entity.MenuItem { FoodItem = "TestGetOrdersByUserFoodItem1", Description = "Med hår", Price = 25.0 };
            var menuItem2 = new Entity.MenuItem { FoodItem = "TestGetOrdersByUserFoodItem2", Description = "med salat", Price = 25.7 };
            var menuItem3 = new Entity.MenuItem { FoodItem = "TestGetOrdersByUserFoodItem3", Description = "løgsuppe", Price = 25.3 };
            List<MenuItem> menuItems = new List<MenuItem> { menuItem1, menuItem2, menuItem3 };

            bd.CreateMenu(menuItems, todayPlusFour, todayPlusFour.AddHours(2));
            List<MenuItem> menuItemsDb = bd.GetMenuByDate(todayPlusFour).MenuItems;

            Order order1 = new Order
            {
                Comment = "SetupTestOrder1User",
                Date = todayPlusFour,
                DeliveryType = "Late lunch",
                MenuItems = menuItemsDb
            };
            Order order2 = new Order
            {
                Comment = "SetupTestOrder2User",
                Date = todayPlusFour,
                DeliveryType = "Pickup",
                MenuItems = menuItemsDb
            };

            
            bd.CreateUser(user1);
            bd.CreateOrder(order1, new List<User> { user1 });
            bd.CreateOrder(order2, new List<User> { user1 });

            Entity.User user = bd.GetAllUsers().FirstOrDefault(u => u.Name == "testGetOrderUser");

            List<Order> orders = bd.GetOrdersByUser(user);

            Assert.AreEqual(2, orders.Count);
        }

        [TestMethod]
        public void TestOrdersByMonth()
        {
            int month = DateTime.Today.Month;
            Boundary bd = new Boundary();
            List<Order> orders = bd.GetOrdersByMonth(month);

            Assert.IsTrue(orders.FirstOrDefault(o => o.Date.Month == month).Date.Month == month);
        }

        [TestMethod]
        public void TestGetTodaysMenu()
        {
            var menu = new Menu { Date = DateTime.Today, MenuItems = new List<MenuItem>() };
            Boundary bd = new Boundary();
            Menu dbMenu = bd.GetMenuByDate(DateTime.Today);

            Assert.AreEqual(menu.Date, dbMenu.Date);
        }

        //[TestMethod]
        //public void TestChangeOrderStatus()
        //{
        //    Boundary bd = new Boundary();

        //    Order order = bd.GetLatestOrderByUserEmail("abelort@mail.dk");


        //    bd.ChangeOrderStatus(order.Id, "Declined", "kitchen comment", 0);


        //    Assert.AreEqual("Declined", bd.GetLatestOrderByUserEmail("abelort@mail.dk").Status);
        //}


        [TestMethod]
        public void TestCreateOrder()
        {
            DateTime testDate = DateTime.Today;
            Boundary bd = new Boundary();
            User user = bd.GetAllUsers().Single(x => x.Email.Equals("Karsten-Arne@mail.dk"));

            List<MenuItem> menuItems = bd.GetMenuByDate(testDate).MenuItems;

            Order order1 = new Order
            {
                Comment = "SetupTestCreateOrder",
                Date = testDate,
                DeliveryType = "Late lunch",
                MenuItems = menuItems
            };

            bd.CreateOrder(order1, new List<User>{user});

            Assert.AreEqual(order1.Comment, bd.GetOrdersByUser(user)[0].Comment);
        }

        [TestMethod]
        public void TestCreateManyOrdersToday()
        {
            Boundary bd = new Boundary();
            DateTime testDate = DateTime.Today;
            List<User> users = bd.GetAllUsers();

            List<MenuItem> menuItems = bd.GetMenuByDate(testDate).MenuItems;

            Order order = new Order
            {
                Date = testDate,
                DeliveryType = "Late Lunch",
                Comment = "TestCreateManyOrders",
                KitchenComment = "Ingen remo",
                TotalPrice = 50.0,
                MenuItems = menuItems
            };

            bd.CreateOrder(order, users);

            Assert.AreEqual(order.Comment, bd.GetLatestOrderByUserEmail("Karsten-Arne@mail.dk").Comment);
        }

        [TestMethod]
        public void TestGetAllOrdersToday()
        {
            Boundary bd = new Boundary();
            var orders = bd.GetUserOrdersByDate(DateTime.Today);


            Assert.IsNotNull(orders);
        }

        [TestMethod]
        public void TestKitchenClosingTime()
        {
            Boundary bd = new Boundary();
            DateTime testDate = DateTime.Today.AddDays(9);
            var menuItem1 = new MenuItem { FoodItem = "Test1", Description = "Med hår", Price = 25.0 };
            var menuItem2 = new MenuItem { FoodItem = "Test2", Description = "med salat", Price = 25.0 };
            var menuItem3 = new MenuItem { FoodItem = "Test3", Description = "løgsuppe", Price = 25.0 };

            List<MenuItem> menuItems = new List<MenuItem> { menuItem1, menuItem2, menuItem3 };

            bd.CreateMenu(menuItems, testDate, testDate.AddHours(2));

            Menu menu = bd.GetMenuByDate(testDate);

            Assert.AreEqual(testDate.AddHours(2), menu.ClosingTime);
        }

        //[TestMethod]
        //public void TestGetAcceptedOrdersByMonth()
        //{
        //    Boundary bd = new Boundary();

        //    DateTime testDate = DateTime.Today.AddDays(3);
        //    var user = new User
        //    {
        //        Name = "test1",
        //        Location = "Kbh",
        //        Email = "test1@mail.dk",
        //        Orders = new List<Order>()
        //    };
        //    var user2 = new User
        //    {
        //        Name = "test2",
        //        Location = "Kbh",
        //        Email = "test2@mail.dk",
        //        Orders = new List<Order>()
        //    };
        //    var user3 = new User
        //    {
        //        Name = "test3",
        //        Location = "Kbh",
        //        Email = "test3@mail.dk",
        //        Orders = new List<Order>()
        //    };
        //    var user4 = new User
        //    {
        //        Name = "test4",
        //        Location = "Kbh",
        //        Email = "test4@mail.dk",
        //        Orders = new List<Order>()
        //    };
        //    bd.CreateUser(user);
        //    bd.CreateUser(user2);
        //    bd.CreateUser(user3);
        //    bd.CreateUser(user4);


        //    var menuItem1 = new MenuItem { FoodItem = "TestCreateOrderFoodItem1", Description = "Med hår", Price = 25.0 };
        //    var menuItem2 = new MenuItem { FoodItem = "TestCreateOrderFoodItem2", Description = "med salat", Price = 25.0 };
        //    var menuItem3 = new MenuItem { FoodItem = "TestCreateOrderFoodItem3", Description = "løgsuppe", Price = 25.0 };

        //    List<MenuItem> menuItems = new List<MenuItem> { menuItem1, menuItem2, menuItem3 };
        //    bd.CreateMenu(menuItems, testDate, testDate.AddHours(2));

        //    List<MenuItem> menuItemsDb = bd.GetMenuByDate(testDate).MenuItems;

        //    Order order1 = new Order
        //    {
        //        Comment = "SetupTestCreateOrder",
        //        Date = DateTime.Today.AddMonths(1),
        //        DeliveryType = "Late lunch",
        //        MenuItems = menuItemsDb
        //    };

        //    bd.CreateOrder(order1, new List<User> { user });
        //    bd.CreateOrder(order1, new List<User> { user2 });
        //    bd.CreateOrder(order1, new List<User> { user3 });
        //    bd.CreateOrder(order1, new List<User> { user4 });

        //    List<User> users = bd.GetAllUsers();

        //    bd.ChangeOrderStatus(bd.GetOrdersByUser(bd.GetUser(users.Single(u => u.Name == "test1").Id))[0].Id, "Accepted", "we", 0);
        //    bd.ChangeOrderStatus(bd.GetOrdersByUser(bd.GetUser(users.Single(u => u.Name == "test2").Id))[0].Id, "Declined", "we", 0);
        //    bd.ChangeOrderStatus(bd.GetOrdersByUser(bd.GetUser(users.Single(u => u.Name == "test3").Id))[0].Id, "Accepted", "we", 0);
        //    bd.ChangeOrderStatus(bd.GetOrdersByUser(bd.GetUser(users.Single(u => u.Name == "test4").Id))[0].Id, "Accepted", "we", 0);

        //    Assert.AreEqual(3, bd.GetAcceptedOrdersByMonth(DateTime.Today.AddMonths(1).Month).Count);
        //}

        [TestMethod]
        public void TestMenuItemsOrderCount()
        {
            DateTime testDate = DateTime.Today;
            Boundary bd = new Boundary();
            
            List<MenuItem> menuItemsDb = bd.GetMenuByDate(testDate).MenuItems;

            Assert.AreEqual(2, menuItemsDb[0].OrderCount);

        }

        //[TestMethod]
        //public void TestGetMonthlyReport()
        //{
        //    Boundary bd = new Boundary();

        //    DateTime testDate = DateTime.Today.AddDays(9);
        //    var user = new User
        //    {
        //        Name = "testm1",
        //        Location = "Kbh",
        //        Email = "test1@mail.dk",
        //        Orders = new List<Order>()
        //    };

        //    bd.CreateUser(user);

        //    var menuItem1 = new MenuItem { FoodItem = "TestCreateOrderFoodItem1", Description = "Med hår", Price = 25.0 };
        //    var menuItem2 = new MenuItem { FoodItem = "TestCreateOrderFoodItem2", Description = "med salat", Price = 25.0 };
        //    var menuItem3 = new MenuItem { FoodItem = "TestCreateOrderFoodItem3", Description = "løgsuppe", Price = 25.0 };

        //    List<MenuItem> menuItems = new List<MenuItem> { menuItem1, menuItem2, menuItem3 };
        //    bd.CreateMenu(menuItems, testDate, testDate.AddHours(2));

        //    List<MenuItem> menuItemsDb = bd.GetMenuByDate(testDate).MenuItems;

        //    Order order1 = new Order
        //    {
        //        Comment = "SetupTestCreateOrderM",
        //        Date = testDate,
        //        DeliveryType = "Late lunch",
        //        MenuItems = menuItemsDb
        //    };

        //    bd.CreateOrder(order1, new List<User> { user });
        //    bd.CreateOrder(order1, new List<User> { user });
        //    bd.CreateOrder(order1, new List<User> { user });
        //    bd.CreateOrder(order1, new List<User> { user });

        //    List<User> users = bd.GetAllUsers();

        //    User userTest = bd.GetUser(users.Single(u => u.Name == "testm1").Id);

        //    int orderId = bd.GetOrdersByUser(userTest)[0].Id;

        //    bd.ChangeOrderStatus(orderId, "Accepted", "we", 0);

        //    List<User> users2 = bd.GetMonthlyReport();

        //    double total = order1.TotalPrice * 4;

        //    double res = 0;
        //    foreach (var item in users2)
        //    {
        //        foreach (var order in item.Orders)
        //        {
        //            res += order.TotalPrice;
        //        }
        //    }

        //    Assert.AreEqual(total, res);
        //}

        //[TestMethod]
        //public void TestSendEmail()
        //{
        //    string fileName = "C:\\Users\\kponto01\\Downloads\\kitchenappattachmenttestfile.txt";

        //    FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);


        //    Attachment thisAttachment = new Attachment(fs, fileName);

        //    Attachment[] attachments = { thisAttachment };
        //    var from = new MailAddress("khp@magnetix.dk");
        //    string subject = "test subject";
        //    string bodytext = "test body";
        //    string[] recipients = { "kasperpontoppidan@gmail.com", "khp@magnetix.dk" };

        //    MailConfiguration mailConf = new MailConfiguration(from, subject, bodytext, attachments, recipients);

        //    EmailServiceCustom emailService = new EmailServiceCustom();
        //    emailService.AddOutgoingEmail(mailConf);
        //    emailService.SendAllEmails();
        //    //how to test if email was received?
        //    Assert.AreEqual(true, true);
        //}

        //[TestMethod]
        //public void TestOrderNotificationEmail()
        //{
        //    MenuItem mi = new MenuItem
        //    {
        //        FoodItem = "Test food item",
        //        Description = "for email notification",
        //        Price = 35.5
        //    };
        //    MenuItem mi2 = new MenuItem
        //    {
        //        FoodItem = "Test food item 2",
        //        Description = "for email notification",
        //        Price = 22
        //    };
        //    Order order = new Order
        //    {
        //        Comment = "Test comment for email notification",
        //        Date = DateTime.Today,
        //        DeliveryType = "Pickup",
        //        KitchenComment = "Test kitchen comment",
        //        MenuItems = new List<MenuItem> { mi, mi2 }
        //    };
        //    Boundary bd = new Boundary();

        //    User user = bd.GetUserByName("Kasper Hornum Pontoppidan");

        //    bd.CreateOrder(order.Date, order.DeliveryType, order.Comment, order.KitchenComment, order.MenuItems, new List<User>{user});
        //}
    }
}
